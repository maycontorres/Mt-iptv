ÁUREON V35.22 — correção de compilação

Unificados os callbacks onActivityResult em MainActivity.java, preservando o gerenciamento de múltiplas listas (requestCode 712) e a seleção de arquivo M3U (requestCode 77). Sem mudanças adicionais no banner.
