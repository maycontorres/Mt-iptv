# ÁUREON V35.21 — banner automático corrigido

- Carrega o catálogo de filmes ao abrir a tela inicial, sem exigir entrar primeiro na aba Filmes.
- Quando a lista não contém uma categoria Cinema, usa os filmes mais recentes disponíveis da própria lista.
- Atualiza a tela inicial assim que o catálogo persistido é carregado.
- Alterna entre filmes a cada 5 segundos quando existem pelo menos dois títulos.
- Mantém a imagem estática apenas se não houver filmes disponíveis; um único filme não pode alternar.
- Preserva o gerenciamento de múltiplas listas e os reprodutores da versão anterior.

Compilação e testes em dispositivo ainda necessários.
