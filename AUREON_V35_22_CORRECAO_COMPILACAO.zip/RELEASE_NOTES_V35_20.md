# ÁUREON V35.20 — Múltiplas listas + Banner rápido

- Ao adicionar outra lista, salva a lista anterior em Minhas listas, sem substituí-la.
- Salva automaticamente a nova lista após conexão bem-sucedida.
- Minhas listas permite selecionar listas salvas e adicionar outra.
- Banner Cinema alterna a cada 5 segundos (antes 12).
- Preserva os motores ExoPlayer e LibVLC da V35.19.

Observação: listas são selecionadas individualmente; os catálogos não são mesclados. Compile e teste antes de distribuir.
