# ÁUREON release rules
-keepattributes Signature,*Annotation*
-dontwarn javax.annotation.**

# Media3/OkHttp/Glide provide consumer rules; keep app models used by JSON cache explicit.
-keep class com.mtiptv.app.MediaEntry { *; }
-keep class com.mtiptv.app.XtreamCreds { *; }
-keep class com.mtiptv.app.EpgItem { *; }
-keep class com.mtiptv.app.DetailInfo { *; }
