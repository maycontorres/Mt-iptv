package com.mtiptv.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.View;
import android.view.ViewParent;
import android.view.inputmethod.InputMethodManager;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ProgressBar;
import android.content.res.ColorStateList;
import android.os.SystemClock;

import androidx.media3.common.MediaItem;
import androidx.media3.datasource.okhttp.OkHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.GridLayoutManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.os.Handler;
import android.os.Looper;

public class MainActivity extends Activity {
    static final int LIVE=0, MOVIE=1, SERIES=2;
    static final int PAGE_SIZE=80, MAX_ITEMS=50000;

    final int GOLD=Color.rgb(229,178,63), BG=Color.rgb(5,5,6), PANEL=Color.rgb(15,15,17),
            CARD=Color.rgb(18,18,20), WHITE=Color.rgb(245,245,245), MUTED=Color.rgb(170,170,175);

    LinearLayout root, nav, content, browserList;
    RecyclerView browserRecycler, mediaRecycler;
    TextView browserResultCount;
    ChannelRecyclerAdapter channelRecyclerAdapter;
    MediaRecyclerAdapter mediaRecyclerAdapter;
    ScrollView contentScroll, navScroll;
    SharedPreferences prefs;
    ExecutorService exec=Executors.newSingleThreadExecutor();
    // Carregamento das três bibliotecas em paralelo. Isso evita esperar TV terminar para só então buscar Filmes/Séries.
    ExecutorService dataExec=Executors.newFixedThreadPool(2);
    ExecutorService cacheExec=Executors.newSingleThreadExecutor();
    Uri selectedM3u;
    final Handler uiHandler=new Handler(Looper.getMainLooper());
    static final long STARTUP_MIN_MS=1400L;
    static final long ACTIVATION_POLL_MS=5000L;
    long startupStartedAt;
    DeviceActivationClient activationClient;
    boolean activationPolling=false;
    final Runnable activationPollTask=this::pollActivation;
    final Runnable prepareStartupTask=this::prepareStartup;
    final Runnable finishStartupTask=()->{
        if(!isFinishing()&&!isDestroyed())build();
    };
    TextView pageTitle, status;
    String activeScreen="";
    boolean compact, navCollapsed=false, navHidden=false;
    int navWidth;
    Button topMenuButton;
    List<MediaEntry> playlistCache=new ArrayList<>(), browserAll=new ArrayList<>(), browserFiltered=new ArrayList<>();
    List<String> browserCategoryOrder=new ArrayList<>();
    int browserShown=0, browserKind=LIVE;
    String browserGroup="Todos", browserQuery="";
    boolean browserSortRecent=true;
    GridLayout mediaGrid;
    TextView mediaCount;
    LinearLayout categoryColumn, liveCategoryColumn;
    EditText categorySearch;
    // Estado de navegação por controle remoto. Mantém categoria/item e evita foco "invisível".
    String lastFocusedCategory="Todos", lastFocusedBrowserKey="", lastFocusedMediaKey="";
    long lastBackPressAt=0L;

    // Cache de TV / Filmes / Séries em memória. Trocar de aba não baixa a lista novamente.
    static final long SECTION_CACHE_TTL_MS=60L*60L*1000L;
    final Object sectionCacheLock=new Object();
    final Map<Integer,SectionData> sectionCache=new LinkedHashMap<>();
    final Set<Integer> sectionLoading=new LinkedHashSet<>();
    volatile int currentSectionRequest=-1;
    final Map<String,DetailInfo> detailCache=new LinkedHashMap<>();
    final Map<String,List<EpgItem>> epgCache=new LinkedHashMap<>();
    ExoPlayer previewPlayer;
    PlayerView previewPlayerView;
    MediaEntry previewEntry;
    MediaEntry pendingBrowserPreview;
    TextView browserPreviewHint;
    Button browserFavoriteButton;
    final Runnable browserPreviewTask=()->{
        MediaEntry selected=pendingBrowserPreview;
        pendingBrowserPreview=null;
        if(selected!=null && "TV Ao Vivo".equals(activeScreen))selectBrowserPreview(selected);
    };
    LinearLayout liveEpgContainer;

    // Navegação Anterior/Próximo para detalhes e player.
    List<MediaEntry> detailNavItems=new ArrayList<>();
    // Estado para o botão Voltar/D-pad: ao sair de detalhes, retorna à mesma categoria/item.
    int detailScreenKind=-1, restoreKind=-1;
    String restoreGroup="Todos", restoreQuery="", restoreFocusKey="";
    FeaturedTitle pendingFeatured;
    static final ArrayList<MediaEntry> PLAYER_QUEUE=new ArrayList<>();
    static int PLAYER_INDEX=-1;

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+.5f); }

    TextView text(String s,float size){
        TextView t=new TextView(this); t.setText(s); t.setTextColor(WHITE); t.setTextSize(size); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }

    GradientDrawable box(int color,float radius,int strokeColor,int stroke){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); if(stroke>0)g.setStroke(dp(stroke),strokeColor); return g;
    }

    Button button(String s){
        Button b=new Button(this); b.setText(s); b.setTextColor(WHITE); b.setTextSize(compact?11:14); b.setAllCaps(false); b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(42)); b.setPadding(dp(9),0,dp(9),0); b.setBackground(box(CARD,13,Color.rgb(80,63,25),1)); b.setFocusable(true); b.setClickable(true);
        b.setOnFocusChangeListener((v,has)->{
            if(has){ v.setBackground(box(Color.rgb(58,42,15),13,GOLD,3)); focusMotion(v,true); }
            else { v.setBackground(box(CARD,13,Color.rgb(80,63,25),1)); focusMotion(v,false); }
        });
        return b;
    }

    // Android TV / Google TV: deixa o item atual bem visível ao navegar no D-pad.
    void focusMotion(View v,boolean has){
        if(v==null)return;
        v.animate().cancel();
        v.animate().scaleX(has?1.018f:1f).scaleY(has?1.018f:1f).setDuration(85).start();
        if(Build.VERSION.SDK_INT>=21)v.setElevation(has?dp(8):0);
        if(has) revealFocused(v);
    }

    void revealFocused(View v){
        if(v==null)return;
        v.post(()->{
            try{
                android.graphics.Rect r=new android.graphics.Rect(0,0,Math.max(1,v.getWidth()),Math.max(1,v.getHeight()));
                v.requestRectangleOnScreen(r,true);
                // Em listas de categorias, mantém o item focado próximo ao centro da tela.
                ViewParent p=v.getParent();
                while(p!=null){
                    if(p instanceof ScrollView){
                        ScrollView sv=(ScrollView)p;
                        int[] vl=new int[2], sl=new int[2];
                        v.getLocationOnScreen(vl); sv.getLocationOnScreen(sl);
                        int target=sl[1]+sv.getHeight()/2;
                        int current=vl[1]+v.getHeight()/2;
                        sv.smoothScrollBy(0,current-target);
                        break;
                    }
                    p=p.getParent();
                }
            }catch(Exception ignored){}
        });
    }

    void focusFirstChild(LinearLayout parent){
        if(parent==null||parent.getChildCount()==0)return;
        parent.post(()->{
            for(int i=0;i<parent.getChildCount();i++){
                View v=parent.getChildAt(i);
                if(v!=null&&v.isFocusable()&&v.getVisibility()==View.VISIBLE){ v.requestFocus(); revealFocused(v); break; }
            }
        });
    }

    void focusFirstBrowserItem(){
        if(browserRecycler==null)return;
        browserRecycler.scrollToPosition(0);
        browserRecycler.postDelayed(()->{RecyclerView.ViewHolder h=browserRecycler.findViewHolderForAdapterPosition(0);if(h!=null){View target=h.itemView;if(target instanceof android.view.ViewGroup&&((android.view.ViewGroup)target).getChildCount()>0)target=((android.view.ViewGroup)target).getChildAt(0);target.requestFocus();revealFocused(target);}},80);
    }

    void focusFirstMediaCard(){
        if(mediaRecycler==null)return;
        mediaRecycler.scrollToPosition(0);
        mediaRecycler.postDelayed(()->{RecyclerView.ViewHolder h=mediaRecycler.findViewHolderForAdapterPosition(0);if(h!=null){View target=h.itemView;if(target instanceof android.view.ViewGroup&&((android.view.ViewGroup)target).getChildCount()>0)target=((android.view.ViewGroup)target).getChildAt(0);target.requestFocus();revealFocused(target);}},80);
    }

    void focusCategoryByName(LinearLayout parent,String group){
        if(parent==null||parent.getChildCount()==0)return;
        String wanted=(group==null||group.isEmpty())?"Todos":group;
        parent.post(()->{
            View fallback=null;
            for(int i=0;i<parent.getChildCount();i++){
                View v=parent.getChildAt(i);
                if(v==null||!v.isFocusable()||v.getVisibility()!=View.VISIBLE)continue;
                if(fallback==null)fallback=v;
                Object tag=v.getTag();
                if(tag!=null&&wanted.equals(String.valueOf(tag))){v.requestFocus();revealFocused(v);return;}
            }
            if(fallback!=null){fallback.requestFocus();revealFocused(fallback);}
        });
    }

    void focusActiveCategory(){
        LinearLayout parent=liveCategoryColumn!=null?liveCategoryColumn:categoryColumn;
        focusCategoryByName(parent,browserGroup==null?lastFocusedCategory:browserGroup);
    }

    boolean focusLastContentItem(){
        if(browserRecycler!=null){
            if(lastFocusedBrowserKey!=null&&!lastFocusedBrowserKey.isEmpty())restoreBrowserItemFocus(lastFocusedBrowserKey);
            else focusFirstBrowserItem();
            return true;
        }
        if(mediaRecycler!=null){
            if(lastFocusedMediaKey!=null&&!lastFocusedMediaKey.isEmpty())restoreMediaItemFocus(lastFocusedMediaKey);
            else focusFirstMediaCard();
            return true;
        }
        return false;
    }

    boolean isDescendantOf(View child,View parent){
        if(child==null||parent==null)return false;
        View cur=child;
        while(cur!=null){
            if(cur==parent)return true;
            ViewParent p=cur.getParent();
            cur=p instanceof View?(View)p:null;
        }
        return false;
    }

    boolean dismissSearchFocus(){
        View f=getCurrentFocus();
        if(!(f instanceof EditText))return false;
        try{
            InputMethodManager imm=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            if(imm!=null)imm.hideSoftInputFromWindow(f.getWindowToken(),0);
        }catch(Exception ignored){}
        f.clearFocus();
        if(liveCategoryColumn!=null||categoryColumn!=null)focusActiveCategory();
        return true;
    }

    void refreshCategorySelection(LinearLayout parent){
        if(parent==null)return;
        for(int i=0;i<parent.getChildCount();i++){
            View v=parent.getChildAt(i);
            if(!(v instanceof LinearLayout))continue;
            LinearLayout row=(LinearLayout)v; Object tag=row.getTag();
            boolean active=tag!=null&&String.valueOf(tag).equals(browserGroup);
            boolean focused=row.hasFocus();
            row.setBackground(box(focused?Color.rgb(78,56,16):(active?Color.rgb(70,50,16):Color.TRANSPARENT),10,focused?GOLD:(active?GOLD:Color.TRANSPARENT),focused?4:(active?2:0)));
            if(row.getChildCount()>0&&row.getChildAt(0) instanceof TextView){
                TextView n=(TextView)row.getChildAt(0); n.setTextColor((focused||active)?GOLD:WHITE); n.setTypeface(null,(focused||active)?1:0);
            }
            if(row.getChildCount()>1&&row.getChildAt(1) instanceof TextView){
                TextView c=(TextView)row.getChildAt(1); c.setTextColor(focused?WHITE:(active?GOLD:MUTED));
            }
        }
    }

    void restoreBrowserItemFocus(String key){
        if(browserRecycler==null||channelRecyclerAdapter==null||key==null||key.isEmpty())return;
        int pos=-1;for(int i=0;i<channelRecyclerAdapter.data.size();i++)if(key.equals(PlaybackStore.key(channelRecyclerAdapter.data.get(i)))){pos=i;break;}
        if(pos<0){focusFirstBrowserItem();return;} final int p=pos; browserRecycler.scrollToPosition(p);
        browserRecycler.postDelayed(()->{RecyclerView.ViewHolder h=browserRecycler.findViewHolderForAdapterPosition(p);if(h!=null){View t=h.itemView;if(t instanceof android.view.ViewGroup&&((android.view.ViewGroup)t).getChildCount()>0)t=((android.view.ViewGroup)t).getChildAt(0);t.requestFocus();revealFocused(t);}},140);
    }

    void restoreMediaItemFocus(String key){
        if(mediaRecycler==null||mediaRecyclerAdapter==null||key==null||key.isEmpty())return;
        int pos=-1;for(int i=0;i<mediaRecyclerAdapter.data.size();i++)if(key.equals(PlaybackStore.key(mediaRecyclerAdapter.data.get(i)))){pos=i;break;}
        if(pos<0){focusFirstMediaCard();return;} final int p=pos; mediaRecycler.scrollToPosition(p);
        mediaRecycler.postDelayed(()->{RecyclerView.ViewHolder h=mediaRecycler.findViewHolderForAdapterPosition(p);if(h!=null){View t=h.itemView;if(t instanceof android.view.ViewGroup&&((android.view.ViewGroup)t).getChildCount()>0)t=((android.view.ViewGroup)t).getChildAt(0);t.requestFocus();revealFocused(t);}},140);
    }

    void returnToSection(int kind){ detailScreenKind=-1; if(kind==LIVE)showLive(); else if(kind==SERIES)showSeries(); else showMovies(); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        AppCrashReporter.install(this);
        enterImmersiveMode();
        prefs=AppPrefs.get(this); compact=getResources().getConfiguration().screenWidthDp<900; navWidth=compact?180:225;
        if(!prefs.contains("auto_refresh"))prefs.edit().putBoolean("auto_refresh",true).apply();
        scheduleAutoRefresh();
        showStartup();
        // Give the logo a frame to appear before preparing local state.
        uiHandler.postDelayed(prepareStartupTask,32L);
    }

    void showStartup(){
        startupStartedAt=SystemClock.uptimeMillis();
        LinearLayout splash=new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL); splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(BG); splash.setPadding(dp(24),dp(12),dp(24),dp(12));
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.aureon_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER); logo.setContentDescription("ÁUREON");
        int logoHeight=Math.min(compact?180:235,Math.max(80,getResources().getConfiguration().screenHeightDp-120));
        splash.addView(logo,new LinearLayout.LayoutParams(dp(compact?240:310),dp(logoHeight)));
        ProgressBar progress=new ProgressBar(this); progress.setIndeterminate(true);
        progress.setIndeterminateTintList(ColorStateList.valueOf(GOLD));
        progress.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(28),dp(28)); pp.topMargin=dp(14);
        splash.addView(progress,pp);
        TextView loading=text(getString(R.string.ui_001),compact?12:15);
        loading.setGravity(Gravity.CENTER); loading.setTextColor(MUTED);
        loading.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(36)); lp.topMargin=dp(6);
        splash.addView(loading,lp);
        setContentView(splash);
    }

    void prepareStartup(){
        if(isFinishing()||isDestroyed())return;
        if(!prefs.contains("autoplay_live")||!prefs.contains("resume_vod")||!prefs.contains("clock_24h")){
            SharedPreferences.Editor defaults=prefs.edit();
            if(!prefs.contains("autoplay_live"))defaults.putBoolean("autoplay_live",true);
            if(!prefs.contains("resume_vod"))defaults.putBoolean("resume_vod",true);
            if(!prefs.contains("clock_24h"))defaults.putBoolean("clock_24h",false);
            defaults.apply();
        }
        CredentialStore.migrate(prefs);
        migrateOldSource();
        String savedUri=prefs.getString("file_uri",""); if(!savedUri.isEmpty())try{selectedM3u=Uri.parse(savedUri);}catch(Exception ignored){}
        // Network availability never gates the home screen; catálogos continuam carregando em segundo plano.
        long remaining=STARTUP_MIN_MS-(SystemClock.uptimeMillis()-startupStartedAt);
        uiHandler.postDelayed(finishStartupTask,Math.max(0L,remaining));
    }

    void enterImmersiveMode(){
        // Compatível com Android 6+ e evita APIs modernas de insets que podem falhar em alguns aparelhos.
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override protected void onResume(){
        super.onResume();
        enterImmersiveMode();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus){
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus) enterImmersiveMode();
    }


    void migrateOldSource(){
        String mode=prefs.getString("source_mode","").trim();
        String file=prefs.getString("file_uri","").trim();
        String xs=prefs.getString("xt_server","").trim();
        String xu=CredentialStore.user(prefs).trim();
        String xp=CredentialStore.pass(prefs).trim();
        String old=CredentialStore.m3uUrl(prefs).trim();
        String input=old;

        // Se o modo salvo ainda é válido, não altera nada.
        if(mode.equals("xtream")&&!xs.isEmpty()&&!xu.isEmpty()&&!xp.isEmpty())return;
        if(mode.equals("file")&&!file.isEmpty())return;
        if(mode.equals("m3u")&&(!old.isEmpty()||!input.isEmpty()))return;

        // Credenciais Xtream salvas por versões mais novas.
        if(!xs.isEmpty()&&!xu.isEmpty()&&!xp.isEmpty()){
            prefs.edit().putString("source_mode","xtream").apply();
            return;
        }

        // Versões antigas salvavam a URL get.php completa. Recupera servidor, usuário e senha dela.
        String[] candidates={old,input};
        for(String candidate:candidates){
            if(candidate==null||candidate.trim().isEmpty())continue;
            try{
                XtreamCreds x=xtreamFromM3uUrl(candidate);
                if(x!=null&&x.valid()){
                    prefs.edit().putString("source_mode","xtream")
                            .putString("xt_server",x.server).apply();
                    CredentialStore.save(prefs,x.user,x.pass);
                    return;
                }
            }catch(Exception ignored){}
        }

        if(!file.isEmpty()){
            prefs.edit().putString("source_mode","file").apply();
            return;
        }
        if(!old.isEmpty()){
            prefs.edit().putString("source_mode","m3u").apply();
            return;
        }
        if(!input.isEmpty()){
            prefs.edit().putString("source_mode","m3u").apply();
            CredentialStore.saveM3uUrl(prefs,input);
        }
    }

    String resolveSourceMode(){
        migrateOldSource();
        String mode=prefs.getString("source_mode","").trim();
        if(mode.equals("xtream")&&savedXtream().valid())return "xtream";
        if(mode.equals("file")&&!prefs.getString("file_uri","").trim().isEmpty())return "file";
        if(mode.equals("m3u")){
            String u=CredentialStore.m3uUrl(prefs).trim();
            if(!u.isEmpty())return "m3u";
        }

        // Última tentativa de recuperação sem depender de source_mode.
        if(savedXtream().valid()){
            prefs.edit().putString("source_mode","xtream").apply();
            return "xtream";
        }
        String u=CredentialStore.m3uUrl(prefs).trim();
        if(!u.isEmpty()){
            try{
                XtreamCreds x=xtreamFromM3uUrl(u);
                if(x!=null&&x.valid()){
                    prefs.edit().putString("source_mode","xtream").putString("xt_server",x.server).apply();
                    CredentialStore.save(prefs,x.user,x.pass);
                    return "xtream";
                }
            }catch(Exception ignored){}
            prefs.edit().putString("source_mode","m3u").apply();
            CredentialStore.saveM3uUrl(prefs,u);
            return "m3u";
        }
        if(!prefs.getString("file_uri","").trim().isEmpty()){
            prefs.edit().putString("source_mode","file").apply();
            return "file";
        }
        return "";
    }

    void showMissingSource(String title){
        clear(title);
        addTitle(title,24);
        TextView t=text(getString(R.string.ui_002),compact?11:14);
        t.setTextColor(MUTED); t.setGravity(Gravity.CENTER); t.setPadding(dp(18),dp(18),dp(18),dp(18));
        content.addView(t,new LinearLayout.LayoutParams(-1,dp(compact?110:130)));
        Button b=button(getString(R.string.ui_003)); b.setTextColor(GOLD); b.setOnClickListener(v->showPlaylistManager());
        content.addView(b,new LinearLayout.LayoutParams(-1,dp(56)));
    }

    void build(){
        setContentView(R.layout.activity_main); root=findViewById(R.id.main_root);
        boolean hasSource=!resolveSourceMode().isEmpty();
        if(hasSource){
            buildNav(); buildMain(); showHome();
            // Enquanto o usuário vê o Início, aquece TV/Filmes/Séries em segundo plano.
            root.postDelayed(this::prewarmAllSections,1800);
        }else{
            // Primeiro uso: exibe apenas o código/PIN. A Home real abre depois que
            // o cliente vincula sua lista pelo portal de ativação.
            showActivationScreen();
        }
    }

    void showActivationScreen(){
        activationPolling=true;
        activationClient=new DeviceActivationClient(this);
        LinearLayout screen=new LinearLayout(this);screen.setOrientation(LinearLayout.HORIZONTAL);
        screen.setGravity(Gravity.CENTER);screen.setPadding(dp(compact?28:64),dp(24),dp(compact?28:64),dp(24));screen.setBackgroundColor(BG);

        LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);brand.setGravity(Gravity.CENTER);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.aureon_logo);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        brand.addView(logo,new LinearLayout.LayoutParams(dp(compact?210:300),dp(compact?150:220)));
        TextView welcome=text("BEM-VINDO AO ÁUREON",compact?18:25);welcome.setTextColor(GOLD);welcome.setTypeface(null,1);welcome.setGravity(Gravity.CENTER);
        brand.addView(welcome,new LinearLayout.LayoutParams(-1,dp(56)));
        TextView copy=text("Conecte sua lista pelo celular ou computador.\nEsta tela será atualizada automaticamente.",compact?11:15);
        copy.setTextColor(MUTED);copy.setGravity(Gravity.CENTER);brand.addView(copy,new LinearLayout.LayoutParams(-1,dp(74)));
        screen.addView(brand,new LinearLayout.LayoutParams(0,-1,.44f));

        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER);
        card.setPadding(dp(compact?30:46),dp(20),dp(compact?30:46),dp(20));card.setBackground(box(PANEL,22,Color.rgb(92,70,28),1));
        TextView step=text("ATIVAR ESTE APARELHO",compact?13:18);step.setTextColor(GOLD);step.setTypeface(null,1);step.setGravity(Gravity.CENTER);
        card.addView(step,new LinearLayout.LayoutParams(-1,dp(42)));
        final String activationUrl="https://ativar-aureon-tv.maycontorres1995.chatgpt.site";
        TextView site=text("Leia o QR Code com o celular\nou digite o endereço mostrado abaixo",compact?11:16);site.setTextColor(WHITE);site.setGravity(Gravity.CENTER);
        card.addView(site,new LinearLayout.LayoutParams(-1,dp(compact?56:70)));
        ImageView activationQr=new ImageView(this);activationQr.setScaleType(ImageView.ScaleType.FIT_CENTER);
        Bitmap activationBitmap=makeQrBitmap(activationUrl,compact?220:300);
        if(activationBitmap!=null)activationQr.setImageBitmap(activationBitmap);
        card.addView(activationQr,new LinearLayout.LayoutParams(-1,dp(compact?96:125)));
        TextView portalAddress=text("ativar-aureon-tv.maycontorres1995.chatgpt.site",compact?8:10);
        portalAddress.setTextColor(MUTED);portalAddress.setGravity(Gravity.CENTER);
        card.addView(portalAddress,new LinearLayout.LayoutParams(-1,dp(24)));

        TextView codeLabel=text("CÓDIGO DO APARELHO",compact?10:12);codeLabel.setTextColor(MUTED);codeLabel.setGravity(Gravity.CENTER);
        card.addView(codeLabel,new LinearLayout.LayoutParams(-1,dp(28)));
        TextView code=text(DeviceKeyUtil.key(this),compact?25:36);code.setTextColor(GOLD);code.setTypeface(null,1);code.setGravity(Gravity.CENTER);
        code.setLetterSpacing(.12f);code.setBackground(box(Color.rgb(8,8,9),14,Color.rgb(80,63,25),1));
        card.addView(code,new LinearLayout.LayoutParams(-1,dp(compact?62:78)));

        TextView pinLabel=text("PIN DE 6 NÚMEROS",compact?10:12);pinLabel.setTextColor(MUTED);pinLabel.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams plp=new LinearLayout.LayoutParams(-1,dp(30));plp.topMargin=dp(12);card.addView(pinLabel,plp);
        TextView pin=text(DeviceKeyUtil.pin(this),compact?24:34);pin.setTextColor(WHITE);pin.setTypeface(null,1);pin.setGravity(Gravity.CENTER);pin.setLetterSpacing(.2f);
        card.addView(pin,new LinearLayout.LayoutParams(-1,dp(54)));
        status=text("Conectando ao servidor…",compact?10:13);status.setTextColor(MUTED);status.setGravity(Gravity.CENTER);
        card.addView(status,new LinearLayout.LayoutParams(-1,dp(44)));
        Button manual=button("Adicionar lista diretamente neste aparelho");
        manual.setOnClickListener(v->{activationPolling=false;uiHandler.removeCallbacks(activationPollTask);setContentView(R.layout.activity_main);root=findViewById(R.id.main_root);buildMain();showPlaylistManager();});
        card.addView(manual,new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-1,.56f);cp.setMargins(dp(20),0,0,0);screen.addView(card,cp);
        setContentView(screen);

        activationClient.register(new DeviceActivationClient.Listener(){
            public void onResult(JSONObject ignored){runOnUiThread(()->{if(status!=null)status.setText("Aguardando a lista…");uiHandler.removeCallbacks(activationPollTask);uiHandler.post(activationPollTask);});}
            public void onError(String message){runOnUiThread(()->{if(status!=null)status.setText(message+" Tentando novamente…");uiHandler.removeCallbacks(activationPollTask);uiHandler.postDelayed(activationPollTask,ACTIVATION_POLL_MS);});}
        });
    }

    void pollActivation(){
        if(!activationPolling||activationClient==null||isFinishing()||isDestroyed())return;
        activationClient.sync(new DeviceActivationClient.Listener(){
            public void onResult(JSONObject result){runOnUiThread(()->{
                if(!activationPolling)return;
                JSONObject playlist=result.optJSONObject("playlist");
                if("active".equals(result.optString("status"))&&playlist!=null&&applyRemotePlaylist(playlist)){
                    activationPolling=false;uiHandler.removeCallbacks(activationPollTask);
                    Toast.makeText(MainActivity.this,"Lista conectada com sucesso!",Toast.LENGTH_LONG).show();build();return;
                }
                if(status!=null)status.setText("Aguardando você concluir no site…");
                uiHandler.postDelayed(activationPollTask,ACTIVATION_POLL_MS);
            });}
            public void onError(String message){runOnUiThread(()->{if(status!=null)status.setText(message+" Tentando novamente…");uiHandler.postDelayed(activationPollTask,ACTIVATION_POLL_MS);});}
        });
    }

    boolean applyRemotePlaylist(JSONObject playlist){
        try{
            String mode=playlist.optString("mode","");
            String name=playlist.optString("playlist_name","Minha lista");
            CredentialStore.clearAllSourceSecrets(prefs);
            SharedPreferences.Editor edit=prefs.edit().putString("playlist_name",name).putString("file_uri","");
            if("xtream".equals(mode)){
                String server=playlist.optString("server_url",""),user=playlist.optString("username",""),pass=playlist.optString("password","");
                if(server.isEmpty()||user.isEmpty()||pass.isEmpty())return false;
                edit.putString("source_mode","xtream").putString("xt_server",server).apply();CredentialStore.save(prefs,user,pass);
            }else if("m3u".equals(mode)){
                String url=playlist.optString("m3u_url","");if(url.isEmpty())return false;
                edit.putString("source_mode","m3u").putString("xt_server","").apply();CredentialStore.saveM3uUrl(prefs,url);
            }else return false;
            CredentialStore.saveEpgUrl(prefs,playlist.optString("epg_url",""));
            playlistCache.clear();invalidateSectionCaches();return true;
        }catch(Exception e){return false;}
    }

    void buildNav(){
        navScroll=new ScrollView(this); navScroll.setFillViewport(true); navScroll.setVerticalScrollBarEnabled(false); navScroll.setBackgroundColor(Color.rgb(4,6,8));
        nav=new LinearLayout(this); nav.setOrientation(LinearLayout.VERTICAL); navScroll.addView(nav,new ScrollView.LayoutParams(-1,-2));
        root.addView(navScroll,new LinearLayout.LayoutParams(dp(navWidth),-1));
        renderNav();
    }

    void renderNav(){
        if(nav==null)return;
        nav.removeAllViews();
        nav.setPadding(dp(navCollapsed?8:(compact?12:18)),dp(7),dp(navCollapsed?8:(compact?12:18)),dp(12));

        Button toggle=button(navCollapsed?"☰":"☰   Recolher");
        toggle.setTextColor(GOLD); toggle.setGravity(navCollapsed?Gravity.CENTER:Gravity.LEFT|Gravity.CENTER_VERTICAL);
        toggle.setPadding(navCollapsed?0:dp(12),0,0,0); toggle.setOnClickListener(v->toggleNav());
        nav.addView(toggle,new LinearLayout.LayoutParams(-1,dp(navCollapsed?44:42)));

        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.aureon_logo); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams lpLogo=new LinearLayout.LayoutParams(-1,dp(navCollapsed?72:(compact?116:155))); lpLogo.topMargin=dp(4); nav.addView(logo,lpLogo);

        addNavModern("⌂", "Início", this::showHome, true);
        addNavModern("▣", "TV Ao Vivo", this::showLive, false);
        addNavModern("▤", "Filmes", this::showMovies, false);
        addNavModern("▱", "Séries", this::showSeries, false);
        addNavModern("▦", "Categorias", this::showCategoriesHub, false);
        addNavModern("◉", "Rádio", this::showRadio, false);
        addNavModern("▣", "EPG (Guia)", this::showEpgGuide, false);
        addNavModern("♡", "Favoritos", this::showFavorites, false);
        addNavModern("◉", "Continue Assistindo", this::showContinueWatching, false);
        addNavModern("⌕", "Busca", this::showGlobalSearch, false);
        addNavModern("⚙", "Configurações", this::showSetup, false);
    }

    void toggleNav(){
        // No conteúdo, o menu lateral some por completo e pode ser reaberto pelo botão ☰ do topo.
        setNavHidden(true);
    }

    void setNavHidden(boolean hidden){
        navHidden=hidden;
        if(navScroll!=null) navScroll.setVisibility(hidden?View.GONE:View.VISIBLE);
        if(topMenuButton!=null) topMenuButton.setVisibility(hidden?View.VISIBLE:View.GONE);
    }

    void addNavModern(String icon,String label,Runnable action,boolean selected){
        Button b=new Button(this); b.setAllCaps(false); b.setText(navCollapsed?icon:icon+"   "+label); b.setTextSize(navCollapsed?(compact?14:17):(compact?11:14)); b.setTextColor(selected?GOLD:WHITE); b.setGravity(navCollapsed?Gravity.CENTER:Gravity.LEFT|Gravity.CENTER_VERTICAL);
        b.setPadding(navCollapsed?0:dp(compact?14:18),0,navCollapsed?0:dp(8),0); b.setMinHeight(0); b.setFocusable(true); b.setClickable(true);
        b.setBackground(box(selected?Color.rgb(61,43,13):Color.TRANSPARENT,14,selected?GOLD:Color.rgb(20,22,24),selected?1:0));
        b.setOnClickListener(v->{
            if(label.equals("Início")){ setNavHidden(false); action.run(); }
            else { setNavHidden(true); action.run(); }
        });
        b.setOnFocusChangeListener((v,has)->{ Button x=(Button)v; x.setTextColor(has?GOLD:WHITE); v.setBackground(box(has?Color.rgb(48,35,14):Color.TRANSPARENT,14,has?GOLD:Color.rgb(20,22,24),has?1:0)); });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(navCollapsed?44:(compact?43:51))); lp.bottomMargin=dp(3); nav.addView(b,lp);
    }

    void buildMain(){
        LinearLayout wrap=new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL); root.addView(wrap,new LinearLayout.LayoutParams(0,-1,1));

        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT); top.setPadding(dp(16),dp(8),dp(16),dp(6)); top.setBackgroundColor(Color.rgb(3,5,7));
        topMenuButton=button(getString(R.string.ui_004)); topMenuButton.setTextColor(GOLD); topMenuButton.setTextSize(compact?17:21); topMenuButton.setVisibility(View.GONE); topMenuButton.setOnClickListener(v->setNavHidden(false));
        LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(dp(compact?46:54),dp(compact?42:50)); mlp.rightMargin=dp(8); top.addView(topMenuButton,mlp);
        pageTitle=text(getString(R.string.ui_005),1); pageTitle.setVisibility(View.GONE); top.addView(pageTitle,new LinearLayout.LayoutParams(0,1,1));

        Button search=new Button(this); search.setAllCaps(false); search.setText("⌕   Buscar..."); search.setTextColor(WHITE); search.setTextSize(compact?10:13); search.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); search.setPadding(dp(15),0,0,0); search.setBackground(box(Color.rgb(7,9,11),13,Color.rgb(104,77,24),1)); search.setOnClickListener(v->showGlobalSearch());
        top.addView(search,new LinearLayout.LayoutParams(dp(compact?230:305),dp(compact?42:50)));

        LinearLayout clock=new LinearLayout(this); clock.setOrientation(LinearLayout.VERTICAL); clock.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); clock.setPadding(dp(18),0,dp(14),0);
        String time=new SimpleDateFormat(prefs.getBoolean("clock_24h",false)?"HH:mm":"h:mm a",Locale.getDefault()).format(new Date());
        String date=new SimpleDateFormat("EEE, dd 'de' MMM",new Locale("pt","BR")).format(new Date());
        TextView tvTime=text(time,compact?15:20); tvTime.setGravity(Gravity.RIGHT); tvTime.setTypeface(null,1); clock.addView(tvTime,new LinearLayout.LayoutParams(-1,dp(compact?23:28)));
        TextView tvDate=text(date,compact?8:11); tvDate.setGravity(Gravity.RIGHT); tvDate.setTextColor(MUTED); clock.addView(tvDate,new LinearLayout.LayoutParams(-1,dp(compact?18:22)));
        top.addView(clock,new LinearLayout.LayoutParams(dp(compact?150:190),dp(compact?48:56)));

        Button profile=new Button(this); profile.setText("●"); profile.setTextColor(Color.LTGRAY); profile.setTextSize(compact?17:22); profile.setBackground(box(Color.rgb(11,12,14),30,GOLD,1)); profile.setOnClickListener(v->showSetup()); top.addView(profile,new LinearLayout.LayoutParams(dp(compact?46:58),dp(compact?46:58)));
        wrap.addView(top,new LinearLayout.LayoutParams(-1,dp(compact?62:72)));

        contentScroll=new ScrollView(this); contentScroll.setFillViewport(true); contentScroll.setVerticalScrollBarEnabled(false);
        // Não deixa o ScrollView externo capturar o foco invisivelmente na TV.
        contentScroll.setFocusable(false); contentScroll.setFocusableInTouchMode(false);
        contentScroll.setDescendantFocusability(android.view.ViewGroup.FOCUS_AFTER_DESCENDANTS);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(compact?12:20),dp(8),dp(compact?12:20),dp(24));
        contentScroll.addView(content); wrap.addView(contentScroll,new LinearLayout.LayoutParams(-1,0,1));
    }

    void clear(String title){
        activeScreen=title==null?"":title;
        if(!"Início".equals(activeScreen))lastBackPressAt=0L;
        pendingFeatured=null;
        releasePreviewPlayer();
        content.removeAllViews(); pageTitle.setText(title); browserList=null; browserRecycler=null; mediaRecycler=null; browserResultCount=null; channelRecyclerAdapter=null; mediaRecyclerAdapter=null; liveCategoryColumn=null; categoryColumn=null; categorySearch=null; if(contentScroll!=null) contentScroll.post(() -> contentScroll.scrollTo(0,0));
    }

    void releasePreviewPlayer(){
        uiHandler.removeCallbacks(browserPreviewTask);
        pendingBrowserPreview=null;
        if(previewPlayerView!=null) previewPlayerView.setPlayer(null);
        if(previewPlayer!=null){ try{previewPlayer.release();}catch(Exception ignored){} }
        previewPlayer=null; previewPlayerView=null; previewEntry=null; browserPreviewHint=null; browserFavoriteButton=null; liveEpgContainer=null;
    }


    void addTitle(String s,float size){
        TextView t=text(s,compact?Math.max(14,size-2):size); t.setTypeface(null,1); t.setTextColor(WHITE); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(size>22?40:34)); p.topMargin=dp(4); content.addView(t,p);
    }

    void showHome(){ currentSectionRequest=-1; detailScreenKind=-1; restoreKind=-1;
        setNavHidden(false);
        clear(getString(R.string.ui_006));

        LinearLayout first=new LinearLayout(this); first.setOrientation(LinearLayout.HORIZONTAL); first.setGravity(Gravity.CENTER_VERTICAL);
        ImageView hero=new ImageView(this); hero.setImageResource(R.drawable.hero_home); hero.setScaleType(ImageView.ScaleType.CENTER_CROP); hero.setBackground(box(Color.rgb(10,10,10),14,GOLD,1)); hero.setClickable(true); hero.setFocusable(true); hero.setContentDescription("John Wick 4 — abrir detalhes"); hero.setOnClickListener(v->openFeatured(new FeaturedTitle(MOVIE,"John Wick 4","John Wick: Chapter 4","John Wick 4: Baba Yaga")));
        // O banner ocupa toda a largura disponível. A navegação continua no menu lateral.
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(0,dp(compact?196:268),1f);
        first.addView(hero,hp);
        content.addView(first,new LinearLayout.LayoutParams(-1,dp(compact?196:268)));

        List<MediaEntry> cw=PlaybackStore.continueWatching(this,10);
        if(!cw.isEmpty()) addDynamicMediaStrip("Continue Assistindo",cw,this::showContinueWatching,compact?126:168);

        SectionData movieData=cachedSection(MOVIE,true);
        if(movieData!=null&&!movieData.items.isEmpty()) addDynamicMediaStrip("Filmes adicionados recentemente",latestEntries(movieData.items,10),this::showMovies,compact?138:190);
        else addFeaturedStrip("Filmes em Destaque",R.drawable.featured_films,this::showMovies,compact?138:190,new FeaturedTitle[]{
            new FeaturedTitle(MOVIE,"Deadpool & Wolverine","Deadpool e Wolverine","Deadpool and Wolverine"),
            new FeaturedTitle(MOVIE,"Divertida Mente 2","Divertidamente 2","Inside Out 2"),
            new FeaturedTitle(MOVIE,"Bad Boys Até o Fim","Bad Boys: Ride or Die","Bad Boys 4"),
            new FeaturedTitle(MOVIE,"Duna: Parte 2","Duna: Parte Dois","Dune: Part Two","Dune: Part 2"),
            new FeaturedTitle(MOVIE,"Godzilla e Kong: O Novo Império","Godzilla x Kong: The New Empire","Godzilla x Kong: O Novo Império"),
            new FeaturedTitle(MOVIE,"Kung Fu Panda 4"),
            new FeaturedTitle(MOVIE,"Planeta dos Macacos: O Reinado","Kingdom of the Planet of the Apes")
        });

        SectionData seriesData=cachedSection(SERIES,true);
        if(seriesData!=null&&!seriesData.items.isEmpty()) addDynamicMediaStrip("Séries adicionadas recentemente",latestEntries(seriesData.items,10),this::showSeries,compact?126:172);
        else addFeaturedStrip("Séries em Destaque",R.drawable.featured_series,this::showSeries,compact?126:172,new FeaturedTitle[]{
            new FeaturedTitle(SERIES,"The Last of Us"),new FeaturedTitle(SERIES,"Fallout"),
            new FeaturedTitle(SERIES,"House of the Dragon","A Casa do Dragão"),
            new FeaturedTitle(SERIES,"A Casa do Dragão","House of the Dragon"),
            new FeaturedTitle(SERIES,"Reacher"),new FeaturedTitle(SERIES,"The Boys"),
            new FeaturedTitle(SERIES,"Round 6","Squid Game"),new FeaturedTitle(SERIES,"Breaking Bad","Breaking Bad: A Química do Mal")
        });
        addPreviewStrip("Canais Ao Vivo",R.drawable.featured_live,this::showLive,compact?92:112);
    }

    String homeCountSub(int kind,String label){
        SectionData d=cachedSection(kind,true); int count=d==null?-1:d.items.size();
        if(count<0){String key=currentSourceCacheKey(); if(!key.isEmpty())count=CatalogCache.peekCount(this,key,kind);}
        if(count<0)return kind==LIVE?"CANAIS":label;
        return String.format(Locale.US,"%,d %s",count,label);
    }

    List<MediaEntry> latestEntries(List<MediaEntry> source,int limit){
        ArrayList<MediaEntry> out=new ArrayList<>();for(MediaEntry e:source)if(contentAllowed(e))out.add(e);Collections.sort(out,(a,b)->compareAdded(b,a));
        if(out.size()>limit)return new ArrayList<>(out.subList(0,limit)); return out;
    }

    void addDynamicMediaStrip(String title,List<MediaEntry> entries,Runnable all,int height){
        if(entries==null||entries.isEmpty())return;
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t=text(title,compact?14:19);t.setTypeface(null,1);head.addView(t,new LinearLayout.LayoutParams(0,dp(34),1));
        TextView more=text(getString(R.string.ui_007),compact?9:12);more.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);more.setTextColor(Color.LTGRAY);more.setFocusable(true);more.setClickable(true);more.setOnClickListener(v->all.run());head.addView(more,new LinearLayout.LayoutParams(dp(compact?90:120),dp(34)));content.addView(head,new LinearLayout.LayoutParams(-1,dp(36)));
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);hsv.setFocusable(false);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(0,0,dp(8),0);hsv.addView(row,new HorizontalScrollView.LayoutParams(-2,-1));
        int cardW=compact?100:132, posterH=Math.max(90,height-42);
        final ArrayList<MediaEntry> stripItems=new ArrayList<>(entries);
        for(MediaEntry e:entries){LinearLayout card=makePosterCard(e,cardW,posterH);card.setOnClickListener(v->{detailNavItems=new ArrayList<>(stripItems);if(e.kind==LIVE)showLiveDetails(e);else if(e.url!=null&&!e.url.isEmpty()&&e.group!=null&&e.group.toLowerCase(Locale.US).startsWith("temporada")){setPlayerQueue(stripItems,e);play(e);}else showMediaDetails(e);});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(cardW),dp(height));lp.rightMargin=dp(8);row.addView(card,lp);}
        content.addView(hsv,new LinearLayout.LayoutParams(-1,dp(height+4)));
    }

    void addHomeQuick(LinearLayout row,String icon,String title,String sub,Runnable action){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(compact?12:16),dp(7),dp(10),dp(7)); card.setBackground(box(Color.rgb(10,11,12),14,Color.rgb(93,69,22),1)); card.setClickable(true); card.setFocusable(true); card.setOnClickListener(v->action.run());
        TextView ic=text(icon,compact?23:31); ic.setTextColor(GOLD); ic.setGravity(Gravity.CENTER); card.addView(ic,new LinearLayout.LayoutParams(dp(compact?48:64),-1));
        LinearLayout labels=new LinearLayout(this); labels.setOrientation(LinearLayout.VERTICAL); labels.setGravity(Gravity.CENTER_VERTICAL);
        TextView h=text(title,compact?11:16); h.setTypeface(null,1); labels.addView(h,new LinearLayout.LayoutParams(-1,dp(compact?25:32)));
        TextView s=text(sub,compact?8:11); s.setTextColor(WHITE); labels.addView(s,new LinearLayout.LayoutParams(-1,dp(compact?20:24)));
        card.addView(labels,new LinearLayout.LayoutParams(0,-1,1));
        card.setOnFocusChangeListener((v,has)->v.setBackground(box(has?Color.rgb(38,29,13):Color.rgb(10,11,12),14,has?GOLD:Color.rgb(93,69,22),1)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); p.leftMargin=dp(4); p.rightMargin=dp(4); row.addView(card,p);
    }

    void addPreviewStrip(String title,int drawable,Runnable action,int h){
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL); TextView t=text(title,compact?14:19); t.setTypeface(null,1); head.addView(t,new LinearLayout.LayoutParams(0,dp(34),1)); TextView more=text(getString(R.string.ui_007),compact?9:12); more.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); more.setTextColor(Color.LTGRAY); head.addView(more,new LinearLayout.LayoutParams(dp(compact?90:120),dp(34))); content.addView(head,new LinearLayout.LayoutParams(-1,dp(36)));
        ImageView strip=new ImageView(this); strip.setImageResource(drawable); strip.setScaleType(ImageView.ScaleType.CENTER_CROP); strip.setBackground(box(Color.rgb(8,8,9),10,Color.rgb(70,52,18),1)); strip.setClickable(true); strip.setFocusable(true); strip.setOnClickListener(v->action.run()); content.addView(strip,new LinearLayout.LayoutParams(-1,dp(h)));
        more.setFocusable(true); more.setOnClickListener(v->action.run());
    }

    static class FeaturedTitle {
        final int kind;
        final String title;
        final String[] aliases;
        final Set<String> normalizedAliases=new LinkedHashSet<>();
        FeaturedTitle(int kind,String title,String... otherNames){
            this.kind=kind; this.title=title;
            aliases=new String[otherNames.length+1]; aliases[0]=title;
            System.arraycopy(otherNames,0,aliases,1,otherNames.length);
            for(String alias:aliases)normalizedAliases.add(FeaturedMatcher.normalize(alias));
        }
    }

    void addFeaturedStrip(String title,int drawable,Runnable all,int height,FeaturedTitle[] titles){
        // Preserve the original artwork and its CENTER_CROP geometry. Only add individual hit targets.
        addPreviewStrip(title,drawable,all,height);
        View original=content.getChildAt(content.getChildCount()-1);
        content.removeView(original);
        original.setClickable(false); original.setFocusable(false);
        BitmapFactory.Options bounds=new BitmapFactory.Options(); bounds.inJustDecodeBounds=true;
        BitmapFactory.decodeResource(getResources(),drawable,bounds);
        FrameLayout strip=new FrameLayout(this){
            @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){
                super.onSizeChanged(w,h,oldw,oldh);
                float scale=Math.max((float)w/bounds.outWidth,(float)h/bounds.outHeight);
                float scaledWidth=bounds.outWidth*scale, offset=Math.round((w-scaledWidth)/2f);
                for(int i=0;i<titles.length;i++){
                    int left=Math.max(0,Math.round(offset+scaledWidth*i/titles.length));
                    int right=Math.min(w,Math.round(offset+scaledWidth*(i+1)/titles.length));
                    View target=getChildAt(i+1);
                    FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Math.max(0,right-left),h);
                    lp.leftMargin=left; target.setLayoutParams(lp);
                    target.setVisibility(right>left?View.VISIBLE:View.GONE);
                }
            }
        };
        strip.addView(original,new FrameLayout.LayoutParams(-1,-1));
        for(FeaturedTitle item:titles){
            View target=new View(this); target.setFocusable(true); target.setClickable(true);
            target.setContentDescription(item.title+" — abrir detalhes");
            target.setOnClickListener(v->openFeatured(item));
            target.setOnFocusChangeListener((v,has)->v.setBackground(has?box(Color.TRANSPARENT,10,GOLD,2):null));
            strip.addView(target,new FrameLayout.LayoutParams(0,-1));
        }
        content.addView(strip,new LinearLayout.LayoutParams(-1,dp(height)));
    }

    void openFeatured(FeaturedTitle title){
        currentSectionRequest=-1;
        String mode=resolveSourceMode();
        if(mode.isEmpty()){ showMissingSource(title.title); return; }
        SectionData data=cachedSection(title.kind,true);
        if(data!=null){ showFeaturedMatch(title,data); return; }
        clear(title.title); setNavHidden(true);
        TextView loading=text(getString(R.string.ui_008)+title.title+" na sua playlist…",15);
        loading.setGravity(Gravity.CENTER); loading.setTextColor(MUTED);
        content.addView(loading,new LinearLayout.LayoutParams(-1,dp(110)));
        pendingFeatured=title;
        // Reuse any catalog request already started by background prewarming.
        fetchSectionAsync(title.kind,mode,false);
    }

    void showFeaturedMatch(FeaturedTitle title,SectionData data){
        clear(title.title); setNavHidden(true);
        TextView loading=text(getString(R.string.ui_008)+title.title+" na sua playlist…",15);
        loading.setGravity(Gravity.CENTER); loading.setTextColor(MUTED);
        content.addView(loading,new LinearLayout.LayoutParams(-1,dp(110)));
        dataExec.submit(()->{
            ArrayList<MediaEntry> matches=new ArrayList<>();
            for(MediaEntry e:data.items){
                if(e.kind==title.kind && title.normalizedAliases.contains(FeaturedMatcher.normalize(e.name)))matches.add(e);
            }
            runOnUiThread(()->{
                if(loading.getParent()==content && data.sourceKey.equals(currentSourceCacheKey()))renderFeaturedMatches(title,data,matches);
            });
        });
    }

    void renderFeaturedMatches(FeaturedTitle title,SectionData data,List<MediaEntry> matches){
        if(matches.size()==1){
            detailNavItems=new ArrayList<>(data.items);
            showMediaDetails(matches.get(0)); return;
        }
        clear(title.title); setNavHidden(true); addTitle(title.title,24);
        TextView message=text(matches.isEmpty()?"Este título não foi encontrado na sua playlist.":"Escolha a versão disponível na sua playlist:",compact?12:15);
        message.setTextColor(MUTED); content.addView(message,new LinearLayout.LayoutParams(-1,dp(64)));
        for(MediaEntry e:matches){
            Button option=button(e.name+(e.group==null||e.group.isEmpty()?"":" • "+e.group));
            option.setOnClickListener(v->{detailNavItems=new ArrayList<>(data.items);showMediaDetails(e);});
            content.addView(option,new LinearLayout.LayoutParams(-1,dp(54)));
        }
        Button back=button(getString(R.string.ui_009)); back.setOnClickListener(v->showHome());
        content.addView(back,new LinearLayout.LayoutParams(-1,dp(52)));
    }

    void showGlobalSearch(){ currentSectionRequest=-1;
        setNavHidden(true); clear(getString(R.string.ui_010)); addTitle(getString(R.string.ui_011),24);
        TextView sub=text(getString(R.string.ui_012),compact?10:13);sub.setTextColor(MUTED);content.addView(sub,new LinearLayout.LayoutParams(-1,dp(36)));
        EditText search=field(getString(R.string.ui_013),"");content.addView(search,new LinearLayout.LayoutParams(-1,dp(52)));
        LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(10);content.addView(results,rp);
        final Runnable[] pending={null};
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void afterTextChanged(Editable e){} public void onTextChanged(CharSequence cs,int st,int b,int c){
            if(pending[0]!=null)uiHandler.removeCallbacks(pending[0]); String q=cs.toString().trim();
            pending[0]=()->runGlobalSearch(q,results); uiHandler.postDelayed(pending[0],280);
        }});
        TextView hint=text(getString(R.string.ui_014),compact?11:14);hint.setTextColor(MUTED);hint.setGravity(Gravity.CENTER);results.addView(hint,new LinearLayout.LayoutParams(-1,dp(90)));
        search.postDelayed(search::requestFocus,180);
    }

    void runGlobalSearch(String query,LinearLayout results){
        results.removeAllViews(); if(query==null||query.trim().length()<2){TextView h=text(getString(R.string.ui_014),compact?11:14);h.setTextColor(MUTED);h.setGravity(Gravity.CENTER);results.addView(h,new LinearLayout.LayoutParams(-1,dp(90)));return;}
        TextView loading=text(getString(R.string.ui_015),compact?11:14);loading.setTextColor(MUTED);loading.setGravity(Gravity.CENTER);results.addView(loading,new LinearLayout.LayoutParams(-1,dp(80)));
        final String q=query.toLowerCase(Locale.US);
        dataExec.submit(()->{
            ArrayList<MediaEntry> matches=new ArrayList<>(); LinkedHashMap<Integer,SectionData> sourceByKind=new LinkedHashMap<>();
            try{
                for(int kind=LIVE;kind<=SERIES;kind++){
                    SectionData d=ensureSectionSync(kind); if(d==null)continue; sourceByKind.put(kind,d);
                    for(MediaEntry e:d.items){if(e!=null&&contentAllowed(e)&&e.name!=null&&e.name.toLowerCase(Locale.US).contains(q)){matches.add(e);if(matches.size()>=80)break;}}
                    if(matches.size()>=80)break;
                }
            }catch(Exception ignored){}
            runOnUiThread(()->{
                results.removeAllViews(); if(matches.isEmpty()){TextView none=text(getString(R.string.ui_016),compact?11:14);none.setTextColor(MUTED);none.setGravity(Gravity.CENTER);results.addView(none,new LinearLayout.LayoutParams(-1,dp(90)));return;}
                TextView count=text(matches.size()+" resultado(s)",compact?10:12);count.setTextColor(MUTED);results.addView(count,new LinearLayout.LayoutParams(-1,dp(34)));
                for(MediaEntry e:matches){String type=e.kind==LIVE?"TV":e.kind==MOVIE?"FILME":"SÉRIE";Button b=button(type+"  •  "+e.name);b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setPadding(dp(15),0,dp(10),0);b.setOnClickListener(v->{SectionData d=sourceByKind.get(e.kind);detailNavItems=d==null?new ArrayList<>():new ArrayList<>(d.items);if(e.kind==LIVE)showLiveDetails(e);else showMediaDetails(e);});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.bottomMargin=dp(5);results.addView(b,lp);}
            });
        });
    }

    SectionData ensureSectionSync(int kind) throws Exception{
        SectionData d=cachedSection(kind,true); if(d!=null)return d; String mode=resolveSourceMode(); if(mode.isEmpty())return null; String sourceKey=currentSourceCacheKey();
        CatalogCache.CachedCatalog disk=CatalogCache.load(this,sourceKey,kind); if(disk!=null&&!disk.items.isEmpty()){d=new SectionData(disk.items,disk.categories,disk.loadedAt,sourceKey);storeSection(kind,d);return d;}
        d=fetchSectionData(kind,mode,sourceKey);storeSection(kind,d);saveCatalogAsync(kind,d);return d;
    }

    void showFavorites(){ currentSectionRequest=-1; setNavHidden(true); clear(getString(R.string.ui_017)); addTitle(getString(R.string.ui_017),24); List<MediaEntry> all=PlaybackStore.favorites(this); showStoredEntries("Seus favoritos",all); }
    void showContinueWatching(){ currentSectionRequest=-1; setNavHidden(true); clear(getString(R.string.ui_018)); addTitle(getString(R.string.ui_018),24); showStoredEntries("Retome de onde parou",PlaybackStore.continueWatching(this,100)); }

    void showStoredEntries(String subtitle,List<MediaEntry> entries){
        TextView sub=text(subtitle,compact?10:13);sub.setTextColor(MUTED);content.addView(sub,new LinearLayout.LayoutParams(-1,dp(36)));
        if(entries==null||entries.isEmpty()){TextView none=text(getString(R.string.ui_019),compact?12:15);none.setTextColor(MUTED);none.setGravity(Gravity.CENTER);content.addView(none,new LinearLayout.LayoutParams(-1,dp(110)));return;}
        final ArrayList<MediaEntry> navItems=new ArrayList<>(entries);
        for(MediaEntry e:entries){
            Button b=button((e.kind==LIVE?"▣  ":e.kind==MOVIE?"▤  ":"▱  ")+(e.name==null?"Conteúdo":e.name));b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setPadding(dp(15),0,dp(10),0);
            b.setOnClickListener(v->{detailNavItems=new ArrayList<>(navItems);if(e.kind==LIVE)showLiveDetails(e);else if(e.url!=null&&!e.url.isEmpty()&&e.group!=null&&e.group.toLowerCase(Locale.US).startsWith("temporada")){setPlayerQueue(navItems,e);play(e);}else showMediaDetails(e);});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.bottomMargin=dp(5);content.addView(b,lp);
        }
    }

    void showRadio(){ currentSectionRequest=-1; setNavHidden(true); clear(getString(R.string.ui_020)); addTitle(getString(R.string.ui_020),24); TextView loading=text(getString(R.string.ui_021),compact?11:14);loading.setTextColor(MUTED);loading.setGravity(Gravity.CENTER);content.addView(loading,new LinearLayout.LayoutParams(-1,dp(90)));
        dataExec.submit(()->{ArrayList<MediaEntry> radios=new ArrayList<>();try{SectionData d=ensureSectionSync(LIVE);if(d!=null)for(MediaEntry e:d.items){String z=((e.group==null?"":e.group)+" "+(e.name==null?"":e.name)).toLowerCase(Locale.US);if(z.contains("radio")||z.contains("rádio")||z.contains("fm ")||z.endsWith(" fm"))radios.add(e);}}catch(Exception ignored){}runOnUiThread(()->{clear(getString(R.string.ui_020));addTitle(getString(R.string.ui_020),24);if(radios.isEmpty()){TextView none=text(getString(R.string.ui_022),compact?11:14);none.setTextColor(MUTED);none.setGravity(Gravity.CENTER);content.addView(none,new LinearLayout.LayoutParams(-1,dp(100)));}else showBrowser("Rádio",radios,LIVE);});});
    }

    void showEpgGuide(){
        currentSectionRequest=-1;
        startActivity(new Intent(this,EpgGuideActivity.class));
    }

    void showCategoriesHub(){ currentSectionRequest=-1;
        clear(getString(R.string.ui_028)); addTitle(getString(R.string.ui_029),22); Button live=button(getString(R.string.ui_030)); live.setOnClickListener(v->showLive()); content.addView(live,new LinearLayout.LayoutParams(-1,dp(56)));
        Button mov=button(getString(R.string.ui_031)); mov.setOnClickListener(v->showMovies()); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(56)); p.topMargin=dp(8); content.addView(mov,p);
        Button ser=button(getString(R.string.ui_032)); ser.setOnClickListener(v->showSeries()); LinearLayout.LayoutParams p2=new LinearLayout.LayoutParams(-1,dp(56)); p2.topMargin=dp(8); content.addView(ser,p2);
    }

    void showSetup(){ currentSectionRequest=-1;
        setNavHidden(true); clear(getString(R.string.ui_033)); addTitle(getString(R.string.ui_033),24);
        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        addSettingsRow(grid,"▣","Adicionar / Trocar Playlist",this::showPlaylistManager,"◫","Chave do Dispositivo",this::showDeviceCode);
        addSettingsRow(grid,"↻","Atualizar Catálogos",this::refreshCatalogs,"⌫","Limpar Cache",this::clearAppCache);
        addSettingsRow(grid,"◉","Ocultar conteúdo adulto: "+onOff(prefs.getBoolean("hide_adult",false)),()->toggleBooleanSetting("hide_adult"),"▶","Autoplay TV: "+onOff(prefs.getBoolean("autoplay_live",true)),()->toggleBooleanSetting("autoplay_live"));
        addSettingsRow(grid,"◷","Retomar filmes/séries: "+onOff(prefs.getBoolean("resume_vod",true)),()->toggleBooleanSetting("resume_vod"),"◷","Relógio 24h: "+onOff(prefs.getBoolean("clock_24h",false)),()->toggleBooleanSetting("clock_24h"));
        addSettingsRow(grid,"⌫","Limpar histórico de TV",()->clearHistoryKind(LIVE),"⌫","Limpar histórico de Filmes",()->clearHistoryKind(MOVIE));
        addSettingsRow(grid,"⌫","Limpar histórico de Séries",()->clearHistoryKind(SERIES),"⌫","Limpar todo histórico",()->{PlaybackStore.clearAllHistory(this);showInfo("Histórico e pontos de reprodução removidos.");});
        addSettingsRow(grid,"▣","Guia EPG em grade + Catch-up",this::showEpgGuide,"♡","Abrir Favoritos",this::showFavorites);
        addSettingsRow(grid,"👥","Perfis / Playlists",()->startActivity(new Intent(this,ProfilesActivity.class)),"⚡","Teste de velocidade",()->startActivity(new Intent(this,SpeedTestActivity.class)));
        addSettingsRow(grid,"🔐","Controle parental: "+onOff(ParentalControl.enabled(this)),this::toggleParental,"↻","Atualização automática: "+onOff(prefs.getBoolean("auto_refresh",true)),this::toggleAutoRefresh);
        addSettingsRow(grid,"🔒",BuildConfig.ALLOW_CLEARTEXT?"Rede: Compatibilidade HTTP/HTTPS":"Rede: Seguro HTTPS",this::showTransportInfo,"⚕","Diagnóstico de falhas",this::showDiagnostics);
        content.addView(grid,new LinearLayout.LayoutParams(-1,-2));
        TextView dev=text(getString(R.string.ui_034)+DeviceKeyUtil.key(this)+" • v"+BuildConfig.VERSION_NAME,compact?10:13);dev.setTextColor(MUTED);dev.setGravity(Gravity.CENTER);LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(42));mp.topMargin=dp(8);content.addView(dev,mp);
    }

    void toggleParental(){ if(ParentalControl.enabled(this))ParentalControl.disable(this,this::showSetup);else ParentalControl.setup(this,this::showSetup); }
    void toggleAutoRefresh(){prefs.edit().putBoolean("auto_refresh",!prefs.getBoolean("auto_refresh",true)).apply();scheduleAutoRefresh();showSetup();}
    void scheduleAutoRefresh(){
        try{
            androidx.work.WorkManager wm=androidx.work.WorkManager.getInstance(getApplicationContext());
            if(!prefs.getBoolean("auto_refresh",true)){wm.cancelUniqueWork("aureon_catalog_refresh");return;}
            androidx.work.Constraints c=new androidx.work.Constraints.Builder().setRequiredNetworkType(androidx.work.NetworkType.CONNECTED).build();
            androidx.work.PeriodicWorkRequest req=new androidx.work.PeriodicWorkRequest.Builder(CatalogRefreshWorker.class,4,java.util.concurrent.TimeUnit.HOURS).setConstraints(c).build();
            wm.enqueueUniquePeriodicWork("aureon_catalog_refresh",androidx.work.ExistingPeriodicWorkPolicy.UPDATE,req);
        }catch(Exception ignored){}
    }
    void runProtectedCategory(String group,Runnable action){if(adultText(group)&&ParentalControl.enabled(this))ParentalControl.unlock(this,action);else action.run();}

    void showTransportInfo(){
        String msg=BuildConfig.ALLOW_CLEARTEXT
                ? "Esta edição aceita HTTP para compatibilidade com servidores antigos. Prefira HTTPS sempre que o provedor oferecer suporte."
                : "Esta edição bloqueia HTTP e aceita somente HTTPS para proteger usuário, senha e tokens durante o transporte.";
        showInfo(msg);
    }

    void showDiagnostics(){
        java.io.File latest=AppCrashReporter.latest(this);
        String msg=latest==null
                ? "Nenhuma falha registrada neste aparelho. Versão "+BuildConfig.VERSION_NAME+" • "+getString(R.string.transport_mode)
                : "Última falha local: "+new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date(latest.lastModified()))+". O relatório não inclui credenciais em texto aberto.";
        showInfo(msg);
    }

    void addSettingsRow(LinearLayout grid,String i1,String l1,Runnable a1,String i2,String l2,Runnable a2){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);addSettingsTile(row,i1,l1,a1);addSettingsTile(row,i2,l2,a2);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(compact?64:76));rp.bottomMargin=dp(8);grid.addView(row,rp);
    }
    String onOff(boolean v){return v?"Ligado":"Desligado";}
    void toggleBooleanSetting(String key){prefs.edit().putBoolean(key,!prefs.getBoolean(key,false)).apply();showSetup();}
    void clearHistoryKind(int kind){PlaybackStore.clearRecents(this,kind);showInfo("Histórico limpo.");}
    void refreshCatalogs(){invalidateSectionCaches();CatalogCache.clear(this);EpgCacheStore.clear(this);detailCache.clear();epgCache.clear();String mode=resolveSourceMode();if(!mode.isEmpty())prewarmAllSections();showInfo("Atualização iniciada em segundo plano.");}

    void clearAppCache(){
        playlistCache.clear();
        invalidateSectionCaches();
        try{com.bumptech.glide.Glide.get(this).clearMemory();}catch(Exception ignored){}
        cacheExec.submit(()->{try{com.bumptech.glide.Glide.get(getApplicationContext()).clearDiskCache();}catch(Exception ignored){}});
        CatalogCache.clear(this);
        showInfo("Cache limpo. As listas serão atualizadas na próxima abertura; favoritos e Continue Assistindo foram preservados.");
    }

    void addSettingsTile(LinearLayout row,String icon,String label,Runnable action){
        Button b=button(icon+"   "+label); b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); b.setPadding(dp(16),0,dp(10),0); b.setOnClickListener(v->action.run());
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1); lp.leftMargin=dp(4); lp.rightMargin=dp(4); row.addView(b,lp);
    }

    void showPlaylistManager(){ currentSectionRequest=-1;
        clear(getString(R.string.ui_035)); addTitle(getString(R.string.ui_035),24);
        LinearLayout tabs=new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL); Button xt=button(getString(R.string.ui_036)); Button m3uTab=button(getString(R.string.ui_037)); xt.setTextColor(GOLD); tabs.addView(xt,new LinearLayout.LayoutParams(0,dp(48),1)); tabs.addView(m3uTab,new LinearLayout.LayoutParams(0,dp(48),1)); content.addView(tabs,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView device=text(getString(R.string.ui_038)+DeviceKeyUtil.key(this),compact?10:13); device.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); device.setTextColor(MUTED); content.addView(device,new LinearLayout.LayoutParams(-1,dp(36)));
        final String[] mode={prefs.getString("source_mode","xtream").equals("xtream")?"xtream":"m3u"};
        EditText name=field(getString(R.string.ui_039),prefs.getString("playlist_name","ÁUREON")); content.addView(name,new LinearLayout.LayoutParams(-1,dp(50)));
        String savedSource=prefs.getString("source_mode","xtream").equals("xtream")?prefs.getString("xt_server",""):CredentialStore.m3uUrl(prefs);
        EditText url=field(getString(R.string.ui_040),savedSource); content.addView(url,new LinearLayout.LayoutParams(-1,dp(50)));
        EditText user=field(getString(R.string.ui_041),CredentialStore.user(prefs)); content.addView(user,new LinearLayout.LayoutParams(-1,dp(50)));
        EditText pass=field(getString(R.string.ui_042),CredentialStore.pass(prefs)); pass.setInputType(129); content.addView(pass,new LinearLayout.LayoutParams(-1,dp(50)));
        EditText epg=field(getString(R.string.ui_043),CredentialStore.epgUrl(prefs)); content.addView(epg,new LinearLayout.LayoutParams(-1,dp(50)));
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); Button cancel=button(getString(R.string.ui_044)); Button go=button(getString(R.string.ui_045)); go.setTextColor(GOLD); actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1)); LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(0,dp(52),1); gp.leftMargin=dp(8); actions.addView(go,gp); content.addView(actions,new LinearLayout.LayoutParams(-1,dp(58)));
        status=text(getString(R.string.ui_005),compact?10:13); status.setTextColor(MUTED); content.addView(status,new LinearLayout.LayoutParams(-1,dp(40)));
        Runnable repaint=()->{
            boolean isXtream=mode[0].equals("xtream");
            xt.setTextColor(isXtream?GOLD:WHITE); m3uTab.setTextColor(isXtream?WHITE:GOLD);
            url.setHint(isXtream?"Servidor Xtream (ex.: http://servidor:porta)":"URL completa M3U/M3U8");
            user.setVisibility(isXtream?View.VISIBLE:View.GONE);
            pass.setVisibility(isXtream?View.VISIBLE:View.GONE);
        };
        xt.setOnClickListener(v->{mode[0]="xtream";repaint.run();}); m3uTab.setOnClickListener(v->{mode[0]="m3u";repaint.run();}); repaint.run(); cancel.setOnClickListener(v->showSetup());
        go.setOnClickListener(v->{
            prefs.edit().putString("playlist_name",name.getText().toString()).apply();
            String selectedMode=mode[0];
            String source=url.getText().toString().trim().toLowerCase(Locale.US);
            if(selectedMode.equals("xtream") && user.getText().toString().trim().isEmpty()
                    && pass.getText().toString().trim().isEmpty()
                    && (source.contains("get.php?") || source.contains(".m3u") || source.contains(".m3u8"))) {
                selectedMode="m3u";
            }
            connect(selectedMode,url,user,pass,epg,status,go);
        });
    }

    void showDeviceCode(){ currentSectionRequest=-1;
        clear(getString(R.string.ui_046)); addTitle(getString(R.string.ui_046),24);
        String deviceKey=DeviceKeyUtil.key(this);
        TextView key=text(getString(R.string.ui_047)+deviceKey,compact?20:28); key.setTypeface(null,1); key.setGravity(Gravity.CENTER); key.setBackground(box(Color.rgb(14,15,18),14,Color.rgb(70,70,74),1)); content.addView(key,new LinearLayout.LayoutParams(-1,dp(compact?90:110)));
        ImageView qr=new ImageView(this); qr.setScaleType(ImageView.ScaleType.FIT_CENTER); qr.setPadding(dp(12),dp(12),dp(12),dp(12)); qr.setBackground(box(Color.WHITE,12,Color.WHITE,1));
        Bitmap qrBitmap=makeQrBitmap("AUREON-DEVICE:"+deviceKey,compact?420:560); if(qrBitmap!=null)qr.setImageBitmap(qrBitmap); else qr.setImageResource(R.drawable.aureon_logo);
        LinearLayout.LayoutParams qlp=new LinearLayout.LayoutParams(dp(compact?220:300),dp(compact?220:300)); qlp.gravity=Gravity.CENTER_HORIZONTAL; qlp.topMargin=dp(18); content.addView(qr,qlp);
        TextView hint=text(getString(R.string.ui_048),compact?11:15); hint.setGravity(Gravity.CENTER); hint.setTextColor(MUTED); content.addView(hint,new LinearLayout.LayoutParams(-1,dp(60)));
    }

    Bitmap makeQrBitmap(String value,int size){
        try{
            BitMatrix bits=new MultiFormatWriter().encode(value,BarcodeFormat.QR_CODE,size,size);
            Bitmap b=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);
            for(int y=0;y<size;y++)for(int x=0;x<size;x++)b.setPixel(x,y,bits.get(x,y)?Color.BLACK:Color.WHITE);
            return b;
        }catch(Exception e){return null;}
    }

    EditText field(String hint,String value){ EditText e=new EditText(this); e.setHint(hint); e.setHintTextColor(Color.rgb(115,115,120)); e.setTextColor(WHITE); e.setText(value); e.setSingleLine(true); e.setPadding(dp(12),0,dp(12),0); e.setBackground(box(Color.rgb(20,20,22),13,Color.rgb(70,70,72),1)); return e; }

    void connect(String mode,EditText url,EditText user,EditText pass,EditText epg,TextView st,Button go){
        String u=url.getText().toString().trim(), us=user.getText().toString().trim(), pw=pass.getText().toString().trim();
        if(mode.equals("file")&&selectedM3u==null){st.setText("Escolha um arquivo M3U/M3U8.");return;}
        if(mode.equals("m3u")&&u.isEmpty()){st.setText("Informe a URL M3U/M3U8.");return;}
        if(mode.equals("xtream")&&(u.isEmpty()||us.isEmpty()||pw.isEmpty())){st.setText("Preencha servidor, usuário e senha Xtream.");return;}
        go.setEnabled(false); st.setText("Testando e carregando…");
        try{CredentialStore.saveEpgUrl(prefs,epg.getText().toString().trim());}catch(Exception secureError){go.setEnabled(true);st.setText("Falha: "+friendlyError(secureError));return;}
        exec.submit(()->{
            try{
                if(mode.equals("xtream")){
                    String server=normalizeServer(u); XtreamCreds x=new XtreamCreds(server,us,pw); verifyXtream(x);
                    prefs.edit().putString("source_mode","xtream").putString("xt_server",server).putString("file_uri","").apply(); CredentialStore.clearM3u(prefs); CredentialStore.save(prefs,us,pw); selectedM3u=null; playlistCache.clear(); invalidateSectionCaches();
                }else if(mode.equals("file")){
                    List<MediaEntry> items=loadFromUri(selectedM3u); playlistCache=new ArrayList<>(items); prefs.edit().putString("source_mode","file").putString("xt_server","").apply(); CredentialStore.clear(prefs); CredentialStore.clearM3u(prefs); invalidateSectionCaches();
                }else{
                    // Se a URL M3U for um link Xtream get.php, tente usar a API nativa do provedor.
                    // Isso separa TV ao vivo, filmes e séries de forma confiável.
                    XtreamCreds detected=xtreamFromM3uUrl(u);
                    boolean usedXtream=false;
                    if(detected!=null && detected.valid()){
                        try{
                            verifyXtream(detected);
                            prefs.edit().putString("source_mode","xtream").putString("xt_server",detected.server).putString("file_uri","").apply(); CredentialStore.clearM3u(prefs); CredentialStore.save(prefs,detected.user,detected.pass);
                            selectedM3u=null; playlistCache.clear(); invalidateSectionCaches(); usedXtream=true;
                        }catch(Exception ignored){
                            // Se player_api.php não estiver disponível, cai para a M3U normal.
                        }
                    }
                    if(!usedXtream){
                        List<MediaEntry> items=loadFromUrl(u); playlistCache=new ArrayList<>(items); prefs.edit().putString("source_mode","m3u").putString("file_uri","").putString("xt_server","").apply(); CredentialStore.clear(prefs); CredentialStore.saveM3uUrl(prefs,u); selectedM3u=null; invalidateSectionCaches();
                    }
                }
                runOnUiThread(()->{go.setEnabled(true);st.setText("Conectado com sucesso.");build();});
            }catch(Exception e){ runOnUiThread(()->{go.setEnabled(true);st.setText("Falha: "+friendlyError(e));}); }
        });
    }

    String friendlyError(Exception e){ String m=e.getMessage(); if(m==null||m.trim().isEmpty())return "não foi possível conectar."; if(m.length()>120)m=m.substring(0,120); return m; }

    String normalizeServer(String s) throws Exception{ return CatalogRepository.normalizeServer(s); }

    XtreamCreds savedXtream(){ return new XtreamCreds(prefs.getString("xt_server",""),CredentialStore.user(prefs),CredentialStore.pass(prefs)); }

    XtreamCreds xtreamFromM3uUrl(String raw){ return CatalogRepository.xtreamFromM3uUrl(raw); }



    void verifyXtream(XtreamCreds x) throws Exception{ CatalogRepository.verifyXtream(x); }

    void showLive(){ setNavHidden(true); loadSection(LIVE); }
    void showMovies(){ setNavHidden(true); loadSection(MOVIE); }
    void showSeries(){ setNavHidden(true); loadSection(SERIES); }

    String categoryAction(int kind){ return kind==LIVE?"get_live_categories":kind==MOVIE?"get_vod_categories":"get_series_categories"; }

    String sectionTitle(int kind){ return kind==LIVE?"TV Ao Vivo":kind==MOVIE?"Filmes":"Séries"; }

    String currentSourceCacheKey(){
        String mode=resolveSourceMode();
        if(mode.equals("xtream")){
            XtreamCreds x=savedXtream();
            return "xtream|"+x.server+"|"+x.user+"|"+Integer.toHexString((x.pass==null?"":x.pass).hashCode());
        }
        if(mode.equals("file"))return "file|"+prefs.getString("file_uri","");
        if(mode.equals("m3u")){String u=CredentialStore.m3uUrl(prefs);return "m3u|"+Integer.toHexString(u.hashCode());}
        return "";
    }

    void invalidateSectionCaches(){
        synchronized(sectionCacheLock){ sectionCache.clear(); sectionLoading.clear(); }
    }

    SectionData cachedSection(int kind,boolean allowStale){
        String key=currentSourceCacheKey();
        synchronized(sectionCacheLock){
            SectionData d=sectionCache.get(kind);
            if(d==null||key.isEmpty()||!key.equals(d.sourceKey))return null;
            if(!allowStale && System.currentTimeMillis()-d.loadedAt>SECTION_CACHE_TTL_MS)return null;
            return d;
        }
    }

    void storeSection(int kind,SectionData d){
        synchronized(sectionCacheLock){ sectionCache.put(kind,d); }
    }

    boolean sectionIsLoading(int kind){ synchronized(sectionCacheLock){ return sectionLoading.contains(kind); } }

    boolean markSectionLoading(int kind){
        synchronized(sectionCacheLock){
            if(sectionLoading.contains(kind))return false;
            sectionLoading.add(kind); return true;
        }
    }

    void unmarkSectionLoading(int kind){ synchronized(sectionCacheLock){ sectionLoading.remove(kind); } }

    void prewarmAllSections(){
        String mode=resolveSourceMode();
        if(mode.isEmpty())return;
        for(int kind=LIVE;kind<=SERIES;kind++){
            if(cachedSection(kind,false)==null)fetchSectionAsync(kind,mode,false);
        }
    }

    void prewarmOtherSections(int exceptKind){
        String mode=resolveSourceMode();
        if(mode.isEmpty())return;
        for(int kind=LIVE;kind<=SERIES;kind++){
            if(kind!=exceptKind && cachedSection(kind,false)==null)fetchSectionAsync(kind,mode,false);
        }
    }

    void renderSectionData(int kind,SectionData d){
        String title=sectionTitle(kind);
        ArrayList<MediaEntry> visible=new ArrayList<>(); for(MediaEntry e:d.items)if(contentAllowed(e))visible.add(e);
        browserCategoryOrder=new ArrayList<>(); for(String c:d.categories)if(!prefs.getBoolean("hide_adult",false)||!adultText(c))browserCategoryOrder.add(c);
        if(kind==LIVE)showBrowser(title,visible,kind); else showLibrary(title,visible,kind);
    }

    boolean adultText(String s){String z=s==null?"":s.toLowerCase(Locale.US);return z.contains("xxx")||z.contains("adult")||z.contains("18+")||z.contains("porn");}
    boolean contentAllowed(MediaEntry e){return !prefs.getBoolean("hide_adult",false)||!(adultText(e==null?"":e.group)||adultText(e==null?"":e.name));}

    void loadSection(int kind){
        String title=sectionTitle(kind);
        currentSectionRequest=kind;
        String mode=resolveSourceMode();
        if(mode.isEmpty()){ showMissingSource(title); return; }

        // Cache-first: se já carregou esta aba, abre na hora.
        SectionData cached=cachedSection(kind,true);
        if(cached!=null){
            renderSectionData(kind,cached);
            // Depois de 1 hora mantém o conteúdo na tela e atualiza silenciosamente.
            if(System.currentTimeMillis()-cached.loadedAt>SECTION_CACHE_TTL_MS)fetchSectionAsync(kind,mode,false);
            return;
        }

        clear(title);
        TextView loading=text(sectionIsLoading(kind)?"Preparando "+title.toLowerCase(Locale.US)+"…":"Carregando "+title.toLowerCase(Locale.US)+"…",15);
        loading.setTextColor(MUTED); loading.setGravity(Gravity.CENTER);
        content.addView(loading,new LinearLayout.LayoutParams(-1,dp(120)));
        fetchSectionAsync(kind,mode,true);
    }

    void fetchSectionAsync(int kind,String mode,boolean foregroundRequest){
        if(!markSectionLoading(kind))return;
        final String sourceKey=currentSourceCacheKey();
        dataExec.submit(()->{
            try{
                // Persistent cache first: after reopening the app, the last working catalog appears before the network refresh.
                SectionData memory=cachedSection(kind,true);
                if(memory==null){
                    CatalogCache.CachedCatalog disk=CatalogCache.load(this,sourceKey,kind);
                    if(disk!=null&&!disk.items.isEmpty()&&sourceKey.equals(currentSourceCacheKey())){
                        SectionData diskData=new SectionData(disk.items,disk.categories,disk.loadedAt,sourceKey);
                        storeSection(kind,diskData);
                        runOnUiThread(()->{
                            if(pendingFeatured!=null&&pendingFeatured.kind==kind){FeaturedTitle f=pendingFeatured;pendingFeatured=null;showFeaturedMatch(f,diskData);}
                            else if(currentSectionRequest==kind)renderSectionData(kind,diskData);
                        });
                        if(System.currentTimeMillis()-disk.loadedAt<=SECTION_CACHE_TTL_MS){
                            if(foregroundRequest)runOnUiThread(()->uiHandler.postDelayed(()->prewarmOtherSections(kind),700));
                            return;
                        }
                    }
                }

                SectionData data=fetchSectionData(kind,mode,sourceKey);
                if(!sourceKey.equals(currentSourceCacheKey()))return;
                storeSection(kind,data);
                saveCatalogAsync(kind,data);
                runOnUiThread(()->{
                    if(pendingFeatured!=null && pendingFeatured.kind==kind && sourceKey.equals(currentSourceCacheKey())){
                        FeaturedTitle selected=pendingFeatured; pendingFeatured=null; showFeaturedMatch(selected,data);
                    }else if(currentSectionRequest==kind && sourceKey.equals(currentSourceCacheKey())){
                        renderSectionData(kind,data);
                    }
                });
                if(foregroundRequest)runOnUiThread(()->uiHandler.postDelayed(()->prewarmOtherSections(kind),700));
            }catch(Exception e){
                runOnUiThread(()->{
                    if(pendingFeatured!=null && pendingFeatured.kind==kind && sourceKey.equals(currentSourceCacheKey())){
                        FeaturedTitle selected=pendingFeatured;
                        clear(selected.title);
                        TextView error=text(getString(R.string.ui_049)+friendlyError(e),compact?12:15);
                        content.addView(error,new LinearLayout.LayoutParams(-1,dp(110)));
                        Button retry=button(getString(R.string.ui_050)); retry.setOnClickListener(v->openFeatured(selected)); content.addView(retry,new LinearLayout.LayoutParams(-1,dp(52)));
                        Button back=button(getString(R.string.ui_009)); back.setOnClickListener(v->showHome()); content.addView(back,new LinearLayout.LayoutParams(-1,dp(52)));
                    }else if(currentSectionRequest==kind && cachedSection(kind,true)==null){ showSectionError(sectionTitle(kind),e); }
                });
            }finally{ unmarkSectionLoading(kind); }
        });
    }

    void saveCatalogAsync(int kind,SectionData data){
        if(data==null||data.sourceKey==null||data.sourceKey.isEmpty())return;
        try{cacheExec.submit(()->CatalogCache.save(this,data.sourceKey,kind,data.items,data.categories,data.loadedAt));}catch(Exception ignored){}
    }

    SectionData fetchSectionData(int kind,String mode,String sourceKey) throws Exception{
        List<MediaEntry> items=new ArrayList<>();
        ArrayList<String> categoryOrder=new ArrayList<>();

        if(mode.equals("xtream")){
            XtreamCreds x=savedXtream();
            if(!x.valid())throw new IOException("credenciais Xtream não encontradas");

            LinkedHashMap<String,String> cats=loadXtreamCategoriesSafe(x,categoryAction(kind));
            if(kind==LIVE)items=loadXtreamLive(x,cats);
            else if(kind==MOVIE)items=loadXtreamMovies(x,cats);
            else items=loadXtreamSeries(x,cats);

            LinkedHashSet<String> used=new LinkedHashSet<>();
            for(MediaEntry e:items){
                String g=(e.group==null||e.group.trim().isEmpty())?"Outros":e.group.trim();
                used.add(g);
            }
            for(String name:cats.values()){
                if(name==null)continue;
                String n=name.trim();
                if(!n.isEmpty()&&!categoryOrder.contains(n))categoryOrder.add(n);
            }
            for(String g:used)if(!categoryOrder.contains(g))categoryOrder.add(g);

            if(items.isEmpty()){
                List<MediaEntry> fallback=loadXtreamM3uFallback(x,kind);
                if(fallback!=null&&!fallback.isEmpty()){
                    items=fallback; categoryOrder.clear(); LinkedHashSet<String> groups=new LinkedHashSet<>();
                    for(MediaEntry e:items)groups.add((e.group==null||e.group.trim().isEmpty())?"Outros":e.group.trim());
                    categoryOrder.addAll(groups);
                }
            }
        }else{
            List<MediaEntry> all=ensurePlaylistLoaded(mode);
            LinkedHashSet<String> groups=new LinkedHashSet<>();
            for(MediaEntry e:all){
                if(e.kind==kind){
                    items.add(e);
                    groups.add((e.group==null||e.group.trim().isEmpty())?"Outros":e.group.trim());
                }
            }
            categoryOrder.addAll(groups);
        }
        return new SectionData(items,categoryOrder,System.currentTimeMillis(),sourceKey);
    }

    void showSectionError(String title,Exception e){
        clear(title); addTitle(title,24);
        TextView t=text(getString(R.string.ui_051)+title+". "+friendlyError(e),compact?11:14);
        t.setTextColor(MUTED); t.setGravity(Gravity.CENTER); t.setPadding(dp(18),dp(18),dp(18),dp(18));
        content.addView(t,new LinearLayout.LayoutParams(-1,dp(compact?110:130)));
        Button retry=button(getString(R.string.ui_050)); retry.setTextColor(GOLD);
        retry.setOnClickListener(v->{ if(title.equals("TV Ao Vivo"))showLive(); else if(title.equals("Filmes"))showMovies(); else showSeries(); });
        content.addView(retry,new LinearLayout.LayoutParams(-1,dp(54)));
        Button setup=button(getString(R.string.ui_052)); setup.setOnClickListener(v->showPlaylistManager());
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(54)); sp.topMargin=dp(8); content.addView(setup,sp);
    }

    List<MediaEntry> loadXtreamM3uFallback(XtreamCreds x,int kind) throws Exception{ return CatalogRepository.loadXtreamM3uFallback(x,kind); }

    List<MediaEntry> ensurePlaylistLoaded(String mode) throws Exception{
        if(!playlistCache.isEmpty())return new ArrayList<>(playlistCache); List<MediaEntry> all;
        if(mode.equals("file")){String su=prefs.getString("file_uri","");if(su.isEmpty())throw new IOException("arquivo não encontrado");all=loadFromUri(Uri.parse(su));}
        else {String u=CredentialStore.m3uUrl(prefs);if(u.isEmpty())throw new IOException("URL não encontrada");all=loadFromUrl(u);} playlistCache=new ArrayList<>(all); return all;
    }

    void showBrowser(String title,List<MediaEntry> items,int kind){
        boolean restoring=restoreKind==kind; String focusKey=restoring?restoreFocusKey:"";
        browserAll=new ArrayList<>(items); browserKind=kind; browserGroup=restoring?restoreGroup:"Todos"; browserQuery=restoring?restoreQuery:""; detailScreenKind=-1; clear(title);
        if(items.isEmpty()){ TextView empty=text(getString(R.string.ui_053),14); empty.setTextColor(MUTED); empty.setGravity(Gravity.CENTER); content.addView(empty,new LinearLayout.LayoutParams(-1,dp(120))); Button setup=button(getString(R.string.ui_054)); setup.setOnClickListener(v->showSetup()); content.addView(setup,new LinearLayout.LayoutParams(-1,dp(52))); return; }

        LinearLayout toolbar=new LinearLayout(this); toolbar.setOrientation(LinearLayout.HORIZONTAL); toolbar.setGravity(Gravity.CENTER_VERTICAL);
        EditText catSearch=field(getString(R.string.ui_055),""); toolbar.addView(catSearch,new LinearLayout.LayoutParams(dp(compact?220:285),dp(46)));
        EditText channelSearch=field(getString(R.string.ui_056),browserQuery); LinearLayout.LayoutParams chp=new LinearLayout.LayoutParams(0,dp(46),1); chp.leftMargin=dp(8); toolbar.addView(channelSearch,chp);
        content.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(52)));

        LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.HORIZONTAL); body.setGravity(Gravity.TOP);
        LinearLayout catPanel=new LinearLayout(this); catPanel.setOrientation(LinearLayout.VERTICAL); catPanel.setPadding(dp(8),dp(8),dp(8),dp(8)); catPanel.setBackground(box(Color.rgb(8,9,11),12,Color.rgb(70,55,24),1));
        ScrollView catScroll=new ScrollView(this); catScroll.setVerticalScrollBarEnabled(true); catScroll.setScrollbarFadingEnabled(false); catScroll.setNestedScrollingEnabled(true); catScroll.setFocusable(false); catScroll.setFocusableInTouchMode(false); catScroll.setDescendantFocusability(android.view.ViewGroup.FOCUS_AFTER_DESCENDANTS); LinearLayout cats=new LinearLayout(this); cats.setOrientation(LinearLayout.VERTICAL); liveCategoryColumn=cats; catScroll.addView(cats,new ScrollView.LayoutParams(-1,-2)); int liveCatH=Math.max(230,getResources().getConfiguration().screenHeightDp-(compact?150:175)); catPanel.addView(catScroll,new LinearLayout.LayoutParams(-1,dp(liveCatH)));
        int leftW=compact?220:280; body.addView(catPanel,new LinearLayout.LayoutParams(dp(leftW),-1));

        LinearLayout channelPanel=new LinearLayout(this); channelPanel.setOrientation(LinearLayout.VERTICAL); channelPanel.setPadding(dp(8),0,dp(8),0);
        browserResultCount=text(getString(R.string.ui_005),compact?10:12);browserResultCount.setTextColor(MUTED);channelPanel.addView(browserResultCount,new LinearLayout.LayoutParams(-1,dp(30)));
        browserRecycler=new RecyclerView(this);browserRecycler.setLayoutManager(new LinearLayoutManager(this));browserRecycler.setHasFixedSize(true);browserRecycler.setItemViewCacheSize(12);browserRecycler.setNestedScrollingEnabled(true);browserRecycler.setFocusable(false);browserRecycler.setDescendantFocusability(android.view.ViewGroup.FOCUS_AFTER_DESCENDANTS);
        channelRecyclerAdapter=new ChannelRecyclerAdapter();browserRecycler.setAdapter(channelRecyclerAdapter);int channelH=Math.max(220,getResources().getConfiguration().screenHeightDp-(compact?160:185));channelPanel.addView(browserRecycler,new LinearLayout.LayoutParams(-1,dp(channelH)));
        body.addView(channelPanel,new LinearLayout.LayoutParams(0,dp(channelH+34),1.15f));

        LinearLayout playerPanel=new LinearLayout(this); playerPanel.setOrientation(LinearLayout.VERTICAL); playerPanel.setPadding(dp(8),0,0,0);
        FrameLayout preview=new FrameLayout(this); preview.setBackground(box(Color.BLACK,12,Color.rgb(70,55,24),1)); preview.setClickable(true); preview.setFocusable(true);
        previewPlayerView=new PlayerView(this);previewPlayerView.setUseController(false);previewPlayerView.setKeepScreenOn(true);previewPlayerView.setFocusable(false);preview.addView(previewPlayerView,new FrameLayout.LayoutParams(-1,-1));
        browserPreviewHint=text("Carregando canal…",compact?10:13);browserPreviewHint.setGravity(Gravity.CENTER|Gravity.BOTTOM);browserPreviewHint.setTextColor(WHITE);browserPreviewHint.setBackgroundColor(0x88000000);FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(42));hp.gravity=Gravity.BOTTOM;preview.addView(browserPreviewHint,hp);
        preview.setOnClickListener(v->{if(previewEntry!=null)openFullScreen(previewEntry);});
        preview.setOnKeyListener((v,key,event)->{if(event.getAction()==KeyEvent.ACTION_UP&&(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER||key==KeyEvent.KEYCODE_NUMPAD_ENTER)){if(previewEntry!=null)openFullScreen(previewEntry);return true;}return false;});
        playerPanel.addView(preview,new LinearLayout.LayoutParams(-1,dp(compact?230:320)));
        LinearLayout quick=new LinearLayout(this); quick.setOrientation(LinearLayout.HORIZONTAL); Button back=button(getString(R.string.ui_058)); browserFavoriteButton=button(getString(R.string.ui_059)); Button full=button(getString(R.string.ui_060)); Button more=button(getString(R.string.ui_061));
        back.setOnClickListener(v->showHome());
        browserFavoriteButton.setOnClickListener(v->{if(previewEntry!=null){boolean on=PlaybackStore.toggleFavorite(this,previewEntry);browserFavoriteButton.setText(on?"★  Favorito":"☆  Favorito");}});
        full.setOnClickListener(v->{if(previewEntry!=null)openFullScreen(previewEntry);});
        more.setOnClickListener(v->{if(previewEntry!=null)openLiveDetailsFromBrowser(previewEntry);});
        quick.addView(back,new LinearLayout.LayoutParams(0,dp(76),1)); quick.addView(browserFavoriteButton,new LinearLayout.LayoutParams(0,dp(76),1)); quick.addView(full,new LinearLayout.LayoutParams(0,dp(76),1)); quick.addView(more,new LinearLayout.LayoutParams(0,dp(76),1)); LinearLayout.LayoutParams qlp=new LinearLayout.LayoutParams(-1,dp(82)); qlp.topMargin=dp(8); playerPanel.addView(quick,qlp);
        body.addView(playerPanel,new LinearLayout.LayoutParams(0,-1,.95f)); content.addView(body,new LinearLayout.LayoutParams(-1,-2));

        LinkedHashMap<String,Integer> counts=new LinkedHashMap<>(); for(MediaEntry e:items){String g=(e.group==null||e.group.trim().isEmpty())?"Outros":e.group.trim();counts.put(g,counts.getOrDefault(g,0)+1);} 
        Runnable rebuildCats=()->{cats.removeAllViews();String f=catSearch.getText().toString().trim().toLowerCase(Locale.US); addLiveCategory(cats,"Todos",items.size(),browserGroup.equals("Todos"),channelSearch); if(f.isEmpty()||"recentemente vistos".contains(f))addLiveCategory(cats,"Recentemente vistos",storedMatches(PlaybackStore.recents(this,100),LIVE,items).size(),browserGroup.equals("Recentemente vistos"),channelSearch); if(f.isEmpty()||"favoritos".contains(f))addLiveCategory(cats,"Favoritos",storedMatches(PlaybackStore.favorites(this),LIVE,items).size(),browserGroup.equals("Favoritos"),channelSearch); ArrayList<String> names=browserCategoryOrder.isEmpty()?new ArrayList<>(counts.keySet()):new ArrayList<>(browserCategoryOrder); for(String g:counts.keySet())if(!names.contains(g))names.add(g); for(String g:names){if(g==null||g.trim().isEmpty())continue;if(!f.isEmpty()&&!g.toLowerCase(Locale.US).contains(f))continue;addLiveCategory(cats,g,counts.getOrDefault(g,0),browserGroup.equals(g),channelSearch);}};
        catSearch.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){rebuildCats.run();}public void afterTextChanged(Editable e){}});
        channelSearch.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){browserQuery=s.toString();renderBrowserList();}public void afterTextChanged(Editable e){}});
        rebuildCats.run(); renderBrowserList();
        if(restoring && !focusKey.isEmpty()){ restoreKind=-1; restoreBrowserItemFocus(focusKey); }
        else { if(restoring)restoreKind=-1; focusFirstChild(cats); }
    }

    void addLiveCategory(LinearLayout parent,String group,int count,boolean selected,EditText search){
        LinearLayout row=new LinearLayout(this); row.setTag(group); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(10),0,dp(8),0); row.setBackground(box(selected?Color.rgb(70,50,16):Color.TRANSPARENT,10,selected?GOLD:Color.TRANSPARENT,selected?2:0)); row.setClickable(true); row.setFocusable(true);
        TextView n=text(group,compact?10:12); n.setTextColor(selected?GOLD:WHITE); n.setTypeface(null,selected?1:0); row.addView(n,new LinearLayout.LayoutParams(0,dp(42),1)); TextView c=text(String.valueOf(count),compact?9:11); c.setTextColor(selected?GOLD:MUTED); c.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); row.addView(c,new LinearLayout.LayoutParams(dp(48),dp(42)));
        row.setOnClickListener(v->runProtectedCategory(group,()->{lastFocusedCategory=group;browserGroup=group;browserQuery=search.getText().toString();refreshCategorySelection(parent);renderBrowserList();focusLastContentItem();}));
        row.setOnKeyListener((v,key,event)->{
            if(event.getAction()!=KeyEvent.ACTION_DOWN)return false;
            if(key==KeyEvent.KEYCODE_DPAD_RIGHT){runProtectedCategory(group,()->{lastFocusedCategory=group;browserGroup=group;refreshCategorySelection(parent);renderBrowserList();focusLastContentItem();});return true;}
            return false;
        });
        row.setOnFocusChangeListener((v,has)->{
            if(has){lastFocusedCategory=group;row.setBackground(box(Color.rgb(78,56,16),10,GOLD,4)); n.setTextColor(GOLD); n.setTypeface(null,1); c.setTextColor(WHITE);}
            else{boolean active=browserGroup.equals(group);row.setBackground(box(active?Color.rgb(70,50,16):Color.TRANSPARENT,10,active?GOLD:Color.TRANSPARENT,active?2:0));n.setTextColor(active?GOLD:WHITE);n.setTypeface(null,active?1:0);c.setTextColor(active?GOLD:MUTED);}
            focusMotion(v,has);
        });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(44)); lp.bottomMargin=dp(2); parent.addView(row,lp);
    }

    String titleForKind(int kind){ return kind==LIVE?"TV Ao Vivo":kind==MOVIE?"Filmes":"Séries"; }

    void showLibrary(String title,List<MediaEntry> items,int kind){
        boolean restoring=restoreKind==kind; String focusKey=restoring?restoreFocusKey:"";
        browserAll=new ArrayList<>(items); browserKind=kind; browserGroup=restoring?restoreGroup:"Todos"; browserQuery=restoring?restoreQuery:""; browserSortRecent=true; detailScreenKind=-1; clear(title+" • "+items.size());
        if(items.isEmpty()){ TextView empty=text(getString(R.string.ui_062)+title.toLowerCase(Locale.US)+" foi encontrado nesta fonte.",14); empty.setTextColor(MUTED); empty.setGravity(Gravity.CENTER); content.addView(empty,new LinearLayout.LayoutParams(-1,dp(120))); Button setup=button(getString(R.string.ui_054)); setup.setOnClickListener(v->showSetup()); content.addView(setup,new LinearLayout.LayoutParams(-1,dp(52))); return; }

        LinearLayout heading=new LinearLayout(this); heading.setGravity(Gravity.CENTER_VERTICAL); heading.setPadding(0,0,0,dp(5));
        TextView icon=text(kind==MOVIE?"▤":"▶",compact?24:31); icon.setTextColor(GOLD); icon.setGravity(Gravity.CENTER); icon.setBackground(box(Color.rgb(15,15,16),12,GOLD,1)); heading.addView(icon,new LinearLayout.LayoutParams(dp(compact?48:60),dp(compact?48:60)));
        LinearLayout htexts=new LinearLayout(this); htexts.setOrientation(LinearLayout.VERTICAL); htexts.setPadding(dp(12),0,0,0); TextView h=text(title,compact?22:29); h.setTypeface(null,1); htexts.addView(h,new LinearLayout.LayoutParams(-1,dp(compact?29:36))); TextView hs=text(kind==MOVIE?"Milhares de filmes para você assistir":"Milhares de séries para você assistir",compact?9:12); hs.setTextColor(MUTED); htexts.addView(hs,new LinearLayout.LayoutParams(-1,dp(22))); heading.addView(htexts,new LinearLayout.LayoutParams(0,dp(compact?54:64),1));
        content.addView(heading,new LinearLayout.LayoutParams(-1,dp(compact?60:70)));

        LinearLayout toolbar=new LinearLayout(this); toolbar.setOrientation(LinearLayout.HORIZONTAL); toolbar.setGravity(Gravity.CENTER_VERTICAL);
        EditText search=field(kind==MOVIE?"⌕   Buscar filmes...":"⌕   Buscar séries...",browserQuery); toolbar.addView(search,new LinearLayout.LayoutParams(0,dp(compact?43:48),1));
        Button sort=button(getString(R.string.ui_063)); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(compact?190:255),dp(compact?43:48)); sp.leftMargin=dp(8); toolbar.addView(sort,sp);
        mediaCount=text(getString(R.string.ui_064)+items.size()+")",compact?11:15); mediaCount.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(compact?135:180),dp(compact?43:48)); cp.leftMargin=dp(8); toolbar.addView(mediaCount,cp);
        content.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(compact?48:54)));

        LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.HORIZONTAL); body.setGravity(Gravity.TOP);
        LinearLayout categoryPanel=new LinearLayout(this); categoryPanel.setOrientation(LinearLayout.VERTICAL); categoryPanel.setPadding(dp(10),dp(9),dp(10),dp(10)); categoryPanel.setBackground(box(Color.rgb(9,10,11),13,Color.rgb(82,61,21),1));
        categorySearch=field(getString(R.string.ui_055),""); categoryPanel.addView(categorySearch,new LinearLayout.LayoutParams(-1,dp(compact?40:45)));
        ScrollView catScroll=new ScrollView(this); catScroll.setVerticalScrollBarEnabled(true); catScroll.setScrollbarFadingEnabled(false); catScroll.setNestedScrollingEnabled(true); catScroll.setFocusable(false); catScroll.setFocusableInTouchMode(false); catScroll.setDescendantFocusability(android.view.ViewGroup.FOCUS_AFTER_DESCENDANTS); categoryColumn=new LinearLayout(this); categoryColumn.setOrientation(LinearLayout.VERTICAL); catScroll.addView(categoryColumn,new ScrollView.LayoutParams(-1,-2)); int libraryCatH=Math.max(220,getResources().getConfiguration().screenHeightDp-(compact?185:210)); LinearLayout.LayoutParams csp=new LinearLayout.LayoutParams(-1,dp(libraryCatH)); csp.topMargin=dp(8); categoryPanel.addView(catScroll,csp);
        int catW=compact?225:285; body.addView(categoryPanel,new LinearLayout.LayoutParams(dp(catW),dp(libraryCatH+(compact?58:64))));

        LinearLayout gridWrap=new LinearLayout(this); gridWrap.setOrientation(LinearLayout.VERTICAL); gridWrap.setPadding(dp(10),0,0,0);
        int cols=compact?4:5;mediaRecycler=new RecyclerView(this);mediaRecycler.setLayoutManager(new GridLayoutManager(this,cols));mediaRecycler.setHasFixedSize(true);mediaRecycler.setItemViewCacheSize(cols*3);mediaRecycler.setNestedScrollingEnabled(true);mediaRecycler.setFocusable(false);mediaRecycler.setDescendantFocusability(android.view.ViewGroup.FOCUS_AFTER_DESCENDANTS);mediaRecyclerAdapter=new MediaRecyclerAdapter(cols);mediaRecycler.setAdapter(mediaRecyclerAdapter);
        gridWrap.addView(mediaRecycler,new LinearLayout.LayoutParams(-1,dp(libraryCatH+(compact?58:64)))); body.addView(gridWrap,new LinearLayout.LayoutParams(0,dp(libraryCatH+(compact?58:64)),1));
        content.addView(body,new LinearLayout.LayoutParams(-1,-2));

        Runnable rebuildCategories=()->renderCategoryColumn(categorySearch.getText().toString());
        categorySearch.addTextChangedListener(new TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){rebuildCategories.run();} public void afterTextChanged(Editable e){} });
        search.addTextChangedListener(new TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){browserQuery=s.toString();renderMediaGrid();} public void afterTextChanged(Editable e){} });
        sort.setOnClickListener(v->{browserSortRecent=!browserSortRecent;sort.setText(browserSortRecent?"Ordenar: Mais recentes  ▾":"Ordenar: A-Z  ▾");renderMediaGrid();});
        renderCategoryColumn(""); renderMediaGrid();
        if(restoring && !focusKey.isEmpty()){ restoreKind=-1; restoreMediaItemFocus(focusKey); }
        else { if(restoring)restoreKind=-1; focusFirstChild(categoryColumn); }
    }

    void renderCategoryColumn(String filter){
        if(categoryColumn==null)return; categoryColumn.removeAllViews(); String f=filter==null?"":filter.trim().toLowerCase(Locale.US);
        LinkedHashMap<String,Integer> counts=new LinkedHashMap<>(); for(MediaEntry e:browserAll){String g=(e.group==null||e.group.trim().isEmpty())?"Outros":e.group.trim();counts.put(g,counts.getOrDefault(g,0)+1);} 
        addLibraryCategory("Todos",browserAll.size(),browserGroup.equals("Todos"));
        if(browserKind==MOVIE) addLibraryCategory("Continuar assistindo",storedMatches(PlaybackStore.continueWatching(this,100),MOVIE,browserAll).size(),browserGroup.equals("Continuar assistindo"));
        else addLibraryCategory("Recentemente vistos",storedMatches(PlaybackStore.recents(this,100),SERIES,browserAll).size(),browserGroup.equals("Recentemente vistos"));
        addLibraryCategory("Favoritos",storedMatches(PlaybackStore.favorites(this),browserKind,browserAll).size(),browserGroup.equals("Favoritos"));
        ArrayList<String> names=browserCategoryOrder.isEmpty()?new ArrayList<>(counts.keySet()):new ArrayList<>(browserCategoryOrder);
        for(String g:counts.keySet())if(!names.contains(g))names.add(g);
        for(String g:names){if(g==null||g.trim().isEmpty())continue;if(!f.isEmpty()&&!g.toLowerCase(Locale.US).contains(f))continue; addLibraryCategory(g,counts.getOrDefault(g,0),browserGroup.equals(g));}
    }

    void addLibraryCategory(String group,int count,boolean selected){
        LinearLayout row=new LinearLayout(this); row.setTag(group); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(10),0,dp(8),0); row.setBackground(box(selected?Color.rgb(70,50,16):Color.TRANSPARENT,10,selected?GOLD:Color.TRANSPARENT,selected?2:0)); row.setClickable(true); row.setFocusable(true);
        TextView name=text(group,compact?10:13); name.setTextColor(selected?GOLD:WHITE); name.setTypeface(null,selected?1:0); row.addView(name,new LinearLayout.LayoutParams(0,dp(compact?38:44),1)); TextView ct=text(String.valueOf(count),compact?9:11); ct.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); ct.setTextColor(selected?GOLD:MUTED); row.addView(ct,new LinearLayout.LayoutParams(dp(55),dp(compact?38:44)));
        row.setOnClickListener(v->runProtectedCategory(group,()->{lastFocusedCategory=group;browserGroup=group;renderCategoryColumn(categorySearch==null?"":categorySearch.getText().toString());renderMediaGrid();focusLastContentItem();}));
        row.setOnKeyListener((v,key,event)->{
            if(event.getAction()!=KeyEvent.ACTION_DOWN)return false;
            if(key==KeyEvent.KEYCODE_DPAD_RIGHT){runProtectedCategory(group,()->{lastFocusedCategory=group;browserGroup=group;refreshCategorySelection(categoryColumn);renderMediaGrid();focusLastContentItem();});return true;}
            return false;
        });
        row.setOnFocusChangeListener((v,has)->{
            boolean active=browserGroup.equals(group);
            if(has){lastFocusedCategory=group;row.setBackground(box(Color.rgb(78,56,16),10,GOLD,4));name.setTextColor(GOLD);name.setTypeface(null,1);ct.setTextColor(WHITE);}
            else{row.setBackground(box(active?Color.rgb(70,50,16):Color.TRANSPARENT,10,active?GOLD:Color.TRANSPARENT,active?2:0));name.setTextColor(active?GOLD:WHITE);name.setTypeface(null,active?1:0);ct.setTextColor(active?GOLD:MUTED);}
            focusMotion(v,has);
        });
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(compact?40:46)); rp.bottomMargin=dp(2); categoryColumn.addView(row,rp);
    }

    void renderMediaGrid(){
        if(mediaRecycler==null||mediaRecyclerAdapter==null)return; browserFiltered.clear(); String q=browserQuery==null?"":browserQuery.trim().toLowerCase(Locale.US);
        List<MediaEntry> source=browserAll;
        if("Favoritos".equals(browserGroup))source=storedMatches(PlaybackStore.favorites(this),browserKind,browserAll);
        else if("Continuar assistindo".equals(browserGroup))source=storedMatches(PlaybackStore.continueWatching(this,100),MOVIE,browserAll);
        else if("Recentemente vistos".equals(browserGroup))source=storedMatches(PlaybackStore.recents(this,100),SERIES,browserAll);
        for(MediaEntry e:source){boolean groupOk=specialGroup(browserGroup)||browserGroup.equals("Todos")||browserGroup.equals(e.group);boolean searchOk=q.isEmpty()||(e.name!=null&&e.name.toLowerCase(Locale.US).contains(q));if(groupOk&&searchOk)browserFiltered.add(e);}
        if(browserSortRecent) Collections.sort(browserFiltered,(a,b)->compareAdded(b,a)); else Collections.sort(browserFiltered,Comparator.comparing(e->e.name==null?"":e.name,String.CASE_INSENSITIVE_ORDER));
        if(mediaCount!=null)mediaCount.setText((browserGroup.equals("Todos")?"Todos":"Categoria")+" ("+browserFiltered.size()+")");
        mediaRecyclerAdapter.submit(new ArrayList<>(browserFiltered));
    }

    int compareAdded(MediaEntry a,MediaEntry b){
        String aa=a==null?"":a.added, bb=b==null?"":b.added; if(aa==null)aa="";if(bb==null)bb=""; try{return Long.compare(Long.parseLong(aa),Long.parseLong(bb));}catch(Exception ignored){} return aa.compareToIgnoreCase(bb);
    }

    void addNextMediaPage(){ renderMediaGrid(); }

    LinearLayout makePosterCard(MediaEntry e,int cardW,int posterH){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(0,0,0,dp(4)); card.setBackground(box(Color.rgb(12,13,14),9,Color.rgb(91,67,20),1)); card.setClickable(true); card.setFocusable(true);
        FrameLayout posterFrame=new FrameLayout(this); ImageView img=new ImageView(this); img.setScaleType(ImageView.ScaleType.CENTER_CROP); img.setImageResource(R.drawable.aureon_logo); posterFrame.addView(img,new FrameLayout.LayoutParams(-1,-1)); if(e.poster!=null&&!e.poster.trim().isEmpty())loadImage(e.poster,img);
        if(e.rating!=null&&!e.rating.trim().isEmpty()&&!e.rating.equals("0")&&!e.rating.equals("0.0")){TextView rating=text(getString(R.string.ui_065)+trimRating(e.rating),compact?8:10);rating.setTextColor(GOLD);rating.setGravity(Gravity.CENTER);rating.setBackground(box(Color.rgb(5,6,7),7,GOLD,1));FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(dp(compact?46:55),dp(compact?22:25));rp.gravity=Gravity.LEFT|Gravity.BOTTOM;rp.leftMargin=dp(6);rp.bottomMargin=dp(6);posterFrame.addView(rating,rp);} card.addView(posterFrame,new LinearLayout.LayoutParams(-1,dp(posterH)));
        TextView name=text(e.name==null?"":e.name,compact?9:11); name.setTypeface(null,1); name.setMaxLines(2); name.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); name.setPadding(dp(7),dp(2),dp(5),0); card.addView(name,new LinearLayout.LayoutParams(-1,dp(compact?38:44))); TextView yr=text(e.year==null?"":e.year,compact?8:10);yr.setTextColor(MUTED);yr.setPadding(dp(7),0,0,0);card.addView(yr,new LinearLayout.LayoutParams(-1,dp(compact?18:21)));
        card.setOnClickListener(v->openMediaDetailsFromBrowser(e));
        card.setOnFocusChangeListener((v,has)->{
            if(has)lastFocusedMediaKey=PlaybackStore.key(e);
            card.setBackground(box(has?Color.rgb(42,31,12):Color.rgb(12,13,14),9,has?GOLD:Color.rgb(91,67,20),has?4:1));
            name.setTextColor(has?GOLD:WHITE); focusMotion(v,has);
        });
        return card;
    }

    String trimRating(String r){try{double d=Double.parseDouble(r);return String.format(Locale.US,"%.1f",d);}catch(Exception e){return r.length()>4?r.substring(0,4):r;}}

    void loadImage(String url,ImageView target){
        ImageLoader.load(target,url,R.drawable.aureon_logo);
    }

    void addCategoryButton(LinearLayout row,String group,EditText search){ Button b=button(group); b.setOnClickListener(v->{browserGroup=group;browserQuery=search.getText().toString().trim();renderBrowserList();}); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(compact?135:180),dp(44)); p.rightMargin=dp(5); row.addView(b,p); }

    List<MediaEntry> storedMatches(List<MediaEntry> stored,int kind,List<MediaEntry> current){
        ArrayList<MediaEntry> out=new ArrayList<>(); if(stored==null)return out;
        LinkedHashMap<String,MediaEntry> byKey=new LinkedHashMap<>(); if(current!=null)for(MediaEntry e:current)if(e!=null)byKey.put(PlaybackStore.key(e),e);
        for(MediaEntry e:stored){if(e==null||e.kind!=kind)continue;MediaEntry now=byKey.get(PlaybackStore.key(e));out.add(now==null?e:now);} return out;
    }

    boolean specialGroup(String g){return "Recentemente vistos".equals(g)||"Favoritos".equals(g)||"Continuar assistindo".equals(g);}

    void renderBrowserList(){
        if(browserRecycler==null||channelRecyclerAdapter==null)return; browserFiltered.clear(); String q=browserQuery==null?"":browserQuery.toLowerCase(Locale.US);
        List<MediaEntry> source=browserAll;
        if("Recentemente vistos".equals(browserGroup))source=storedMatches(PlaybackStore.recents(this,100),LIVE,browserAll);
        else if("Favoritos".equals(browserGroup))source=storedMatches(PlaybackStore.favorites(this),LIVE,browserAll);
        for(MediaEntry e:source){boolean groupOk=specialGroup(browserGroup)||browserGroup.equals("Todos")||browserGroup.equals(e.group);boolean searchOk=q.isEmpty()||(e.name!=null&&e.name.toLowerCase(Locale.US).contains(q));if(groupOk&&searchOk)browserFiltered.add(e);}
        if(browserResultCount!=null)browserResultCount.setText(browserFiltered.size()+" resultado(s)");
        channelRecyclerAdapter.submit(new ArrayList<>(browserFiltered));
        if(!browserFiltered.isEmpty()){
            boolean currentVisible=false;
            if(previewEntry!=null)for(MediaEntry item:browserFiltered)if(PlaybackStore.key(item).equals(PlaybackStore.key(previewEntry))){currentVisible=true;break;}
            if(!currentVisible)scheduleBrowserPreview(browserFiltered.get(0),80L);
        }else{
            releasePreviewPlayerOnly();
            if(browserPreviewHint!=null)browserPreviewHint.setText("Nenhum canal nesta categoria");
        }
    }

    void scheduleBrowserPreview(MediaEntry e,long delay){
        if(e==null||e.url==null||e.url.trim().isEmpty())return;
        pendingBrowserPreview=e;uiHandler.removeCallbacks(browserPreviewTask);uiHandler.postDelayed(browserPreviewTask,Math.max(0L,delay));
    }

    void selectBrowserPreview(MediaEntry e){
        if(e==null)return;
        PlaybackStore.markRecent(this,e);
        detailNavItems=new ArrayList<>(browserFiltered.isEmpty()?browserAll:browserFiltered);
        if(browserPreviewHint!=null)browserPreviewHint.setText((e.name==null?"Canal":e.name)+"  •  OK para tela cheia");
        if(browserFavoriteButton!=null)browserFavoriteButton.setText(PlaybackStore.isFavorite(this,e)?"★  Favorito":"☆  Favorito");
        if(previewEntry==null||!PlaybackStore.key(previewEntry).equals(PlaybackStore.key(e)))startLivePreview(e);
    }

    void addNextBrowserPage(){ renderBrowserList(); }

    LinearLayout makeLiveRow(MediaEntry e){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(4),dp(10),dp(4));row.setBackground(box(Color.rgb(18,18,20),10,Color.rgb(82,61,22),1));row.setClickable(true);row.setFocusable(true);
        ImageView channelLogo=new ImageView(this);channelLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);channelLogo.setImageResource(R.drawable.aureon_logo);channelLogo.setBackground(box(Color.rgb(8,8,9),8,Color.rgb(70,55,24),1));int logoSize=dp(compact?36:44);LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(logoSize,logoSize);ilp.rightMargin=dp(10);row.addView(channelLogo,ilp);if(e.poster!=null&&!e.poster.trim().isEmpty())loadImage(e.poster,channelLogo);
        TextView playIcon=text(getString(R.string.ui_066),compact?10:12);playIcon.setTextColor(GOLD);playIcon.setGravity(Gravity.CENTER);row.addView(playIcon,new LinearLayout.LayoutParams(dp(22),-1));
        TextView name=text(e.name==null?"Canal":e.name,compact?11:13);name.setTextColor(WHITE);name.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);name.setMaxLines(2);name.setPadding(dp(4),0,0,0);row.addView(name,new LinearLayout.LayoutParams(0,-1,1));
        row.setOnClickListener(v->{selectBrowserPreview(e);openFullScreen(e);});
        row.setOnKeyListener((v,key,event)->{if(event.getAction()==KeyEvent.ACTION_DOWN&&key==KeyEvent.KEYCODE_DPAD_LEFT){lastFocusedBrowserKey=PlaybackStore.key(e);focusActiveCategory();return true;}return false;});
        row.setOnFocusChangeListener((v,has)->{if(has){lastFocusedBrowserKey=PlaybackStore.key(e);scheduleBrowserPreview(e,280L);}row.setBackground(box(has?Color.rgb(78,56,16):Color.rgb(18,18,20),10,has?GOLD:Color.rgb(82,61,22),has?4:1));name.setTextColor(has?GOLD:WHITE);playIcon.setTextColor(has?WHITE:GOLD);focusMotion(v,has);});
        return row;
    }

    void rememberReturnState(MediaEntry e){
        if(e==null)return; restoreKind=e.kind; restoreGroup=browserGroup==null?"Todos":browserGroup; restoreQuery=browserQuery==null?"":browserQuery; restoreFocusKey=PlaybackStore.key(e);
    }

    void openLiveDetailsFromBrowser(MediaEntry e){
        rememberReturnState(e); detailNavItems=new ArrayList<>(browserFiltered.isEmpty()?browserAll:browserFiltered);
        showLiveDetails(e);
    }

    void openMediaDetailsFromBrowser(MediaEntry e){
        rememberReturnState(e); detailNavItems=new ArrayList<>(browserFiltered.isEmpty()?browserAll:browserFiltered);
        showMediaDetails(e);
    }

    MediaEntry adjacentDetail(MediaEntry current,int delta){
        if(current==null||detailNavItems==null||detailNavItems.isEmpty())return null;
        int idx=-1;
        for(int i=0;i<detailNavItems.size();i++){
            MediaEntry x=detailNavItems.get(i);
            if(x==current || (x!=null&&current.id!=null&&current.id.equals(x.id))){idx=i;break;}
        }
        if(idx<0)return null;
        int ni=idx+delta;
        if(ni<0||ni>=detailNavItems.size())return null;
        return detailNavItems.get(ni);
    }

    void addPrevNextButtons(LinearLayout parent,MediaEntry current,boolean live){
        LinearLayout navRow=new LinearLayout(this); navRow.setOrientation(LinearLayout.HORIZONTAL);
        MediaEntry prev=adjacentDetail(current,-1), next=adjacentDetail(current,1);
        Button prevBtn=button(getString(R.string.ui_067)); prevBtn.setTextColor(GOLD); prevBtn.setEnabled(prev!=null); prevBtn.setAlpha(prev==null?.35f:1f);
        prevBtn.setOnClickListener(v->{if(prev!=null){if(restoreKind==current.kind)restoreFocusKey=PlaybackStore.key(prev);if(live)showLiveDetails(prev);else showMediaDetails(prev);}});
        Button nextBtn=button(getString(R.string.ui_068)); nextBtn.setTextColor(GOLD); nextBtn.setEnabled(next!=null); nextBtn.setAlpha(next==null?.35f:1f);
        nextBtn.setOnClickListener(v->{if(next!=null){if(restoreKind==current.kind)restoreFocusKey=PlaybackStore.key(next);if(live)showLiveDetails(next);else showMediaDetails(next);}});
        navRow.addView(prevBtn,new LinearLayout.LayoutParams(0,dp(46),1));
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,dp(46),1); np.leftMargin=dp(8); navRow.addView(nextBtn,np);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(50)); rp.topMargin=dp(6); parent.addView(navRow,rp);
    }

    static synchronized void setPlayerQueue(List<MediaEntry> source,MediaEntry current){
        PLAYER_QUEUE.clear();
        if(source!=null)for(MediaEntry e:source)if(e!=null&&e.url!=null&&!e.url.trim().isEmpty())PLAYER_QUEUE.add(e);
        PLAYER_INDEX=-1;
        if(current!=null){
            for(int i=0;i<PLAYER_QUEUE.size();i++){MediaEntry e=PLAYER_QUEUE.get(i);if(e==current||(current.id!=null&&current.id.equals(e.id))){PLAYER_INDEX=i;break;}}
        }
    }

    static synchronized MediaEntry movePlayerQueue(int delta){
        if(PLAYER_QUEUE.isEmpty())return null;
        if(PLAYER_INDEX<0)PLAYER_INDEX=0; else {int ni=PLAYER_INDEX+delta;if(ni<0||ni>=PLAYER_QUEUE.size())return null;PLAYER_INDEX=ni;}
        return PLAYER_QUEUE.get(PLAYER_INDEX);
    }

    static synchronized boolean canMovePlayerQueue(int delta){
        if(PLAYER_QUEUE.isEmpty()||PLAYER_INDEX<0)return false; int ni=PLAYER_INDEX+delta; return ni>=0&&ni<PLAYER_QUEUE.size();
    }

    static synchronized ArrayList<MediaEntry> playerQueueSnapshot(){
        return new ArrayList<>(PLAYER_QUEUE);
    }

    static synchronized int getPlayerQueueIndex(){
        return PLAYER_INDEX;
    }

    static synchronized void setPlayerQueueIndex(int index){
        if(index>=0&&index<PLAYER_QUEUE.size()) PLAYER_INDEX=index;
    }

    void showMediaDetails(MediaEntry e){
        PlaybackStore.markRecent(this,e); detailScreenKind=e==null?-1:e.kind;
        currentSectionRequest=-1;
        setNavHidden(true);
        clear(e.name==null?"Detalhes":e.name);
        TextView loading=text(getString(R.string.ui_069),15); loading.setTextColor(MUTED); loading.setGravity(Gravity.CENTER);
        content.addView(loading,new LinearLayout.LayoutParams(-1,dp(110)));

        String mode=resolveSourceMode();
        XtreamCreds x=savedXtream();
        String cacheKey=e.kind+"|"+(e.id==null?"":e.id);
        final String detailSourceKey=currentSourceCacheKey();
        DetailInfo cached=detailCache.get(cacheKey);
        if(cached!=null){ renderMediaDetails(e,cached); return; }

        if(!mode.equals("xtream")||!x.valid()||e.id==null||e.id.trim().isEmpty()){
            renderMediaDetails(e,basicDetail(e)); return;
        }

        exec.submit(()->{
            DetailInfo d;
            try{ d=e.kind==SERIES?loadSeriesDetail(x,e):loadMovieDetail(x,e); }
            catch(Exception ex){ d=basicDetail(e); }
            final DetailInfo out=d;
            detailCache.put(cacheKey,out);
            runOnUiThread(()->{
                if(loading.getParent()==content && detailSourceKey.equals(currentSourceCacheKey()))renderMediaDetails(e,out);
            });
        });
    }

    DetailInfo basicDetail(MediaEntry e){
        DetailInfo d=new DetailInfo();
        d.poster=e.poster==null?"":e.poster; d.rating=e.rating==null?"":e.rating;
        d.releaseDate=e.year==null?"":e.year; d.genre=e.group==null?"":e.group;
        return d;
    }

    DetailInfo loadMovieDetail(XtreamCreds x,MediaEntry e) throws Exception{ return CatalogRepository.loadMovieDetail(x,e); }

    DetailInfo loadSeriesDetail(XtreamCreds x,MediaEntry e) throws Exception{ return CatalogRepository.loadSeriesDetail(x,e); }



    String firstNonEmpty(String a,String b){return a!=null&&!a.trim().isEmpty()?a:b==null?"":b;}

    void renderMediaDetails(MediaEntry e,DetailInfo d){
        clear(e.name==null?"Detalhes":e.name);

        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.TOP);
        ImageView poster=new ImageView(this); poster.setScaleType(ImageView.ScaleType.CENTER_CROP); poster.setImageResource(R.drawable.aureon_logo);
        String posterUrl=firstNonEmpty(d.poster,e.poster); if(!posterUrl.isEmpty())loadImage(posterUrl,poster);
        poster.setBackground(box(Color.rgb(10,11,12),12,GOLD,1));
        int posterW=dp(compact?150:205), posterH=dp(compact?218:292);
        top.addView(poster,new LinearLayout.LayoutParams(posterW,posterH));

        LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setPadding(dp(20),dp(2),0,0);
        TextView title=text(e.name==null?"":e.name,compact?21:29); title.setTypeface(null,1); title.setMaxLines(2);
        info.addView(title,new LinearLayout.LayoutParams(-1,dp(compact?58:74)));

        StringBuilder meta=new StringBuilder();
        if(d.releaseDate!=null&&!d.releaseDate.isEmpty())meta.append(shortYear(d.releaseDate));
        if(d.rating!=null&&!d.rating.isEmpty()){if(meta.length()>0)meta.append("  •  ");meta.append("★ ").append(trimRating(d.rating));}
        if(d.duration!=null&&!d.duration.isEmpty()){if(meta.length()>0)meta.append("  •  ");meta.append(formatDuration(d.duration));}
        TextView metaV=text(meta.toString(),compact?11:14); metaV.setTextColor(GOLD); info.addView(metaV,new LinearLayout.LayoutParams(-1,dp(30)));

        // A ação principal fica logo no topo para não ficar cortada em telas menores.
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        Button back=button(getString(R.string.ui_070)); back.setTextColor(GOLD); back.setOnClickListener(v->returnToSection(e.kind));
        actions.addView(back,new LinearLayout.LayoutParams(0,dp(48),.8f));
        Button action=button(e.kind==SERIES?"▣  TEMPORADAS":"▶  ASSISTIR"); action.setTextColor(GOLD);
        action.setOnClickListener(v->{if(e.kind==SERIES)showSeriesEpisodes(e);else {setPlayerQueue(detailNavItems,e);play(e);}});
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(48),1.3f); ap.leftMargin=dp(8); actions.addView(action,ap);
        Button favorite=button(PlaybackStore.isFavorite(this,e)?"★  FAVORITO":"☆  FAVORITAR"); favorite.setTextColor(GOLD);
        favorite.setOnClickListener(v->{boolean on=PlaybackStore.toggleFavorite(this,e);favorite.setText(on?"★  FAVORITO":"☆  FAVORITAR");});
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(0,dp(48),1f); fp.leftMargin=dp(8); actions.addView(favorite,fp);
        LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,dp(52)); alp.topMargin=dp(6); info.addView(actions,alp);
        addPrevNextButtons(info,e,false);

        if(d.genre!=null&&!d.genre.isEmpty()){TextView genre=text(d.genre,compact?10:13);genre.setTextColor(MUTED);genre.setMaxLines(2);LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,dp(40));gp.topMargin=dp(6);info.addView(genre,gp);}
        if(d.director!=null&&!d.director.isEmpty()){TextView dir=text(getString(R.string.ui_071)+d.director,compact?9:12);dir.setTextColor(MUTED);dir.setMaxLines(2);info.addView(dir,new LinearLayout.LayoutParams(-1,dp(34)));}
        if(d.cast!=null&&!d.cast.isEmpty()){TextView cast=text(getString(R.string.ui_072)+d.cast,compact?9:12);cast.setTextColor(MUTED);cast.setMaxLines(2);info.addView(cast,new LinearLayout.LayoutParams(-1,dp(44)));}

        // O painel de informações pode ser mais alto que a capa (elenco, favorito, anterior/próximo etc.).
        // Usar WRAP_CONTENT evita cortar os botões em telas menores/TVs com overscan.
        info.setMinimumHeight(posterH);
        top.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        content.addView(top,new LinearLayout.LayoutParams(-1,-2));

        TextView sh=text(getString(R.string.ui_073),compact?17:21);sh.setTypeface(null,1);sh.setTextColor(GOLD);LinearLayout.LayoutParams shp=new LinearLayout.LayoutParams(-1,dp(42));shp.topMargin=dp(12);content.addView(sh,shp);
        String plot=d.plot==null||d.plot.trim().isEmpty()?"Sinopse não informada pelo servidor.":d.plot.trim();
        TextView synopsis=text(plot,compact?11:14);synopsis.setTextColor(Color.rgb(215,215,218));synopsis.setGravity(Gravity.TOP|Gravity.LEFT);synopsis.setPadding(dp(14),dp(12),dp(14),dp(12));synopsis.setBackground(box(Color.rgb(13,14,16),12,Color.rgb(78,59,22),1));
        content.addView(synopsis,new LinearLayout.LayoutParams(-1,-2));
    }

    String shortYear(String s){
        if(s==null)return ""; String t=s.trim();
        if(t.matches(".*\\b(19|20)\\d{2}\\b.*")){java.util.regex.Matcher m=java.util.regex.Pattern.compile("(19|20)\\d{2}").matcher(t);if(m.find())return m.group();}
        return t.length()>16?t.substring(0,16):t;
    }

    String formatDuration(String s){
        if(s==null)return ""; String t=s.trim();
        try{long sec=Long.parseLong(t);if(sec>300){long h=sec/3600,m=(sec%3600)/60;return h>0?h+"h "+m+"min":m+" min";}}catch(Exception ignored){}
        return t;
    }

    void showLiveDetails(MediaEntry e){
        PlaybackStore.markRecent(this,e); detailScreenKind=LIVE;
        currentSectionRequest=-1; setNavHidden(true);
        String mode=resolveSourceMode(); XtreamCreds x=savedXtream(); String key=e.id==null?"":e.id;
        List<EpgItem> cached=epgCache.get(key);

        // Abre a tela e inicia o canal imediatamente; o EPG chega depois sem reiniciar o vídeo.
        renderLiveDetails(e,cached);
        if(cached!=null)return;
        if(!mode.equals("xtream")||!x.valid()||key.isEmpty()){ updateLiveEpg(new ArrayList<>()); return; }

        exec.submit(()->{
            List<EpgItem> epg;
            try{epg=loadShortEpg(x,e);}catch(Exception ex){epg=new ArrayList<>();}
            epgCache.put(key,epg); final List<EpgItem> out=epg;
            runOnUiThread(()->{
                if(previewEntry!=null && key.equals(previewEntry.id)) updateLiveEpg(out);
            });
        });
    }

    List<EpgItem> loadShortEpg(XtreamCreds x,MediaEntry e) throws Exception{ return CatalogRepository.loadShortEpg(x,e); }



    String epgTime(String s){
        if(s==null||s.trim().isEmpty())return ""; String t=s.trim();
        try{long v=Long.parseLong(t);if(v>1000000000L){SimpleDateFormat f=new SimpleDateFormat("h:mm a",Locale.US);return f.format(new Date(v*1000L));}}catch(Exception ignored){}
        if(t.length()>=16&&t.charAt(10)==' ')return t.substring(11,16);
        return t.length()>16?t.substring(0,16):t;
    }

    void renderLiveDetails(MediaEntry e,List<EpgItem> epg){
        clear(e.name==null?"Canal":e.name);

        LinearLayout head=new LinearLayout(this); head.setOrientation(LinearLayout.HORIZONTAL); head.setGravity(Gravity.TOP);

        LinearLayout infoPanel=new LinearLayout(this); infoPanel.setOrientation(LinearLayout.HORIZONTAL); infoPanel.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo=new ImageView(this); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); logo.setImageResource(R.drawable.aureon_logo);
        logo.setBackground(box(Color.rgb(10,11,12),12,GOLD,1)); if(e.poster!=null&&!e.poster.isEmpty())loadImage(e.poster,logo);
        infoPanel.addView(logo,new LinearLayout.LayoutParams(dp(compact?105:135),dp(compact?105:135)));

        LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); texts.setPadding(dp(16),0,0,0);
        TextView name=text(e.name==null?"Canal":e.name,compact?20:27); name.setTypeface(null,1); name.setMaxLines(2);
        texts.addView(name,new LinearLayout.LayoutParams(-1,dp(compact?56:68)));
        TextView grp=text(e.group==null?"":e.group,compact?10:13); grp.setTextColor(MUTED); grp.setMaxLines(2);
        texts.addView(grp,new LinearLayout.LayoutParams(-1,dp(36)));
        Button liveFav=button(PlaybackStore.isFavorite(this,e)?"★  FAVORITO":"☆  FAVORITAR");liveFav.setTextColor(GOLD);liveFav.setOnClickListener(v->{boolean on=PlaybackStore.toggleFavorite(this,e);liveFav.setText(on?"★  FAVORITO":"☆  FAVORITAR");});
        texts.addView(liveFav,new LinearLayout.LayoutParams(-1,dp(42)));
        LinearLayout extraActions=new LinearLayout(this); extraActions.setOrientation(LinearLayout.HORIZONTAL);
        Button multi=button("▦  MULTI-SCREEN"); multi.setTextColor(GOLD); multi.setOnClickListener(v->{setPlayerQueue(detailNavItems,e);startActivity(new Intent(this,MultiScreenActivity.class));});
        Button external=button("↗  PLAYER EXTERNO"); external.setTextColor(GOLD); external.setOnClickListener(v->ExternalPlayerUtil.open(this,e.url,e.name));
        extraActions.addView(multi,new LinearLayout.LayoutParams(0,dp(42),1)); LinearLayout.LayoutParams exlp=new LinearLayout.LayoutParams(0,dp(42),1);exlp.leftMargin=dp(6);extraActions.addView(external,exlp);
        texts.addView(extraActions,new LinearLayout.LayoutParams(-1,dp(44)));
        Button back=button(getString(R.string.ui_074)); back.setTextColor(GOLD); back.setOnClickListener(v->returnToSection(LIVE));
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(46)); bp.topMargin=dp(4); texts.addView(back,bp);
        addPrevNextButtons(texts,e,true);
        infoPanel.addView(texts,new LinearLayout.LayoutParams(0,dp(compact?235:270),1));

        // Player pequeno: começa sozinho. OK/Enter ou toque abre tela cheia.
        FrameLayout previewBox=new FrameLayout(this); previewBox.setBackground(box(Color.BLACK,12,GOLD,1));
        previewBox.setFocusable(true); previewBox.setClickable(true); previewBox.setFocusableInTouchMode(true);
        previewPlayerView=new PlayerView(this); previewPlayerView.setUseController(false); previewPlayerView.setKeepScreenOn(true);
        previewBox.addView(previewPlayerView,new FrameLayout.LayoutParams(-1,-1));
        TextView previewHint=text(getString(R.string.ui_075),compact?9:11); previewHint.setTextColor(WHITE); previewHint.setGravity(Gravity.CENTER); previewHint.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(30)); hp.gravity=Gravity.BOTTOM; previewBox.addView(previewHint,hp);
        View.OnClickListener openFull=v->openFullScreen(e);
        previewBox.setOnClickListener(openFull); previewPlayerView.setOnClickListener(openFull);
        View.OnKeyListener keyListener=(v,keyCode,event)->{
            if(event.getAction()==KeyEvent.ACTION_UP && (keyCode==KeyEvent.KEYCODE_DPAD_CENTER || keyCode==KeyEvent.KEYCODE_ENTER || keyCode==KeyEvent.KEYCODE_NUMPAD_ENTER)){
                openFullScreen(e); return true;
            }
            return false;
        };
        previewBox.setOnKeyListener(keyListener); previewPlayerView.setFocusable(false);

        LinearLayout leftWrap=new LinearLayout(this); leftWrap.setOrientation(LinearLayout.VERTICAL); leftWrap.addView(infoPanel,new LinearLayout.LayoutParams(-1,-1));
        head.addView(leftWrap,new LinearLayout.LayoutParams(0,dp(compact?250:290),1.0f));
        LinearLayout.LayoutParams pvLp=new LinearLayout.LayoutParams(0,dp(compact?250:290),1.15f); pvLp.leftMargin=dp(14); head.addView(previewBox,pvLp);
        content.addView(head,new LinearLayout.LayoutParams(-1,dp(compact?260:300)));

        startLivePreview(e);
        previewBox.postDelayed(previewBox::requestFocus,250);

        TextView ph=text(getString(R.string.ui_076),compact?18:22); ph.setTypeface(null,1); ph.setTextColor(GOLD);
        LinearLayout.LayoutParams php=new LinearLayout.LayoutParams(-1,dp(45)); php.topMargin=dp(10); content.addView(ph,php);
        liveEpgContainer=new LinearLayout(this); liveEpgContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(liveEpgContainer,new LinearLayout.LayoutParams(-1,-2));
        updateLiveEpg(epg);
    }

    void updateLiveEpg(List<EpgItem> epg){
        if(liveEpgContainer==null)return;
        liveEpgContainer.removeAllViews();
        if(epg==null){
            TextView loading=text(getString(R.string.ui_077),compact?11:14); loading.setTextColor(MUTED); loading.setGravity(Gravity.CENTER_VERTICAL); loading.setPadding(dp(14),dp(12),dp(14),dp(12));
            loading.setBackground(box(Color.rgb(13,14,16),12,Color.rgb(78,59,22),1));
            liveEpgContainer.addView(loading,new LinearLayout.LayoutParams(-1,dp(62))); return;
        }
        if(epg.isEmpty()){
            TextView none=text(getString(R.string.ui_078),compact?11:14); none.setTextColor(MUTED); none.setPadding(dp(14),dp(16),dp(14),dp(16)); none.setBackground(box(Color.rgb(13,14,16),12,Color.rgb(78,59,22),1));
            liveEpgContainer.addView(none,new LinearLayout.LayoutParams(-1,dp(70))); return;
        }
        int i=0;
        for(EpgItem p:epg){
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(dp(14),dp(10),dp(14),dp(10));
            row.setBackground(box(i==0?Color.rgb(34,27,14):Color.rgb(13,14,16),11,i==0?GOLD:Color.rgb(72,55,22),1));
            String range=epgTime(p.start)+(epgTime(p.end).isEmpty()?"":"  -  "+epgTime(p.end));
            TextView time=text(range,compact?9:11); time.setTextColor(i==0?GOLD:MUTED); row.addView(time,new LinearLayout.LayoutParams(-1,dp(24)));
            TextView title=text(p.title==null||p.title.isEmpty()?"Programa":p.title,compact?12:15); title.setTypeface(null,1); row.addView(title,new LinearLayout.LayoutParams(-1,dp(30)));
            if(p.description!=null&&!p.description.isEmpty()){TextView desc=text(p.description,compact?9:11);desc.setTextColor(MUTED);desc.setMaxLines(2);row.addView(desc,new LinearLayout.LayoutParams(-1,dp(38)));}
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(7); liveEpgContainer.addView(row,lp); i++;
        }
    }

    void startLivePreview(MediaEntry e){
        releasePreviewPlayerOnly();
        if(e==null||e.url==null||e.url.trim().isEmpty()||previewPlayerView==null)return;
        try{
            TransportPolicy.requireAllowed(e.url);
            OkHttpDataSource.Factory httpFactory=new OkHttpDataSource.Factory(NetworkClient.client())
                    .setUserAgent("Aureon/35.0");
            DefaultLoadControl loadControl=new DefaultLoadControl.Builder().setBufferDurationsMs(2500,12000,500,1000).setPrioritizeTimeOverSizeThresholds(true).build();
            previewPlayer=new ExoPlayer.Builder(this).setLoadControl(loadControl).setMediaSourceFactory(new DefaultMediaSourceFactory(httpFactory)).build();
            previewEntry=e; previewPlayerView.setPlayer(previewPlayer); previewPlayer.setHandleAudioBecomingNoisy(true);
            previewPlayer.setMediaItem(MediaItem.fromUri(e.url)); previewPlayer.setPlayWhenReady(true); previewPlayer.prepare();
        }catch(Exception error){ AppCrashReporter.record(this,error); releasePreviewPlayerOnly(); }
    }

    void releasePreviewPlayerOnly(){
        if(previewPlayerView!=null) previewPlayerView.setPlayer(null);
        if(previewPlayer!=null){ try{previewPlayer.release();}catch(Exception ignored){} }
        previewPlayer=null; previewEntry=null;
    }

    void openFullScreen(MediaEntry e){
        if(e==null||e.url==null||e.url.isEmpty())return;
        uiHandler.removeCallbacks(browserPreviewTask);pendingBrowserPreview=null;
        setPlayerQueue(detailNavItems,e);
        if(previewPlayer!=null)previewPlayer.pause();
        Intent i=new Intent(this,PlayerActivity.class); i.putExtra("url",e.url); i.putExtra("name",e.name); i.putExtra("kind",e.kind); startActivity(i);
    }

    void play(MediaEntry e){ if(e.url==null||e.url.isEmpty()){showInfo("Este item não possui link reproduzível.");return;} if(PLAYER_QUEUE.isEmpty())setPlayerQueue(detailNavItems,e); Intent i=new Intent(this,PlayerActivity.class); i.putExtra("url",e.url); i.putExtra("name",e.name); i.putExtra("kind",e.kind); startActivity(i); }

    void showSeriesEpisodes(MediaEntry series){ detailScreenKind=SERIES; currentSectionRequest=-1;
        clear(series.name); TextView loading=text(getString(R.string.ui_079),15); loading.setTextColor(MUTED); loading.setGravity(Gravity.CENTER); content.addView(loading,new LinearLayout.LayoutParams(-1,dp(120)));
        XtreamCreds x=savedXtream();
        exec.submit(()->{
            try{
                List<MediaEntry> eps=loadXtreamEpisodes(x,series);
                runOnUiThread(()->showSeasonFolders(series,eps));
            }catch(Exception e){
                runOnUiThread(()->showInfo("Não foi possível carregar as temporadas. "+friendlyError(e)));
            }
        });
    }

    void showSeasonFolders(MediaEntry series,List<MediaEntry> episodes){
        clear(series.name);
        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.TOP); top.setPadding(0,0,0,dp(8));
        ImageView poster=new ImageView(this); poster.setScaleType(ImageView.ScaleType.CENTER_CROP); poster.setImageResource(R.drawable.aureon_logo); if(series.poster!=null&&!series.poster.isEmpty())loadImage(series.poster,poster); poster.setBackground(box(Color.rgb(11,12,13),10,GOLD,1)); top.addView(poster,new LinearLayout.LayoutParams(dp(compact?115:155),dp(compact?165:220)));
        LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setPadding(dp(15),dp(4),0,0); TextView title=text(series.name,compact?21:28);title.setTypeface(null,1);info.addView(title,new LinearLayout.LayoutParams(-1,dp(compact?34:42))); TextView sub=text(getString(R.string.ui_080),compact?11:14);sub.setTextColor(MUTED);info.addView(sub,new LinearLayout.LayoutParams(-1,dp(30))); Button back=button(getString(R.string.ui_081));back.setTextColor(GOLD);back.setOnClickListener(v->returnToSection(SERIES));LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(dp(compact?190:245),dp(46));blp.topMargin=dp(14);info.addView(back,blp);top.addView(info,new LinearLayout.LayoutParams(0,dp(compact?165:220),1)); content.addView(top,new LinearLayout.LayoutParams(-1,dp(compact?175:230)));
        if(episodes==null||episodes.isEmpty()){TextView empty=text(getString(R.string.ui_082),14);empty.setTextColor(MUTED);empty.setGravity(Gravity.CENTER);content.addView(empty,new LinearLayout.LayoutParams(-1,dp(120)));return;}
        LinkedHashMap<String,List<MediaEntry>> bySeason=new LinkedHashMap<>(); for(MediaEntry e:episodes){String season=e.group==null||e.group.trim().isEmpty()?"Temporada":e.group.trim();bySeason.computeIfAbsent(season,k->new ArrayList<>()).add(e);} ArrayList<String> names=new ArrayList<>(bySeason.keySet());Collections.sort(names,(a,b)->Integer.compare(seasonNumber(a),seasonNumber(b)));
        addTitle(getString(R.string.ui_083),18); GridLayout grid=new GridLayout(this); int cols=compact?3:4;grid.setColumnCount(cols);int screenDp=getResources().getConfiguration().screenWidthDp;int available=Math.max(480,screenDp-navWidth-70);int w=Math.max(150,available/cols-12);
        for(String season:names){List<MediaEntry> eps=bySeason.get(season);Button folder=button(getString(R.string.ui_027)+season+"\n"+eps.size()+" episódios");folder.setTextColor(GOLD);folder.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);folder.setPadding(dp(14),0,dp(8),0);folder.setOnClickListener(v->showEpisodeList(series,season,episodes,eps));GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=dp(w);gp.height=dp(compact?72:82);gp.setMargins(dp(4),dp(4),dp(6),dp(6));grid.addView(folder,gp);} content.addView(grid,new LinearLayout.LayoutParams(-1,-2));
    }

    int seasonNumber(String name){
        if(name==null)return 9999; String digits=name.replaceAll("[^0-9]",""); if(digits.isEmpty())return 9999; try{return Integer.parseInt(digits);}catch(Exception e){return 9999;}
    }

    void showEpisodeList(MediaEntry series,String season,List<MediaEntry> allEpisodes,List<MediaEntry> seasonEpisodes){
        clear(series.name+" • "+season); LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);Button back=button(getString(R.string.ui_084));back.setTextColor(GOLD);back.setOnClickListener(v->showSeasonFolders(series,allEpisodes));head.addView(back,new LinearLayout.LayoutParams(dp(compact?155:200),dp(46)));TextView title=text(series.name+"  •  "+season,compact?16:21);title.setTypeface(null,1);title.setPadding(dp(14),0,0,0);head.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));content.addView(head,new LinearLayout.LayoutParams(-1,dp(54)));
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);int num=1;for(MediaEntry e:seasonEpisodes){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(5),dp(8),dp(5));row.setBackground(box(Color.rgb(12,13,14),10,Color.rgb(79,59,20),1));row.setClickable(true);row.setFocusable(true);ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);thumb.setImageResource(R.drawable.aureon_logo);if(e.poster!=null&&!e.poster.isEmpty())loadImage(e.poster,thumb);row.addView(thumb,new LinearLayout.LayoutParams(dp(compact?92:120),dp(compact?58:72)));LinearLayout texts=new LinearLayout(this);texts.setOrientation(LinearLayout.VERTICAL);texts.setPadding(dp(12),0,0,0);TextView ep=text(e.name==null||e.name.isEmpty()?"Episódio "+num:e.name,compact?11:14);ep.setTypeface(null,1);texts.addView(ep,new LinearLayout.LayoutParams(-1,dp(30)));TextView play=text(getString(R.string.ui_085),compact?9:11);play.setTextColor(GOLD);texts.addView(play,new LinearLayout.LayoutParams(-1,dp(24)));row.addView(texts,new LinearLayout.LayoutParams(0,-1,1));row.setOnClickListener(v->{setPlayerQueue(seasonEpisodes,e);play(e);});row.setOnFocusChangeListener((v,has)->v.setBackground(box(has?Color.rgb(38,29,14):Color.rgb(12,13,14),10,has?GOLD:Color.rgb(79,59,20),has?2:1)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(compact?70:84));lp.bottomMargin=dp(6);list.addView(row,lp);num++;}content.addView(list,new LinearLayout.LayoutParams(-1,-2));
    }

    List<MediaEntry> loadXtreamLive(XtreamCreds x) throws Exception{ return CatalogRepository.loadXtreamLive(x); }
    List<MediaEntry> loadXtreamLive(XtreamCreds x,Map<String,String> cats) throws Exception{ return CatalogRepository.loadXtreamLive(x,cats); }

    List<MediaEntry> loadXtreamMovies(XtreamCreds x) throws Exception{ return CatalogRepository.loadXtreamMovies(x); }
    List<MediaEntry> loadXtreamMovies(XtreamCreds x,Map<String,String> cats) throws Exception{ return CatalogRepository.loadXtreamMovies(x,cats); }

    List<MediaEntry> loadXtreamSeries(XtreamCreds x) throws Exception{ return CatalogRepository.loadXtreamSeries(x); }
    List<MediaEntry> loadXtreamSeries(XtreamCreds x,Map<String,String> cats) throws Exception{ return CatalogRepository.loadXtreamSeries(x,cats); }

    List<MediaEntry> loadXtreamEpisodes(XtreamCreds x,MediaEntry series) throws Exception{ return CatalogRepository.loadXtreamEpisodes(x,series); }

    LinkedHashMap<String,String> loadXtreamCategories(XtreamCreds x,String action) throws Exception{ return CatalogRepository.loadXtreamCategories(x,action); }
    LinkedHashMap<String,String> loadXtreamCategoriesSafe(XtreamCreds x,String action){ return CatalogRepository.loadXtreamCategoriesSafe(x,action); }




    List<MediaEntry> loadFromUri(Uri uri) throws Exception{
        String name=getFileName(uri); prefs.edit().putString("file_name",name).putString("file_uri",uri.toString()).apply(); InputStream in=getContentResolver().openInputStream(uri); if(in==null)throw new IOException("arquivo não pôde ser aberto");
        try(BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"))){return parseReader(r);}
    }

    List<MediaEntry> loadFromUrl(String s) throws Exception{ return CatalogRepository.loadFromUrl(s); }



    String getFileName(Uri uri){ try{Cursor c=getContentResolver().query(uri,null,null,null,null);if(c!=null){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(c.moveToFirst()&&i>=0){String n=c.getString(i);c.close();return n;}c.close();}}catch(Exception ignored){} String p=uri.getLastPathSegment();return p==null?"arquivo M3U":p; }

    List<MediaEntry> parseReader(BufferedReader r) throws Exception{ return CatalogRepository.parseReader(r); }





    class ChannelRecyclerAdapter extends RecyclerView.Adapter<ChannelRecyclerAdapter.Holder>{
        final ArrayList<MediaEntry> data=new ArrayList<>();
        ChannelRecyclerAdapter(){setHasStableIds(true);}
        void submit(List<MediaEntry> items){data.clear();if(items!=null)data.addAll(items);notifyDataSetChanged();}
        @Override public long getItemId(int position){return PlaybackStore.key(data.get(position)).hashCode();}
        @Override public Holder onCreateViewHolder(android.view.ViewGroup parent,int viewType){FrameLayout frame=new FrameLayout(MainActivity.this);frame.setFocusable(false);frame.setDescendantFocusability(android.view.ViewGroup.FOCUS_AFTER_DESCENDANTS);frame.setLayoutParams(new RecyclerView.LayoutParams(-1,dp(compact?56:64)));return new Holder(frame);}
        @Override public void onBindViewHolder(Holder h,int position){FrameLayout frame=(FrameLayout)h.itemView;frame.removeAllViews();LinearLayout row=makeLiveRow(data.get(position));frame.addView(row,new FrameLayout.LayoutParams(-1,-1));}
        @Override public void onViewRecycled(Holder h){((FrameLayout)h.itemView).removeAllViews();}
        @Override public int getItemCount(){return data.size();}
        class Holder extends RecyclerView.ViewHolder{Holder(View v){super(v);}}
    }

    class MediaRecyclerAdapter extends RecyclerView.Adapter<MediaRecyclerAdapter.Holder>{
        final ArrayList<MediaEntry> data=new ArrayList<>(); final int cols;
        MediaRecyclerAdapter(int cols){this.cols=cols;setHasStableIds(true);}
        void submit(List<MediaEntry> items){data.clear();if(items!=null)data.addAll(items);notifyDataSetChanged();}
        @Override public long getItemId(int position){return PlaybackStore.key(data.get(position)).hashCode();}
        @Override public Holder onCreateViewHolder(android.view.ViewGroup parent,int viewType){FrameLayout frame=new FrameLayout(MainActivity.this);frame.setFocusable(false);frame.setDescendantFocusability(android.view.ViewGroup.FOCUS_AFTER_DESCENDANTS);return new Holder(frame);}
        @Override public void onBindViewHolder(Holder h,int position){
            int screenDp=getResources().getConfiguration().screenWidthDp;int catW=compact?225:285;int usable=Math.max(380,screenDp-(navHidden?0:navWidth)-catW-70);int cardW=Math.max(compact?118:145,usable/cols-8);int posterH=(int)(cardW*1.42f);
            FrameLayout frame=(FrameLayout)h.itemView;frame.removeAllViews();MediaEntry entry=data.get(position);LinearLayout card=makePosterCard(entry,cardW,posterH);final int adapterPos=position;card.setOnKeyListener((v,key,event)->{if(event.getAction()!=KeyEvent.ACTION_DOWN)return false;if(key==KeyEvent.KEYCODE_DPAD_LEFT&&adapterPos%cols==0){lastFocusedMediaKey=PlaybackStore.key(entry);focusActiveCategory();return true;}return false;});frame.addView(card,new FrameLayout.LayoutParams(-1,-1));RecyclerView.LayoutParams lp=new RecyclerView.LayoutParams(dp(cardW),dp(posterH+(compact?62:72)));lp.setMargins(dp(4),dp(4),dp(4),dp(8));frame.setLayoutParams(lp);
        }
        @Override public void onViewRecycled(Holder h){((FrameLayout)h.itemView).removeAllViews();}
        @Override public int getItemCount(){return data.size();}
        class Holder extends RecyclerView.ViewHolder{Holder(View v){super(v);}}
    }

    void showInfo(String s){ currentSectionRequest=-1; clear(getString(R.string.ui_086)); TextView t=text(s,compact?13:16);t.setTextColor(MUTED);t.setGravity(Gravity.CENTER);content.addView(t,new LinearLayout.LayoutParams(-1,dp(130)));Button b=button(getString(R.string.ui_087));b.setTextColor(GOLD);b.setOnClickListener(v->showSetup());content.addView(b,new LinearLayout.LayoutParams(-1,dp(52))); }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==77&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){selectedM3u=data.getData();try{int flags=data.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION;getContentResolver().takePersistableUriPermission(selectedM3u,flags);}catch(Exception ignored){}prefs.edit().putString("file_uri",selectedM3u.toString()).putString("source_mode","file").apply();showSetup();}}
    @Override protected void onStop(){
        super.onStop();
        if(previewPlayer!=null) previewPlayer.pause();
    }

    @Override protected void onStart(){
        super.onStart();
        if(previewPlayer!=null) previewPlayer.play();
    }

    @Override public void onBackPressed(){
        // Primeiro fecha teclado/pesquisa, sem sair da tela.
        if(dismissSearchFocus())return;

        // Sem lista configurada, permanece na tela de cadastro em vez de abrir a Home demonstrativa.
        if(resolveSourceMode().isEmpty()){
            if(!"Adicionar Playlist".equals(activeScreen))showPlaylistManager();
            return;
        }

        // Detalhes voltam exatamente para a seção/categoria de origem.
        if(detailScreenKind>=LIVE&&detailScreenKind<=SERIES){returnToSection(detailScreenKind);return;}
        if("Adicionar Playlist".equals(activeScreen)||"QR Code / Dispositivo".equals(activeScreen)){showSetup();return;}

        // Em TV/Filmes/Séries, Voltar enquanto o foco está no conteúdo retorna para a categoria ativa.
        LinearLayout catParent=liveCategoryColumn!=null?liveCategoryColumn:categoryColumn;
        View focused=getCurrentFocus();
        if(catParent!=null&&!isDescendantOf(focused,catParent)){focusActiveCategory();return;}

        // Da coluna de categorias, Voltar retorna à página inicial.
        if(!"Início".equals(activeScreen)){showHome();return;}

        // Na tela inicial, um toque nunca fecha o app por acidente. Exige dois toques em 2 s.
        long now=SystemClock.uptimeMillis();
        if(now-lastBackPressAt<2000L){finish();return;}
        lastBackPressAt=now;
        Toast.makeText(this,R.string.back_again_exit,Toast.LENGTH_SHORT).show();
    }

    @Override public void onTrimMemory(int level){
        super.onTrimMemory(level);
        if(level>=android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL){
            try{com.bumptech.glide.Glide.get(this).clearMemory();}catch(Exception ignored){}
            detailCache.clear(); epgCache.clear();
        }else if(level>=android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW){
            try{com.bumptech.glide.Glide.get(this).trimMemory(level);}catch(Exception ignored){}
        }
    }

    @Override public void onLowMemory(){
        super.onLowMemory();
        try{com.bumptech.glide.Glide.get(this).clearMemory();}catch(Exception ignored){} detailCache.clear(); epgCache.clear();
    }

    @Override protected void onDestroy(){
        uiHandler.removeCallbacks(prepareStartupTask);
        uiHandler.removeCallbacks(finishStartupTask);
        activationPolling=false;
        uiHandler.removeCallbacks(activationPollTask);
        releasePreviewPlayer();
        exec.shutdownNow(); dataExec.shutdownNow(); cacheExec.shutdown(); super.onDestroy();
    }
}
