package com.mtiptv.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Map;

/** Central preferences entry point. Migrates the legacy "mt" preferences once. */
final class AppPrefs {
    private static final String NAME = "aureon";
    private static final String LEGACY = "mt";
    private static final String MIGRATED = "legacy_mt_migrated";

    static SharedPreferences get(Context context) {
        SharedPreferences current = context.getSharedPreferences(NAME, Context.MODE_PRIVATE);
        if (!current.getBoolean(MIGRATED, false)) {
            SharedPreferences old = context.getSharedPreferences(LEGACY, Context.MODE_PRIVATE);
            SharedPreferences.Editor out = current.edit();
            for (Map.Entry<String, ?> entry : old.getAll().entrySet()) {
                String key = entry.getKey(); Object value = entry.getValue();
                if (current.contains(key)) continue;
                if (value instanceof String) out.putString(key, (String) value);
                else if (value instanceof Boolean) out.putBoolean(key, (Boolean) value);
                else if (value instanceof Integer) out.putInt(key, (Integer) value);
                else if (value instanceof Long) out.putLong(key, (Long) value);
                else if (value instanceof Float) out.putFloat(key, (Float) value);
                else if (value instanceof java.util.Set) {
                    try { out.putStringSet(key, (java.util.Set<String>) value); } catch (Exception ignored) {}
                }
            }
            out.putBoolean(MIGRATED, true).apply();
        }
        return current;
    }

    private AppPrefs() {}
}
