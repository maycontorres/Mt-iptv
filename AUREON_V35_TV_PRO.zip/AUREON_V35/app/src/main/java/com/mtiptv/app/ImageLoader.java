package com.mtiptv.app;

import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

/** Central image pipeline backed by Glide memory + disk cache. */
final class ImageLoader {
    static void load(ImageView target, String url, int placeholderRes) {
        if (target == null) return;
        if (url == null || url.trim().isEmpty()) {
            target.setImageResource(placeholderRes);
            return;
        }
        try {
            TransportPolicy.requireAllowed(url);
            Glide.with(target)
                    .load(url)
                    .placeholder(placeholderRes)
                    .error(placeholderRes)
                    .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                    .centerCrop()
                    .into(target);
        } catch (Exception blocked) {
            target.setImageResource(placeholderRes);
        }
    }

    private ImageLoader() {}
}
