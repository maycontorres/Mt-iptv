package com.mtiptv.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

final class ExternalPlayerUtil {
    static void open(Activity a, String url, String title) {
        if (url == null || url.trim().isEmpty()) return;
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.parse(url), "video/*");
            i.putExtra("title", title == null ? "ÁUREON" : title);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            a.startActivity(Intent.createChooser(i, "Abrir com player externo"));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(a, "Nenhum player externo encontrado.", Toast.LENGTH_LONG).show();
        }
    }
    private ExternalPlayerUtil() {}
}
