package com.mtiptv.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Favorites, history and resume points. Kept separate from credentials/catalog code. */
final class PlaybackStore {
    private static final String PREF = "aureon_user_state_v2";
    private static final String FAVORITES = "favorites";
    private static final String RECENTS = "recents";
    private static final String PROGRESS = "progress";

    static String key(MediaEntry e) {
        if (e == null) return "";
        String identity = e.id != null && !e.id.trim().isEmpty() ? e.id : (e.url != null && !e.url.trim().isEmpty() ? e.url : e.name);
        return e.kind + "|" + Integer.toHexString((identity == null ? "" : identity).hashCode());
    }

    static boolean isFavorite(Context c, MediaEntry e) {
        try { return favoritesObject(c).has(key(e)); } catch (Exception ignored) { return false; }
    }

    static boolean toggleFavorite(Context c, MediaEntry e) {
        JSONObject all = favoritesObject(c); String k = key(e); boolean now;
        try {
            if (all.has(k)) { all.remove(k); now = false; }
            else { all.put(k, entryToJson(e)); now = true; }
            prefs(c).edit().putString(FAVORITES, all.toString()).apply();
            return now;
        } catch (Exception ignored) { return false; }
    }

    static List<MediaEntry> favorites(Context c) {
        ArrayList<MediaEntry> out = new ArrayList<>(); JSONObject all = favoritesObject(c);
        java.util.Iterator<String> it = all.keys(); while (it.hasNext()) {
            JSONObject o = all.optJSONObject(it.next()); MediaEntry e = entryFromJson(o); if (e != null) out.add(e);
        }
        return out;
    }

    static void markRecent(Context c, MediaEntry e) {
        if (e == null) return;
        try {
            JSONArray old = recentArray(c); JSONArray next = new JSONArray(); String k = key(e);
            JSONObject first = new JSONObject(); first.put("key", k); first.put("last", System.currentTimeMillis()); first.put("entry", entryToJson(e)); next.put(first);
            for (int i = 0; i < old.length() && next.length() < 100; i++) {
                JSONObject x = old.optJSONObject(i); if (x == null || k.equals(x.optString("key", ""))) continue; next.put(x);
            }
            prefs(c).edit().putString(RECENTS, next.toString()).apply();
        } catch (Exception ignored) {}
    }

    static List<MediaEntry> recents(Context c, int limit) {
        ArrayList<MediaEntry> out = new ArrayList<>(); JSONArray a = recentArray(c);
        for (int i = 0; i < a.length() && out.size() < limit; i++) { JSONObject x = a.optJSONObject(i); MediaEntry e = entryFromJson(x == null ? null : x.optJSONObject("entry")); if (e != null) out.add(e); }
        return out;
    }

    static void clearRecents(Context c, int kind) {
        try {
            JSONArray a = recentArray(c), next = new JSONArray();
            for (int i = 0; i < a.length(); i++) {
                JSONObject x = a.optJSONObject(i); MediaEntry e = entryFromJson(x == null ? null : x.optJSONObject("entry"));
                if (e == null || e.kind != kind) next.put(x);
            }
            prefs(c).edit().putString(RECENTS, next.toString()).apply();
        } catch (Exception ignored) {}
    }

    static void clearAllHistory(Context c) { prefs(c).edit().remove(RECENTS).remove(PROGRESS).apply(); }

    static void saveProgress(Context c, MediaEntry e, long positionMs, long durationMs) {
        if (e == null || e.kind == MainActivity.LIVE) return;
        String k = key(e); JSONObject all = progressObject(c);
        try {
            if (durationMs > 0 && positionMs >= durationMs - 30000) {
                all.remove(k);
            } else if (positionMs >= 15000) {
                JSONObject p = new JSONObject(); p.put("position", Math.max(0, positionMs)); p.put("duration", Math.max(0, durationMs)); p.put("last", System.currentTimeMillis()); p.put("entry", entryToJson(e)); all.put(k, p);
            } else {
                return; // Do not erase an existing resume point during initial player setup/reconnect.
            }
            prefs(c).edit().putString(PROGRESS, all.toString()).apply();
        } catch (Exception ignored) {}
    }

    static long progressMs(Context c, MediaEntry e) {
        JSONObject p = progressObject(c).optJSONObject(key(e)); return p == null ? 0 : p.optLong("position", 0);
    }

    static List<MediaEntry> continueWatching(Context c, int limit) {
        ArrayList<ProgressRow> rows = new ArrayList<>(); JSONObject all = progressObject(c); java.util.Iterator<String> it = all.keys();
        while (it.hasNext()) { JSONObject p = all.optJSONObject(it.next()); if (p == null) continue; MediaEntry e = entryFromJson(p.optJSONObject("entry")); if (e != null) rows.add(new ProgressRow(e, p.optLong("last", 0))); }
        Collections.sort(rows, (a,b)->Long.compare(b.last, a.last)); ArrayList<MediaEntry> out = new ArrayList<>();
        for (ProgressRow r : rows) { out.add(r.e); if (out.size() >= limit) break; } return out;
    }

    static int favoriteCount(Context c) { return favoritesObject(c).length(); }

    private static final class ProgressRow { final MediaEntry e; final long last; ProgressRow(MediaEntry e,long last){this.e=e;this.last=last;} }
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }
    private static JSONObject favoritesObject(Context c) { try { return new JSONObject(prefs(c).getString(FAVORITES, "{}")); } catch (Exception e) { return new JSONObject(); } }
    private static JSONObject progressObject(Context c) { try { return new JSONObject(prefs(c).getString(PROGRESS, "{}")); } catch (Exception e) { return new JSONObject(); } }
    private static JSONArray recentArray(Context c) { try { return new JSONArray(prefs(c).getString(RECENTS, "[]")); } catch (Exception e) { return new JSONArray(); } }

    static JSONObject entryToJson(MediaEntry e) throws Exception {
        JSONObject o = new JSONObject(); if (e == null) return o;
        o.put("id", nz(e.id)); o.put("name", nz(e.name)); o.put("url", nz(e.url)); o.put("group", nz(e.group)); o.put("extension", nz(e.extension));
        o.put("poster", nz(e.poster)); o.put("rating", nz(e.rating)); o.put("year", nz(e.year)); o.put("added", nz(e.added)); o.put("kind", e.kind); o.put("tvArchive",e.tvArchive); o.put("tvArchiveDuration",e.tvArchiveDuration); o.put("epgChannelId",nz(e.epgChannelId)); return o;
    }

    static MediaEntry entryFromJson(JSONObject o) {
        if (o == null) return null;
        return new MediaEntry(o.optString("id", ""), o.optString("name", ""), o.optString("url", ""), o.optString("group", ""),
                o.optString("extension", ""), o.optInt("kind", MainActivity.MOVIE), o.optString("poster", ""), o.optString("rating", ""), o.optString("year", ""), o.optString("added", "")).withArchive(o.optBoolean("tvArchive",false),o.optInt("tvArchiveDuration",0),o.optString("epgChannelId",""));
    }
    private static String nz(String s) { return s == null ? "" : s; }
}
