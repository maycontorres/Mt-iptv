package com.mtiptv.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import java.io.InputStream;
import java.util.concurrent.Executors;
import okhttp3.Request;
import okhttp3.Response;

public class SpeedTestActivity extends Activity {
    TextView status;
    @Override public void onCreate(Bundle b){super.onCreate(b);LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setGravity(Gravity.CENTER);r.setPadding(40,40,40,40);r.setBackgroundColor(Color.rgb(5,5,6));TextView t=new TextView(this);t.setText("Teste de velocidade");t.setTextColor(Color.rgb(229,178,63));t.setTextSize(28);t.setGravity(Gravity.CENTER);r.addView(t,new LinearLayout.LayoutParams(-1,70));status=new TextView(this);status.setText("Pronto para testar sua conexão.");status.setTextColor(Color.WHITE);status.setTextSize(20);status.setGravity(Gravity.CENTER);r.addView(status,new LinearLayout.LayoutParams(-1,110));Button go=new Button(this);go.setText("INICIAR TESTE");go.setOnClickListener(v->runTest(go));r.addView(go,new LinearLayout.LayoutParams(420,70));setContentView(r);}
    void runTest(Button go){go.setEnabled(false);status.setText("Medindo download…");Executors.newSingleThreadExecutor().submit(()->{long bytes=0,start=System.nanoTime();try{Request q=new Request.Builder().url("https://speed.cloudflare.com/__down?bytes=5000000").build();try(Response r=NetworkClient.client().newCall(q).execute()){if(!r.isSuccessful()||r.body()==null)throw new Exception("HTTP "+r.code());InputStream in=r.body().byteStream();byte[] b=new byte[64*1024];int n;while((n=in.read(b))!=-1)bytes+=n;}double sec=(System.nanoTime()-start)/1e9,mbps=(bytes*8d/1_000_000d)/Math.max(.001,sec);runOnUiThread(()->{status.setText(String.format(java.util.Locale.US,"%.1f Mbps\n%s",mbps,mbps>=25?"Boa para IPTV 4K em condições normais.":mbps>=10?"Adequada para HD; 4K pode oscilar.":"Baixa para IPTV estável."));go.setEnabled(true);});}catch(Exception e){runOnUiThread(()->{status.setText("Falha no teste: "+e.getMessage());go.setEnabled(true);});}});}
}
