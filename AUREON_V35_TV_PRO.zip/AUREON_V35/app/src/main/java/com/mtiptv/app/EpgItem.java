package com.mtiptv.app;

final class EpgItem {
    String title = "", description = "", start = "", end = "";
    EpgItem(String t, String d, String s, String e) { title = t; description = d; start = s; end = e; }
}
