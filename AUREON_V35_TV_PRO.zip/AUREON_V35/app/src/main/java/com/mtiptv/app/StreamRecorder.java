package com.mtiptv.app;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import java.io.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import okhttp3.Request;
import okhttp3.Response;

final class StreamRecorder {
    interface Callback { void onStarted(String name); void onStopped(String message); void onError(String message); }
    private final Context context; private final ExecutorService exec=Executors.newSingleThreadExecutor(); private final AtomicBoolean recording=new AtomicBoolean(false); private volatile okhttp3.Call call;
    StreamRecorder(Context c){context=c.getApplicationContext();}
    boolean isRecording(){return recording.get();}
    void start(String url,String title,Callback cb){if(recording.get())return;if(url==null||url.contains(".m3u8")){cb.onError("Gravação direta ainda não suporta HLS/M3U8. Use um canal TS.");return;}recording.set(true);exec.submit(()->{OutputStream out=null;Uri uri=null;try{String safe=(title==null?"canal":title).replaceAll("[^A-Za-z0-9._-]","_");String name="AUREON_"+safe+"_"+System.currentTimeMillis()+".ts";if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Video.Media.DISPLAY_NAME,name);v.put(MediaStore.Video.Media.MIME_TYPE,"video/mp2t");v.put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/AUREON");uri=context.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,v);if(uri==null)throw new IOException("não foi possível criar o arquivo");out=context.getContentResolver().openOutputStream(uri);if(out==null)throw new IOException("não foi possível abrir o arquivo");}else{File d=new File(context.getExternalFilesDir(null),"AUREON_Recordings");d.mkdirs();out=new FileOutputStream(new File(d,name));}cb.onStarted(name);Request req=new Request.Builder().url(url).build();call=NetworkClient.client().newCall(req);try(Response r=call.execute()){if(!r.isSuccessful()||r.body()==null)throw new IOException("HTTP "+r.code());InputStream in=r.body().byteStream();byte[] b=new byte[64*1024];int n;while(recording.get()&&(n=in.read(b))!=-1)out.write(b,0,n);}cb.onStopped("Gravação finalizada em Movies/AUREON.");}catch(Exception e){if(!recording.get()){cb.onStopped("Gravação finalizada em Movies/AUREON.");}else{cb.onError("Falha ao gravar: "+e.getMessage());if(uri!=null)try{context.getContentResolver().delete(uri,null,null);}catch(Exception ignored){}}}finally{recording.set(false);if(out!=null)try{out.close();}catch(Exception ignored){}}});}
    void stop(){recording.set(false);if(call!=null)call.cancel();}
}
