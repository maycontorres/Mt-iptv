package com.mtiptv.app;

import android.content.Context;
import android.provider.Settings;
import java.security.MessageDigest;

final class DeviceKeyUtil {
    static String key(Context c) {
        try {
            String id = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ANDROID_ID);
            if (id == null) id = "AUREON";
            MessageDigest md = MessageDigest.getInstance("SHA-256"); byte[] d = md.digest((id + "|AUREON").getBytes("UTF-8"));
            long n = 0; for (int i = 0; i < 4; i++) n = (n << 8) | (d[i] & 0xffL);
            return String.format(java.util.Locale.US, "%06d", n % 1000000L);
        } catch (Exception e) { return "000000"; }
    }
}
