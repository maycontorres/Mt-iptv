package com.mtiptv.app;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Local crash fallback. If Firebase Crashlytics is later configured, record() also
 * forwards non-fatal errors through reflection without making Firebase mandatory.
 */
final class AppCrashReporter {
    private static volatile boolean installed;

    static synchronized void install(Context context) {
        if (installed) return;
        installed = true;
        Context app = context.getApplicationContext();
        Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try { write(app, error); forwardToCrashlytics(error); } catch (Exception ignored) {}
            if (previous != null) previous.uncaughtException(thread, error);
        });
    }

    static void record(Context context, Throwable error) {
        if (error == null) return;
        try { write(context.getApplicationContext(), error); } catch (Exception ignored) {}
        forwardToCrashlytics(error);
    }

    static File latest(Context context) {
        File dir = new File(context.getFilesDir(), "crash_reports");
        File[] files = dir.listFiles();
        if (files == null || files.length == 0) return null;
        File latest = files[0];
        for (File f : files) if (f.lastModified() > latest.lastModified()) latest = f;
        return latest;
    }

    private static void write(Context context, Throwable error) throws Exception {
        File dir = new File(context.getFilesDir(), "crash_reports");
        if (!dir.exists()) dir.mkdirs();
        String name = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".log";
        StringWriter sw = new StringWriter();
        error.printStackTrace(new PrintWriter(sw));
        String text = "AUREON " + BuildConfig.VERSION_NAME + "\n" + TransportPolicy.redact(sw.toString());
        try (FileOutputStream out = new FileOutputStream(new File(dir, name))) {
            out.write(text.getBytes(StandardCharsets.UTF_8));
        }
        trim(dir, 5);
    }

    private static void trim(File dir, int keep) {
        File[] files = dir.listFiles();
        if (files == null || files.length <= keep) return;
        java.util.Arrays.sort(files, (a,b) -> Long.compare(b.lastModified(), a.lastModified()));
        for (int i = keep; i < files.length; i++) try { files[i].delete(); } catch (Exception ignored) {}
    }

    private static void forwardToCrashlytics(Throwable error) {
        try {
            Class<?> clazz = Class.forName("com.google.firebase.crashlytics.FirebaseCrashlytics");
            Object instance = clazz.getMethod("getInstance").invoke(null);
            clazz.getMethod("recordException", Throwable.class).invoke(instance, error);
        } catch (Throwable ignored) {
            // Firebase is optional until a google-services.json is connected.
        }
    }

    private AppCrashReporter() {}
}
