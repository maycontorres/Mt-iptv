package com.mtiptv.app;

import java.io.IOException;
import java.net.URI;

/** Central transport policy for secure vs legacy-compatible builds. */
final class TransportPolicy {
    static void requireAllowed(String url) throws IOException {
        if (url == null || url.trim().isEmpty()) throw new IOException("URL vazia");
        String lower = url.trim().toLowerCase(java.util.Locale.US);
        if (lower.startsWith("http://") && !BuildConfig.ALLOW_CLEARTEXT) {
            throw new IOException("Conexão HTTP bloqueada por segurança. Use HTTPS ou a edição Compatibilidade para servidores antigos.");
        }
    }

    static boolean isCleartext(String url) {
        return url != null && url.trim().toLowerCase(java.util.Locale.US).startsWith("http://");
    }

    static String redact(String value) {
        if (value == null) return "";
        String out = value;
        out = out.replaceAll("(?i)(username=)[^&\\s]+", "$1***");
        out = out.replaceAll("(?i)(password=)[^&\\s]+", "$1***");
        out = out.replaceAll("(?i)(token=)[^&\\s]+", "$1***");
        return out;
    }

    private TransportPolicy() {}
}
