package com.mtiptv.app;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Pattern;

/** Matches the title printed in the home artwork, never an unrelated catalog item. */
final class FeaturedMatcher {
    private static final Pattern MARKS=Pattern.compile("\\p{M}+");
    private static final Pattern LABELS=Pattern.compile("\\b(?:(?:19|20)\\d{2}|4k|8k|uhd|fhd|hd|sd|hdr|h265|h264|hevc|720p|1080p|2160p|dual|audio|dublado|dublada|dub|legendado|legendada|leg|nacional|ptbr|pt-br)\\b");
    private static final Pattern SEPARATORS=Pattern.compile("[^a-z0-9]+");
    private FeaturedMatcher() {}

    static boolean matches(String name,String[] aliases){
        String candidate=normalize(name);
        if(candidate.isEmpty())return false;
        for(String alias:aliases)if(candidate.equals(normalize(alias)))return true;
        return false;
    }

    static String normalize(String name){
        if(name==null)return "";
        String value=MARKS.matcher(Normalizer.normalize(name,Normalizer.Form.NFD))
                .replaceAll("").toLowerCase(Locale.ROOT);
        // Provider labels and release years do not identify a different movie/series.
        value=LABELS.matcher(value).replaceAll(" ");
        return SEPARATORS.matcher(value).replaceAll(" ").trim();
    }
}
