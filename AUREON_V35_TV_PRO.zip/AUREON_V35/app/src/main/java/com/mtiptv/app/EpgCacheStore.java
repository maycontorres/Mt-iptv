package com.mtiptv.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

final class EpgCacheStore {
    private static final String PREF="aureon_epg_cache_v1";
    private static final long TTL=4L*60L*60L*1000L;
    static void save(Context c,MediaEntry e,List<EpgItem> list){if(e==null||e.id==null||e.id.isEmpty()||list==null)return;try{JSONObject root=new JSONObject();root.put("at",System.currentTimeMillis());JSONArray a=new JSONArray();for(EpgItem p:list){JSONObject o=new JSONObject();o.put("title",p.title);o.put("description",p.description);o.put("start",p.start);o.put("end",p.end);a.put(o);}root.put("items",a);prefs(c).edit().putString(key(e),root.toString()).apply();}catch(Exception ignored){}}
    static List<EpgItem> load(Context c,MediaEntry e){ArrayList<EpgItem> out=new ArrayList<>();if(e==null)return out;try{JSONObject root=new JSONObject(prefs(c).getString(key(e),"{}"));if(System.currentTimeMillis()-root.optLong("at",0)>TTL)return out;JSONArray a=root.optJSONArray("items");if(a!=null)for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)out.add(new EpgItem(o.optString("title","Programa"),o.optString("description",""),o.optString("start",""),o.optString("end","")));}}catch(Exception ignored){}return out;}
    static void clear(Context c){prefs(c).edit().clear().apply();}
    private static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    private static String key(MediaEntry e){return "epg_"+Integer.toHexString((e.id==null?"":e.id).hashCode());}
    private EpgCacheStore(){}
}
