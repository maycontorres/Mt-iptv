package com.mtiptv.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.media3.common.MediaItem;
import androidx.media3.datasource.okhttp.OkHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import java.util.*;

public class MultiScreenActivity extends Activity {
    private final ArrayList<ExoPlayer> players=new ArrayList<>();
    private final ArrayList<FrameLayout> panes=new ArrayList<>();
    private ArrayList<MediaEntry> entries=new ArrayList<>();
    private int focused=0;
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);entries=MainActivity.playerQueueSnapshot();int start=Math.max(0,MainActivity.getPlayerQueueIndex());ArrayList<MediaEntry> live=new ArrayList<>();for(int i=start;i<entries.size()&&live.size()<4;i++)if(entries.get(i).kind==MainActivity.LIVE)live.add(entries.get(i));for(int i=0;i<start&&live.size()<4;i++)if(entries.get(i).kind==MainActivity.LIVE)live.add(entries.get(i));entries=live;build();}
    void build(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.BLACK);TextView h=new TextView(this);h.setText("MULTI-SCREEN • setas mudam a tela • OK abre em tela cheia");h.setTextColor(Color.WHITE);h.setGravity(Gravity.CENTER);h.setTextSize(14);root.addView(h,new LinearLayout.LayoutParams(-1,42));GridLayout grid=new GridLayout(this);grid.setColumnCount(2);grid.setRowCount(2);root.addView(grid,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);for(int i=0;i<4;i++){FrameLayout pane=new FrameLayout(this);pane.setBackgroundColor(Color.rgb(12,12,12));pane.setFocusable(true);pane.setTag(i);if(i<entries.size())attach(pane,entries.get(i),i);else{TextView empty=new TextView(this);empty.setText("Sem outro canal na fila");empty.setTextColor(Color.GRAY);empty.setGravity(Gravity.CENTER);pane.addView(empty,new FrameLayout.LayoutParams(-1,-1));}GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=0;gp.height=0;gp.columnSpec=GridLayout.spec(i%2,1,1f);gp.rowSpec=GridLayout.spec(i/2,1,1f);gp.setMargins(3,3,3,3);grid.addView(pane,gp);panes.add(pane);}focusPane(0);}
    void attach(FrameLayout pane,MediaEntry e,int index){PlayerView pv=new PlayerView(this);pv.setUseController(false);pv.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM);pane.addView(pv,new FrameLayout.LayoutParams(-1,-1));TextView label=new TextView(this);label.setText(e.name);label.setTextColor(Color.WHITE);label.setBackgroundColor(0x99000000);label.setPadding(10,6,10,6);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,42,Gravity.BOTTOM);pane.addView(label,lp);OkHttpDataSource.Factory f=new OkHttpDataSource.Factory(NetworkClient.client()).setUserAgent("Aureon/35.0");ExoPlayer p=new ExoPlayer.Builder(this).setMediaSourceFactory(new DefaultMediaSourceFactory(f)).build();pv.setPlayer(p);p.setMediaItem(MediaItem.fromUri(e.url));p.setVolume(index==0?1f:0f);p.prepare();p.play();players.add(p);pane.setOnClickListener(v->open(index));pane.setOnKeyListener((v,k,event)->{if(event.getAction()!=KeyEvent.ACTION_DOWN)return false;if(k==KeyEvent.KEYCODE_DPAD_CENTER||k==KeyEvent.KEYCODE_ENTER){open(index);return true;}if(k==KeyEvent.KEYCODE_DPAD_LEFT){focusPane(index%2==1?index-1:index);return true;}if(k==KeyEvent.KEYCODE_DPAD_RIGHT){focusPane(index%2==0?Math.min(3,index+1):index);return true;}if(k==KeyEvent.KEYCODE_DPAD_UP){focusPane(index>=2?index-2:index);return true;}if(k==KeyEvent.KEYCODE_DPAD_DOWN){focusPane(index<2?Math.min(3,index+2):index);return true;}return false;});}
    void focusPane(int idx){if(idx<0||idx>=panes.size())return;focused=idx;for(int i=0;i<panes.size();i++)panes.get(i).setBackgroundColor(i==idx?Color.rgb(229,178,63):Color.rgb(12,12,12));for(int i=0;i<players.size();i++)players.get(i).setVolume(i==idx?1f:0f);panes.get(idx).requestFocus();}
    void open(int idx){if(idx>=entries.size())return;MediaEntry e=entries.get(idx);Intent i=new Intent(this,PlayerActivity.class);i.putExtra("url",e.url);i.putExtra("name",e.name);i.putExtra("kind",e.kind);startActivity(i);}
    @Override protected void onDestroy(){for(ExoPlayer p:players)try{p.release();}catch(Exception ignored){}players.clear();super.onDestroy();}
}
