package com.mtiptv.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

final class ProfileStore {
    static final class Profile { String name,mode,server,user,pass,m3u,epg; Profile(String n,String m,String s,String u,String p,String mu,String e){name=n;mode=m;server=s;user=u;pass=p;m3u=mu;epg=e;} }
    private static final String KEY="profiles_secure_v1";

    static List<Profile> list(Context c){ ArrayList<Profile> out=new ArrayList<>(); try{JSONArray a=new JSONArray(AppPrefs.get(c).getString(KEY,"[]"));for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;out.add(new Profile(o.optString("name","Perfil"),o.optString("mode",""),o.optString("server",""),dec(o.optString("user","")),dec(o.optString("pass","")),dec(o.optString("m3u","")),dec(o.optString("epg",""))));}}catch(Exception ignored){}return out; }
    static void saveCurrent(Context c,String name){ SharedPreferences p=AppPrefs.get(c);String mode=p.getString("source_mode","");if(mode.isEmpty())return;Profile n=new Profile(name==null||name.trim().isEmpty()?"Playlist":name.trim(),mode,p.getString("xt_server",""),CredentialStore.user(p),CredentialStore.pass(p),CredentialStore.m3uUrl(p),CredentialStore.epgUrl(p));List<Profile> all=list(c);for(int i=all.size()-1;i>=0;i--)if(all.get(i).name.equalsIgnoreCase(n.name))all.remove(i);all.add(0,n);write(c,all); }
    static void remove(Context c,int index){List<Profile> all=list(c);if(index>=0&&index<all.size()){all.remove(index);write(c,all);} }
    static void activate(Context c,Profile x){ if(x==null)return;SharedPreferences p=AppPrefs.get(c);p.edit().putString("source_mode",x.mode).putString("xt_server",x.server==null?"":x.server).putString("playlist_name",x.name==null?"":x.name).apply();CredentialStore.clearAllSourceSecrets(p);if("xtream".equals(x.mode))CredentialStore.save(p,x.user,x.pass);else if("m3u".equals(x.mode))CredentialStore.saveM3uUrl(p,x.m3u);CredentialStore.saveEpgUrl(p,x.epg);CatalogCache.clear(c); }
    private static void write(Context c,List<Profile> all){try{JSONArray a=new JSONArray();for(Profile x:all){JSONObject o=new JSONObject();o.put("name",x.name);o.put("mode",x.mode);o.put("server",x.server);o.put("user",enc(x.user));o.put("pass",enc(x.pass));o.put("m3u",enc(x.m3u));o.put("epg",enc(x.epg));a.put(o);}AppPrefs.get(c).edit().putString(KEY,a.toString()).apply();}catch(Exception ignored){}}
    private static String enc(String s){try{return s==null||s.isEmpty()?"":CredentialStore.protect(s);}catch(Exception e){return "";}}
    private static String dec(String s){try{return s==null||s.isEmpty()?"":CredentialStore.unprotect(s);}catch(Exception e){return "";}}
    private ProfileStore(){}
}
