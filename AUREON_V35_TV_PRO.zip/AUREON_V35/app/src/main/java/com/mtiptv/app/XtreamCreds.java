package com.mtiptv.app;

final class XtreamCreds {
    String server, user, pass;
    XtreamCreds(String s, String u, String p) { server = s; user = u; pass = p; }
    boolean valid() {
        return server != null && !server.isEmpty()
                && user != null && !user.isEmpty()
                && pass != null && !pass.isEmpty();
    }
}
