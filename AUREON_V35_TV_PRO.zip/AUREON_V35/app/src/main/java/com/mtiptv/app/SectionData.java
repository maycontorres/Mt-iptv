package com.mtiptv.app;

import java.util.ArrayList;
import java.util.List;

final class SectionData {
    List<MediaEntry> items;
    ArrayList<String> categories;
    long loadedAt;
    String sourceKey;

    SectionData(List<MediaEntry> i, List<String> c, long t, String k) {
        items = new ArrayList<>(i);
        categories = new ArrayList<>(c);
        loadedAt = t;
        sourceKey = k;
    }
}
