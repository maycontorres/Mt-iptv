package com.mtiptv.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import java.util.List;

public class ProfilesActivity extends Activity {
    LinearLayout list;
    @Override public void onCreate(Bundle b){super.onCreate(b);render();}
    void render(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(28,22,28,22);root.setBackgroundColor(Color.rgb(5,5,6));TextView t=new TextView(this);t.setText("Perfis / Playlists");t.setTextColor(Color.rgb(229,178,63));t.setTextSize(24);root.addView(t,new LinearLayout.LayoutParams(-1,60));Button save=new Button(this);save.setText("SALVAR PLAYLIST ATUAL COMO PERFIL");save.setOnClickListener(v->askSave());root.addView(save,new LinearLayout.LayoutParams(-1,58));list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);ScrollView sc=new ScrollView(this);sc.addView(list);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);reload();}
    void askSave(){EditText e=new EditText(this);e.setHint("Nome do perfil");e.setSingleLine(true);new AlertDialog.Builder(this).setTitle("Salvar perfil").setView(e).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->{ProfileStore.saveCurrent(this,e.getText().toString());reload();}).show();}
    void reload(){list.removeAllViews();List<ProfileStore.Profile> all=ProfileStore.list(this);if(all.isEmpty()){TextView n=new TextView(this);n.setText("Nenhum perfil salvo.");n.setTextColor(Color.LTGRAY);n.setGravity(Gravity.CENTER);list.addView(n,new LinearLayout.LayoutParams(-1,100));return;}for(int i=0;i<all.size();i++){final int idx=i;ProfileStore.Profile p=all.get(i);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);Button open=new Button(this);open.setText(p.name+"  •  "+p.mode);open.setOnClickListener(v->{ProfileStore.activate(this,p);Toast.makeText(this,"Perfil ativado.",Toast.LENGTH_SHORT).show();finish();});row.addView(open,new LinearLayout.LayoutParams(0,64,1));Button del=new Button(this);del.setText("EXCLUIR");del.setOnClickListener(v->{ProfileStore.remove(this,idx);reload();});row.addView(del,new LinearLayout.LayoutParams(150,64));list.addView(row,new LinearLayout.LayoutParams(-1,72));}}
}
