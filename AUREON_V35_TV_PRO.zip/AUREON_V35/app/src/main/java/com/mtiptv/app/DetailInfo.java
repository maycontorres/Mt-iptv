package com.mtiptv.app;

final class DetailInfo {
    String plot = "", genre = "", cast = "", director = "", duration = "", releaseDate = "", rating = "", poster = "";
}
