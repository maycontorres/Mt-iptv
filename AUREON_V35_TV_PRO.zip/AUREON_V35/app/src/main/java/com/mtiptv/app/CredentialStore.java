package com.mtiptv.app;

import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Sensitive source storage backed by Android Keystore (AES/GCM, API 23+).
 * No plaintext fallback is used: if Keystore is unavailable, the app fails closed
 * and asks the user to reconnect instead of silently persisting credentials.
 */
final class CredentialStore {
    private static final String ALIAS = "aureon_source_key_v2";
    private static final String USER = "secure_xt_user";
    private static final String PASS = "secure_xt_pass";
    private static final String M3U = "secure_m3u_url";
    private static final String EPG = "secure_epg_url";
    private static final String MIGRATED = "secure_source_migrated_v2";

    static void migrate(SharedPreferences prefs) {
        if (prefs.getBoolean(MIGRATED, false)) return;
        String oldUser = prefs.getString("xt_user", "");
        String oldPass = prefs.getString("xt_pass", "");
        String oldM3u = prefs.getString("url", "");
        if (oldM3u == null || oldM3u.isEmpty()) oldM3u = prefs.getString("url_input", "");
        String oldEpg = prefs.getString("epg", "");
        try {
            SharedPreferences.Editor e = prefs.edit();
            if (oldUser != null && !oldUser.isEmpty()) e.putString(USER, encrypt(oldUser));
            if (oldPass != null && !oldPass.isEmpty()) e.putString(PASS, encrypt(oldPass));
            if (oldM3u != null && !oldM3u.isEmpty()) e.putString(M3U, encrypt(oldM3u));
            if (oldEpg != null && !oldEpg.isEmpty()) e.putString(EPG, encrypt(oldEpg));
            e.remove("xt_user").remove("xt_pass").remove("url").remove("url_input").remove("epg");
            e.putBoolean(MIGRATED, true).apply();
        } catch (Exception error) {
            // Fail closed: do not keep credentials in plaintext if encryption is unavailable.
            prefs.edit().remove("xt_user").remove("xt_pass").remove("url").remove("url_input").remove("epg")
                    .putBoolean(MIGRATED, true).putBoolean("secure_store_failed", true).apply();
        }
    }

    static String user(SharedPreferences prefs) { return read(prefs, USER); }
    static String pass(SharedPreferences prefs) { return read(prefs, PASS); }
    static String m3uUrl(SharedPreferences prefs) { return read(prefs, M3U); }
    static String epgUrl(SharedPreferences prefs) { return read(prefs, EPG); }

    static void save(SharedPreferences prefs, String user, String pass) {
        putPair(prefs, USER, user, PASS, pass);
    }

    static void saveM3uUrl(SharedPreferences prefs, String url) { put(prefs, M3U, url); }
    static void saveEpgUrl(SharedPreferences prefs, String url) { put(prefs, EPG, url); }

    static void clear(SharedPreferences prefs) {
        prefs.edit().remove(USER).remove(PASS).remove("xt_user").remove("xt_pass").apply();
    }

    static void clearM3u(SharedPreferences prefs) {
        prefs.edit().remove(M3U).remove("url").remove("url_input").apply();
    }

    static void clearAllSourceSecrets(SharedPreferences prefs) {
        prefs.edit().remove(USER).remove(PASS).remove(M3U).remove(EPG)
                .remove("xt_user").remove("xt_pass").remove("url").remove("url_input").remove("epg").apply();
    }

    private static void put(SharedPreferences prefs, String key, String value) {
        try {
            String safe = value == null ? "" : value;
            SharedPreferences.Editor e = prefs.edit();
            if (safe.isEmpty()) e.remove(key); else e.putString(key, encrypt(safe));
            e.putBoolean("secure_store_failed", false).apply();
        } catch (Exception ex) {
            throw new IllegalStateException("Armazenamento seguro indisponível neste aparelho.", ex);
        }
    }

    private static void putPair(SharedPreferences prefs, String k1, String v1, String k2, String v2) {
        try {
            SharedPreferences.Editor e = prefs.edit();
            String a = v1 == null ? "" : v1, b = v2 == null ? "" : v2;
            if (a.isEmpty()) e.remove(k1); else e.putString(k1, encrypt(a));
            if (b.isEmpty()) e.remove(k2); else e.putString(k2, encrypt(b));
            e.remove("xt_user").remove("xt_pass").putBoolean("secure_store_failed", false).apply();
        } catch (Exception ex) {
            throw new IllegalStateException("Armazenamento seguro indisponível neste aparelho.", ex);
        }
    }

    private static String read(SharedPreferences prefs, String key) {
        String value = prefs.getString(key, "");
        if (value == null || value.isEmpty()) return "";
        try { return decrypt(value); }
        catch (Exception ex) { return ""; }
    }

    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(ALIAS)) {
            return ((KeyStore.SecretKeyEntry) ks.getEntry(ALIAS, null)).getSecretKey();
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return kg.generateKey();
    }

    static String protect(String value) throws Exception { return encrypt(value == null ? "" : value); }
    static String unprotect(String value) throws Exception { return decrypt(value == null ? "" : value); }

    private static String encrypt(String value) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key());
        byte[] iv = cipher.getIV();
        byte[] ct = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        byte[] all = new byte[1 + iv.length + ct.length];
        all[0] = (byte) iv.length;
        System.arraycopy(iv, 0, all, 1, iv.length);
        System.arraycopy(ct, 0, all, 1 + iv.length, ct.length);
        return Base64.encodeToString(all, Base64.NO_WRAP);
    }

    private static String decrypt(String encoded) throws Exception {
        byte[] all = Base64.decode(encoded, Base64.NO_WRAP);
        int n = all[0] & 0xff;
        if (n < 8 || n > 32 || all.length <= 1 + n) throw new IllegalArgumentException("invalid secure value");
        byte[] iv = new byte[n];
        byte[] ct = new byte[all.length - 1 - n];
        System.arraycopy(all, 1, iv, 0, n);
        System.arraycopy(all, 1 + n, ct, 0, ct.length);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
        return new String(cipher.doFinal(ct), StandardCharsets.UTF_8);
    }

    private CredentialStore() {}
}
