package com.mtiptv.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class EpgGuideActivity extends Activity {
    private final int GOLD=Color.rgb(229,178,63), WHITE=Color.WHITE, MUTED=Color.rgb(170,170,175);
    private LinearLayout rows;
    private final ExecutorService pool=Executors.newFixedThreadPool(4);
    private XtreamCreds creds;
    private List<MediaEntry> channels=new ArrayList<>();
    private int pageStart=0;
    private static final int PAGE=50;

    @Override public void onCreate(Bundle b){super.onCreate(b);buildUi();load();}
    void buildUi(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(5,5,6));root.setPadding(18,14,18,14);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);TextView title=t("Guia EPG • Agora e próximos",24,GOLD);top.addView(title,new LinearLayout.LayoutParams(0,56,1));Button back=new Button(this);back.setText("VOLTAR");back.setOnClickListener(v->finish());top.addView(back,new LinearLayout.LayoutParams(150,52));root.addView(top,new LinearLayout.LayoutParams(-1,60));
        TextView hint=t("OK abre ao vivo. Programas passados com arquivo disponível abrem o Catch-up.",14,MUTED);root.addView(hint,new LinearLayout.LayoutParams(-1,38));
        ScrollView sc=new ScrollView(this);rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);sc.addView(rows);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
    TextView t(String s,float z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    void load(){TextView loading=t("Carregando canais e programação…",18,MUTED);loading.setGravity(Gravity.CENTER);rows.addView(loading,new LinearLayout.LayoutParams(-1,100));pool.submit(()->{try{android.content.SharedPreferences p=AppPrefs.get(this);creds=new XtreamCreds(p.getString("xt_server",""),CredentialStore.user(p),CredentialStore.pass(p));if(!creds.valid())throw new Exception("Conecte uma playlist Xtream para usar o guia em grade.");channels=CatalogRepository.loadXtreamLive(creds);runOnUiThread(()->renderPage(0));}catch(Exception e){runOnUiThread(()->{rows.removeAllViews();TextView x=t(e.getMessage(),18,Color.LTGRAY);x.setGravity(Gravity.CENTER);rows.addView(x,new LinearLayout.LayoutParams(-1,120));});}});}

    void renderPage(int start){
        pageStart=Math.max(0,Math.min(start,Math.max(0,channels.size()-1))); rows.removeAllViews();
        LinearLayout nav=new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL);
        Button prev=new Button(this);prev.setText("◀ ANTERIOR");prev.setEnabled(pageStart>0);prev.setOnClickListener(v->renderPage(Math.max(0,pageStart-PAGE)));
        TextView page=t("Canais "+(pageStart+1)+"–"+Math.min(channels.size(),pageStart+PAGE)+" de "+channels.size(),14,MUTED);page.setGravity(Gravity.CENTER);
        Button next=new Button(this);next.setText("PRÓXIMOS ▶");next.setEnabled(pageStart+PAGE<channels.size());next.setOnClickListener(v->renderPage(pageStart+PAGE));
        nav.addView(prev,new LinearLayout.LayoutParams(180,52));nav.addView(page,new LinearLayout.LayoutParams(0,52,1));nav.addView(next,new LinearLayout.LayoutParams(180,52));rows.addView(nav,new LinearLayout.LayoutParams(-1,56));
        int end=Math.min(channels.size(),pageStart+PAGE);for(int i=pageStart;i<end;i++)addChannelPlaceholder(channels.get(i));
    }

    void addChannelPlaceholder(MediaEntry ch){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(0,4,0,4);TextView name=t(ch.name==null?"Canal":ch.name,14,WHITE);name.setMaxLines(2);row.addView(name,new LinearLayout.LayoutParams(230,76));HorizontalScrollView hs=new HorizontalScrollView(this);LinearLayout programs=new LinearLayout(this);programs.setOrientation(LinearLayout.HORIZONTAL);TextView wait=t("Carregando EPG…",13,MUTED);programs.addView(wait,new LinearLayout.LayoutParams(260,70));hs.addView(programs);row.addView(hs,new LinearLayout.LayoutParams(0,82,1));rows.addView(row,new LinearLayout.LayoutParams(-1,86));List<EpgItem> cached=EpgCacheStore.load(this,ch);if(!cached.isEmpty())renderPrograms(programs,ch,cached);pool.submit(()->{List<EpgItem> epg;try{epg=CatalogRepository.loadShortEpg(creds,ch);EpgCacheStore.save(this,ch,epg);}catch(Exception e){epg=cached;}List<EpgItem> out=epg;runOnUiThread(()->renderPrograms(programs,ch,out));});}
    void renderPrograms(LinearLayout box,MediaEntry ch,List<EpgItem> epg){box.removeAllViews();if(epg==null||epg.isEmpty()){Button live=new Button(this);live.setText("AO VIVO");live.setOnClickListener(v->play(ch));box.addView(live,new LinearLayout.LayoutParams(240,68));return;}for(EpgItem p:epg){long start=CatalogRepository.parseEpochSeconds(p.start),end=CatalogRepository.parseEpochSeconds(p.end),now=System.currentTimeMillis()/1000L;boolean past=end>0&&end<now&&ch.tvArchive;String label=time(start)+"  "+(p.title==null?"Programa":p.title)+(past?"  ↶":"");Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setOnClickListener(v->{if(past)playCatchup(ch,p);else play(ch);});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(320,68);lp.rightMargin=6;box.addView(b,lp);}}
    String time(long sec){if(sec<=0)return "";return new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(sec*1000L));}
    void play(MediaEntry ch){MainActivity.setPlayerQueue(channels,ch);Intent i=new Intent(this,PlayerActivity.class);i.putExtra("url",ch.url);i.putExtra("name",ch.name);i.putExtra("kind",MainActivity.LIVE);startActivity(i);}
    void playCatchup(MediaEntry ch,EpgItem p){try{String url=CatalogRepository.buildCatchupUrl(creds,ch,p);if(url.isEmpty()){Toast.makeText(this,"Catch-up indisponível para este programa.",Toast.LENGTH_LONG).show();return;}Intent i=new Intent(this,PlayerActivity.class);i.putExtra("url",url);i.putExtra("name",(p.title==null?ch.name:p.title)+" • Catch-up");i.putExtra("kind",MainActivity.MOVIE);startActivity(i);}catch(Exception e){Toast.makeText(this,"Catch-up indisponível: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    @Override protected void onDestroy(){pool.shutdownNow();super.onDestroy();}
}
