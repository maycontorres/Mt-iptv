package com.mtiptv.app;

/** Immutable-ish catalog model shared by UI, cache and player layers. */
final class MediaEntry {
    String id, name, url, group, extension, poster, rating, year, added, epgChannelId;
    int kind, tvArchiveDuration;
    boolean tvArchive;

    MediaEntry(String i, String n, String u, String g, String ext, int k) {
        this(i, n, u, g, ext, k, "", "", "", "");
    }

    MediaEntry(String i, String n, String u, String g, String ext, int k,
               String p, String r, String y, String a) {
        id = i; name = n; url = u; group = g; extension = ext; kind = k;
        poster = p == null ? "" : p;
        rating = r == null ? "" : r;
        year = y == null ? "" : y;
        added = a == null ? "" : a;
        epgChannelId = ""; tvArchive = false; tvArchiveDuration = 0;
    }

    MediaEntry withArchive(boolean enabled, int duration, String epgId) {
        tvArchive = enabled; tvArchiveDuration = Math.max(0, duration); epgChannelId = epgId == null ? "" : epgId; return this;
    }
}
