package com.mtiptv.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

final class ParentalControl {
    private static final String ENABLED="parental_enabled", HASH="parental_pin_hash";

    static boolean enabled(Activity a){ return AppPrefs.get(a).getBoolean(ENABLED,false) && hasPin(a); }
    static boolean hasPin(Activity a){ return !AppPrefs.get(a).getString(HASH,"").isEmpty(); }
    static void setEnabled(Activity a, boolean on){ AppPrefs.get(a).edit().putBoolean(ENABLED,on).apply(); }

    static void setup(Activity a, Runnable done){
        EditText pin = pinField(a, "Novo PIN (4 a 8 números)");
        new AlertDialog.Builder(a).setTitle("Controle parental").setMessage("Defina um PIN para conteúdo adulto.")
                .setView(pin).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->{
                    String v=pin.getText().toString().trim();
                    if(!v.matches("\\d{4,8}")){Toast.makeText(a,"Use de 4 a 8 números.",Toast.LENGTH_LONG).show();return;}
                    AppPrefs.get(a).edit().putString(HASH,hash(v)).putBoolean(ENABLED,true).apply();
                    Toast.makeText(a,"PIN parental salvo.",Toast.LENGTH_SHORT).show(); if(done!=null)done.run();
                }).show();
    }

    static void unlock(Activity a, Runnable allowed){
        if(!enabled(a)){ if(allowed!=null)allowed.run(); return; }
        EditText pin=pinField(a,"PIN");
        new AlertDialog.Builder(a).setTitle("Conteúdo protegido").setMessage("Digite o PIN parental.")
                .setView(pin).setNegativeButton("Cancelar",null).setPositiveButton("Desbloquear",(d,w)->{
                    if(hash(pin.getText().toString().trim()).equals(AppPrefs.get(a).getString(HASH,""))){if(allowed!=null)allowed.run();}
                    else Toast.makeText(a,"PIN incorreto.",Toast.LENGTH_LONG).show();
                }).show();
    }

    static void disable(Activity a){ disable(a,null); }
    static void disable(Activity a,Runnable done){
        if(!hasPin(a)){ setEnabled(a,false); return; }
        EditText pin=pinField(a,"PIN atual");
        new AlertDialog.Builder(a).setTitle("Desativar controle parental").setView(pin)
                .setNegativeButton("Cancelar",null).setPositiveButton("Desativar",(d,w)->{
                    if(hash(pin.getText().toString().trim()).equals(AppPrefs.get(a).getString(HASH,""))){
                        AppPrefs.get(a).edit().putBoolean(ENABLED,false).apply();
                        if(done!=null)done.run();
                    } else Toast.makeText(a,"PIN incorreto.",Toast.LENGTH_LONG).show();
                }).show();
    }

    private static EditText pinField(Activity a,String hint){ EditText e=new EditText(a);e.setHint(hint);e.setSingleLine(true);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);return e; }
    private static String hash(String v){try{byte[] b=MessageDigest.getInstance("SHA-256").digest(("aureon-parental-v1|"+v).getBytes(StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format("%02x",x));return s.toString();}catch(Exception e){return "";}}
    private ParentalControl(){}
}
