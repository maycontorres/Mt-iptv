package com.mtiptv.app;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.util.*;

public class CatalogRefreshWorker extends Worker {
    public CatalogRefreshWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
    @NonNull @Override public Result doWork(){try{android.content.SharedPreferences prefs=AppPrefs.get(getApplicationContext());String mode=prefs.getString("source_mode","");if(!"xtream".equals(mode))return Result.success();XtreamCreds x=new XtreamCreds(prefs.getString("xt_server",""),CredentialStore.user(prefs),CredentialStore.pass(prefs));if(!x.valid())return Result.success();List<MediaEntry> live=refresh(x,MainActivity.LIVE);refresh(x,MainActivity.MOVIE);refresh(x,MainActivity.SERIES);int n=Math.min(30,live.size());for(int i=0;i<n;i++){try{List<EpgItem> epg=CatalogRepository.loadShortEpg(x,live.get(i));EpgCacheStore.save(getApplicationContext(),live.get(i),epg);}catch(Exception ignored){}}prefs.edit().putLong("last_auto_refresh",System.currentTimeMillis()).apply();return Result.success();}catch(Exception e){return Result.retry();}}
    List<MediaEntry> refresh(XtreamCreds x,int kind)throws Exception{List<MediaEntry> items=kind==MainActivity.LIVE?CatalogRepository.loadXtreamLive(x):kind==MainActivity.MOVIE?CatalogRepository.loadXtreamMovies(x):CatalogRepository.loadXtreamSeries(x);LinkedHashSet<String> cs=new LinkedHashSet<>();for(MediaEntry e:items)if(e.group!=null&&!e.group.isEmpty())cs.add(e.group);String key="xtream|"+x.server+"|"+x.user+"|"+Integer.toHexString((x.pass==null?"":x.pass).hashCode());CatalogCache.save(getApplicationContext(),key,kind,items,new ArrayList<>(cs),System.currentTimeMillis());return items;}
}
