# ÁUREON V35 — TV Pro

Principais mudanças desta versão:

- Player em tela cheia com `RESIZE_MODE_ZOOM` por padrão para eliminar bordas laterais quando o vídeo não é 16:9.
- Removida a aba/etiqueta `AO VIVO` no canto superior direito do player.
- Segure OK ou use MENU/INFO no player para abrir as opções avançadas.
- Seleção de áudio e legendas usando o seletor de faixas do Media3.
- Velocidade 0.5x, 0.75x, 1x, 1.25x, 1.5x e 2x.
- Alternância de aspecto: Zoom, Ajustar e Preencher.
- Fallback automático para player externo após três falhas de reprodução.
- Player externo também disponível nos detalhes do canal.
- Chromecast via Media3 Cast / Google Cast.
- Multi-Screen com até quatro canais, foco pelo D-pad e áudio apenas na janela selecionada.
- Gravação de TV ao vivo para streams TS diretos, salva em Movies/AUREON.
- EPG em grade paginado, 50 canais por página.
- Catch-up/TV Archive para servidores Xtream que fornecem `tv_archive`.
- Cache de EPG e atualização automática de catálogo/EPG via WorkManager.
- Controle parental por PIN para categorias adultas.
- Perfis de playlists Xtream/M3U URL protegidos com Android Keystore.
- Teste de velocidade integrado.
- Mantidas as correções da V34 para foco D-pad e botão Voltar.
- versionCode 36 / versionName 35.0.

## Limitações conhecidas

- A gravação interna desta versão suporta stream TS direto. HLS/M3U8 ao vivo não é gravado para evitar arquivos inválidos.
- Catch-up depende do servidor Xtream oferecer TV Archive e aceitar a rota padrão `timeshift`.
- Chromecast depende de Google Play Services/Cast disponível no aparelho e da compatibilidade do stream com o receptor.
- Perfis salvos suportam Xtream e M3U por URL; playlists escolhidas por arquivo local continuam vinculadas ao URI do aparelho atual.
