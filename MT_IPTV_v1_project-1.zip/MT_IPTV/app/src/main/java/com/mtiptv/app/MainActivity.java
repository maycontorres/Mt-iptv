package com.mtiptv.app;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.graphics.drawable.GradientDrawable;import android.view.*;import android.widget.*;import java.io.*;import java.net.*;import java.util.*;import java.util.concurrent.*;import org.json.*;

public class MainActivity extends Activity {
    LinearLayout root, list; EditText url,user,pass,epg; SharedPreferences prefs;
    int gold=Color.rgb(230,180,55); ArrayList<Channel> channels=new ArrayList<>();
    public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("mt",0); build();}
    TextView tv(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(24,10,24,10);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.BLACK);b.setTextSize(15);b.setAllCaps(false);GradientDrawable g=new GradientDrawable();g.setColor(gold);g.setCornerRadius(18);b.setBackground(g);return b;}
    EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.GRAY);e.setTextColor(Color.WHITE);e.setSingleLine(true);e.setPadding(20,0,20,0);GradientDrawable g=new GradientDrawable();g.setColor(Color.rgb(25,25,25));g.setCornerRadius(16);e.setBackground(g);return e;}
    void build(){
        ScrollView sv=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(28,24,28,28);root.setBackgroundColor(Color.BLACK);sv.addView(root);setContentView(sv);
        ImageView logo=new ImageView(this);logo.setImageResource(com.mtiptv.app.R.drawable.mt_logo);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);root.addView(logo,new LinearLayout.LayoutParams(-1,300));
        TextView title=tv("MT IPTV",28);title.setTextColor(gold);title.setGravity(Gravity.CENTER);root.addView(title,new LinearLayout.LayoutParams(-1,60));
        root.addView(tv("Conecte sua própria lista IPTV",16));
        url=input("URL M3U ou servidor"); user=input("Usuário Xtream (opcional)"); pass=input("Senha Xtream (opcional)"); epg=input("URL EPG XMLTV (opcional)");
        root.addView(url,lp(1));root.addView(space(10));root.addView(user,lp(1));root.addView(space(10));root.addView(pass,lp(1));root.addView(space(10));root.addView(epg,lp(1));root.addView(space(14));
        url.setText(prefs.getString("url",""));user.setText(prefs.getString("user",""));pass.setText(prefs.getString("pass",""));epg.setText(prefs.getString("epg",""));
        Button load=btn("▶  CONECTAR E CARREGAR CANAIS");root.addView(load,lp(1));
        load.setOnClickListener(v->loadPlaylist());
        root.addView(space(20));list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list,lp(1));
    }
    LinearLayout.LayoutParams lp(int w){return new LinearLayout.LayoutParams(-1,58);} View space(int h){Space s=new Space(this);s.setLayoutParams(new LinearLayout.LayoutParams(1,h));return s;}
    void loadPlaylist(){final String u=url.getText().toString().trim(), us=user.getText().toString().trim(), pw=pass.getText().toString().trim();if(u.isEmpty()){Toast.makeText(this,"Informe a URL do servidor/lista",Toast.LENGTH_LONG).show();return;}prefs.edit().putString("url",u).putString("user",us).putString("pass",pw).putString("epg",epg.getText().toString().trim()).apply();
        Toast.makeText(this,"Carregando...",Toast.LENGTH_SHORT).show();
        Executors.newSingleThreadExecutor().execute(()->{try{String target=u;if(!us.isEmpty()&&!pw.isEmpty()&&!u.toLowerCase().contains("get.php")){String sep=u.contains("?")?"&":"?";target=u+sep+"username="+URLEncoder.encode(us,"UTF-8")+"&password="+URLEncoder.encode(pw,"UTF-8")+"&type=m3u_plus&output=ts";}String txt=http(target);ArrayList<Channel> parsed=parseM3U(txt);runOnUiThread(()->showChannels(parsed));}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Não foi possível carregar: "+e.getMessage(),Toast.LENGTH_LONG).show());}});
    }
    String http(String s)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(s).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(30000);c.setRequestProperty("User-Agent","MT-IPTV/1.0");InputStream in=c.getInputStream();BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null)b.append(line).append('\n');r.close();return b.toString();}
    ArrayList<Channel> parseM3U(String txt){ArrayList<Channel>a=new ArrayList<>();String[] lines=txt.split("\\r?\\n");String name="Canal",group="Outros",logo="";for(int i=0;i<lines.length;i++){String l=lines[i].trim();if(l.startsWith("#EXTINF")){int comma=l.indexOf(',');name=comma>=0?l.substring(comma+1).trim():"Canal";group=attr(l,"group-title");if(group.isEmpty())group="Outros";logo=attr(l,"tvg-logo");}else if(!l.isEmpty()&&!l.startsWith("#")){a.add(new Channel(name,group,logo,l));}}return a;}
    String attr(String l,String key){String p=key+"=\"";int i=l.indexOf(p);if(i<0)return "";i+=p.length();int j=l.indexOf('"',i);return j<0?"":l.substring(i,j);}
    void showChannels(ArrayList<Channel>a){channels=a;list.removeAllViews();if(a.isEmpty()){list.addView(tv("Nenhum canal encontrado.",16));return;}String current="";for(Channel c:a){if(!c.group.equals(current)){current=c.group;TextView h=tv("▾  "+current,20);h.setTextColor(gold);list.addView(h,new LinearLayout.LayoutParams(-1,55));}Button b=btn("▶  "+c.name);b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);list.addView(b,new LinearLayout.LayoutParams(-1,56));b.setOnClickListener(v->{Intent i=new Intent(this,PlayerActivity.class);i.putExtra("name",c.name);i.putExtra("url",c.url);startActivity(i);});}}
    static class Channel{String name,group,logo,url;Channel(String n,String g,String l,String u){name=n;group=g;logo=l;url=u;}}
}
