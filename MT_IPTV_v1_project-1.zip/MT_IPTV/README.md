# MT IPTV — versão inicial

Aplicativo Android/Fire TV para reproduzir listas que você tem autorização para usar.

## Compatibilidade desta base
- M3U/M3U8 por URL
- Xtream Codes usando URL + usuário + senha (via endpoint M3U)
- HLS/HTTP/HTTPS através do VideoView/MediaPlayer do Android
- EPG: campo reservado para a próxima etapa (XMLTV)
- Celular Android e Fire Stick/Fire TV

## Build
Abra o projeto no Android Studio e gere um APK de release. O projeto usa Android Gradle Plugin 8.6.1, compileSdk 35 e não depende de bibliotecas externas para a reprodução básica.

## Observação
Não existe compatibilidade garantida com todo e qualquer servidor IPTV: servidores proprietários, DRM e formatos específicos podem exigir integração adicional. O app é apenas um player; não fornece canais nem listas.
