# ÁUREON 35.14 — correção de streaming contínuo

- Separado o cliente de rede das listas do cliente usado pelo player.
- Listas e EPG continuam protegidos por tempo máximo de resposta.
- Canais ao vivo não possuem mais limite total de 28 segundos.
- Streaming não é interrompido por timeout de leitura durante pausas do servidor.
- Mantido o ExoPlayer local estável restaurado na versão 35.13.

