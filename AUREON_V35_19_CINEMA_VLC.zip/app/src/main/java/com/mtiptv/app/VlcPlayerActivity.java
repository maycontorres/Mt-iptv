package com.mtiptv.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;
import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;
import java.util.ArrayList;

/** Embedded LibVLC fallback; always releases its own player and surface. */
public final class VlcPlayerActivity extends Activity implements SurfaceHolder.Callback {
    private LibVLC vlc;
    private MediaPlayer player;
    private SurfaceView surface;
    private String url;
    private boolean surfaceReady;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        url=getIntent().getStringExtra("url");
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(0xff000000);
        surface=new SurfaceView(this);root.addView(surface,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
        setContentView(root);
        if(url==null||url.trim().isEmpty()){finish();return;}
        try{
            TransportPolicy.requireAllowed(url);
            ArrayList<String> options=new ArrayList<>();options.add("--network-caching=1500");
            vlc=new LibVLC(this,options);player=new MediaPlayer(vlc);
            surface.getHolder().addCallback(this);
        }catch(Exception error){Toast.makeText(this,"VLC: "+error.getMessage(),Toast.LENGTH_LONG).show();finish();}
    }
    @Override public void surfaceCreated(SurfaceHolder holder){
        if(player==null||surfaceReady)return;
        surfaceReady=true;
        try{
            player.getVLCVout().setVideoView(surface);
            player.getVLCVout().attachViews();
            Media media=new Media(vlc,android.net.Uri.parse(url));
            player.setMedia(media);media.release();player.play();
        }catch(Exception error){Toast.makeText(this,"Erro ao abrir no VLC",Toast.LENGTH_LONG).show();}
    }
    @Override public void surfaceChanged(SurfaceHolder h,int format,int width,int height){}
    @Override public void surfaceDestroyed(SurfaceHolder holder){surfaceReady=false;if(player!=null){player.stop();player.getVLCVout().detachViews();}}
    @Override protected void onStop(){if(player!=null)player.stop();super.onStop();}
    @Override protected void onStart(){super.onStart();if(surfaceReady&&player!=null)player.play();}
    @Override protected void onDestroy(){if(player!=null){player.stop();player.getVLCVout().detachViews();player.release();player=null;}if(vlc!=null){vlc.release();vlc=null;}super.onDestroy();}
}
