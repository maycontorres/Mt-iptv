# ÁUREON 35.16 — recuperação de buffering

- Detecta transmissão sem dados após 20 segundos e aciona a reconexão.
- Mantém o tempo total da transmissão sem limite.
- Buffer da tela cheia ampliado para até 60 segundos.
- Buffer da prévia ampliado para até 30 segundos.
- Exige mais dados antes de retomar após uma interrupção, reduzindo repetição do círculo de carregamento.
- Mantém a correção que impede prévia e tela cheia conectadas simultaneamente.
