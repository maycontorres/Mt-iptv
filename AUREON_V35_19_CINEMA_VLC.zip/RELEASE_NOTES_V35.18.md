# ÁUREON 35.18

- Banner inicial automático com filmes das categorias Cinema, Em Cartaz, Lançamentos ou Estreias.
- Troca automática do destaque a cada 12 segundos.
- Clique no banner abre diretamente os detalhes do filme selecionado.
- Faixa "Filmes em cartaz" usa itens reais da playlist e permite abertura direta.
- Faixa "Canais Ao Vivo" usa canais reais da playlist e permite abertura direta.
- Mantém filmes recentes e imagens internas como reserva quando o provedor não informa uma categoria de cinema ou uma capa.
