# ÁUREON 35.15 — estabilidade da TV ao vivo

- Encerra completamente o player de prévia antes de abrir a tela cheia.
- Impede duas conexões simultâneas ao mesmo canal.
- Restaura a prévia somente depois de sair da tela cheia.
- Aumenta o buffer de TV ao vivo para absorver oscilações curtas do servidor.
- Ao reconectar um canal ao vivo, retorna ao ponto atual da transmissão.
- Mantém separados os clientes de rede da API e do streaming.
