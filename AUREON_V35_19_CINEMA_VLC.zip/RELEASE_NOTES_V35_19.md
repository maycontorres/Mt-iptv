# ÁUREON V35.19 — VLC + Cinema Automático

Base: V35.18 enviada pelo usuário.

- Mantém o banner rotativo da categoria Cinema e os atalhos diretos da V35.18.
- Inclui LibVLC 3.5.1 como motor de reprodução integrado alternativo.
- Menu do player: Automático, ExoPlayer ou VLC; botão para abrir canal/filme atual no VLC.
- No modo Automático, após três falhas de reconexão do ExoPlayer, tenta o VLC.
- Preserva os ajustes de buffer da V35.18.

Observação: o projeto precisa ser compilado pelo GitHub Actions ou Android Studio; a reprodução deve ser validada nos dispositivos.
