$ErrorActionPreference = "Stop"
$project = Join-Path $PSScriptRoot "Aureon.Windows\Aureon.Windows.csproj"
$output = Join-Path $PSScriptRoot "publish\win-x64"

dotnet restore $project
dotnet publish $project -c Release -r win-x64 --self-contained true -p:PublishSingleFile=false -o $output

Write-Host ""
Write-Host "Build concluido:" -ForegroundColor Green
Write-Host (Join-Path $output "Aureon.exe")
