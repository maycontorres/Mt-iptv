using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Aureon.Windows.Services;
using LibVLCSharp.Shared;

namespace Aureon.Windows;

public partial class MainWindow : Window
{
    private const string Portal = "https://ativar-aureon-tv.maycontorres1995.chatgpt.site";
    private readonly DeviceIdentity _identity = SecureStore.LoadOrCreateIdentity();
    private readonly ActivationService _activation = new();
    private readonly CatalogService _catalog = new();
    private readonly CancellationTokenSource _shutdown = new();
    private readonly ObservableCollection<MediaEntry> _visible = new();
    private readonly DispatcherTimer _activationTimer = new() { Interval = TimeSpan.FromSeconds(5) };
    private readonly DispatcherTimer _heroTimer = new() { Interval = TimeSpan.FromSeconds(12) };
    private readonly HashSet<string> _favoriteUrls = new(StringComparer.OrdinalIgnoreCase);
    private PlaylistConfig? _playlist;
    private List<MediaEntry> _all = new();
    private List<MediaEntry> _heroItems = new();
    private int _heroIndex;
    private string _currentKind = "movie";
    private LibVLC? _libVlc;
    private MediaPlayer? _player;
    private Media? _media;

    public MainWindow()
    {
        InitializeComponent(); CatalogList.ItemsSource = _visible;
        DeviceCodeText.Text = _identity.DeviceCode; PinText.Text = _identity.Pin; ConnectedDeviceText.Text = "Dispositivo: " + _identity.DeviceCode;
        _activationTimer.Tick += async (_,_) => await SyncActivation();
        _heroTimer.Tick += (_,_) => RotateHero();
        Loaded += async (_,_) => await StartAsync();
        Closed += (_,_) => DisposeAll();
    }

    private async Task StartAsync()
    {
        _playlist = SecureStore.LoadPlaylist();
        if (_playlist?.IsValid == true) { ShowMain(); await LoadSection("movie"); return; }
        ShowActivation();
        try { await _activation.RegisterAsync(_identity,_shutdown.Token); ActivationStatus.Text="Aguardando a lista pelo portal…"; _activationTimer.Start(); await SyncActivation(); }
        catch(Exception ex){ActivationStatus.Text=ex.Message+" Tentando novamente…";_activationTimer.Start();}
    }

    private async Task SyncActivation()
    {
        try
        {
            var result=await _activation.SyncAsync(_identity,_shutdown.Token);
            if(result.Status=="active"&&result.Playlist?.IsValid==true){_activationTimer.Stop();_playlist=result.Playlist;SecureStore.SavePlaylist(_playlist);ShowMain();await LoadSection("movie");}
            else ActivationStatus.Text="Aguardando você concluir no portal…";
        }
        catch(Exception ex){ActivationStatus.Text=ex.Message;}
    }

    private void ShowActivation(){ActivationView.Visibility=Visibility.Visible;MainView.Visibility=Visibility.Collapsed;SetupView.Visibility=Visibility.Collapsed;}
    private void ShowMain(){ActivationView.Visibility=Visibility.Collapsed;MainView.Visibility=Visibility.Visible;SetupView.Visibility=Visibility.Collapsed;PlaylistNameText.Text=_playlist?.PlaylistName??"ÁUREON";EnsurePlayer();}
    private void EnsurePlayer(){if(_player!=null)return;_libVlc=new LibVLC("--network-caching=4000","--live-caching=3500","--drop-late-frames","--skip-frames");_player=new MediaPlayer(_libVlc);VideoView.MediaPlayer=_player;}

    private async Task LoadSection(string kind)
    {
        if(_playlist?.IsValid!=true)return;_currentKind=kind;PageTitle.Text=kind=="live"?"TV Ao Vivo":"Filmes";EmptyMessage.Visibility=Visibility.Visible;EmptyMessage.Text="Carregando catálogo…";_visible.Clear();
        try{_all=await _catalog.LoadAsync(_playlist,kind,_shutdown.Token);LoadCategories();ApplyFilter();PrepareHero();}
        catch(Exception ex){EmptyMessage.Text="Falha ao carregar: "+ex.Message;}
    }

    private void ApplyFilter()
    {
        var q=(SearchBox.Text??"").Trim();IEnumerable<MediaEntry> source=_all;var category=CategoryBox.SelectedItem as string;
        if(!string.IsNullOrWhiteSpace(category)&&category!="Todos")source=source.Where(x=>x.DisplayGroup==category);
        if(q.Length>0)source=source.Where(x=>x.Name.Contains(q,StringComparison.CurrentCultureIgnoreCase)||x.Group.Contains(q,StringComparison.CurrentCultureIgnoreCase));
        _visible.Clear();foreach(var item in source.Take(1500))_visible.Add(item);EmptyMessage.Visibility=_visible.Count==0?Visibility.Visible:Visibility.Collapsed;EmptyMessage.Text="Nenhum item encontrado.";
    }

    private void LoadCategories(){var selected=CategoryBox.SelectedItem as string;CategoryBox.ItemsSource=new[]{"Todos"}.Concat(_all.Select(x=>x.DisplayGroup).Distinct().OrderBy(x=>x)).ToList();CategoryBox.SelectedItem=CategoryBox.Items.Contains(selected)?selected:"Todos";}

    private void PrepareHero()
    {
        _heroItems=_all.Where(x=>x.Kind=="movie"&&(Normalize(x.Group).Contains("cinema")||Normalize(x.Group).Contains("em cartaz")||Normalize(x.Group).Contains("lancamento")||Normalize(x.Group).Contains("estreia"))).Take(12).ToList();
        if(_heroItems.Count==0)_heroItems=_all.Where(x=>x.Kind=="movie").Take(12).ToList();_heroIndex=0;RenderHero();if(_heroItems.Count>1)_heroTimer.Start();else _heroTimer.Stop();
    }

    private void RotateHero(){if(_heroItems.Count==0)return;_heroIndex=(_heroIndex+1)%_heroItems.Count;RenderHero();}
    private void RenderHero(){if(_heroItems.Count==0){HeroTitle.Text="ÁUREON";HeroImage.Source=null;return;}var item=_heroItems[_heroIndex];HeroTitle.Text="▶  "+item.Name;try{HeroImage.Source=string.IsNullOrWhiteSpace(item.Poster)?null:new BitmapImage(new Uri(item.Poster));}catch{HeroImage.Source=null;}}
    private static string Normalize(string value){var form=value.Normalize(System.Text.NormalizationForm.FormD);return new string(form.Where(c=>System.Globalization.CharUnicodeInfo.GetUnicodeCategory(c)!=System.Globalization.UnicodeCategory.NonSpacingMark).ToArray()).ToLowerInvariant();}

    private void Play(MediaEntry? item)
    {
        if(item is null||string.IsNullOrWhiteSpace(item.Url))return;EnsurePlayer();_media?.Dispose();_media=new Media(_libVlc!,new Uri(item.Url));_media.AddOption(":network-caching=4000");_player!.Play(_media);PageTitle.Text=item.Name;
    }

    private void Portal_Click(object sender,RoutedEventArgs e)=>Process.Start(new ProcessStartInfo(Portal){UseShellExecute=true});
    private async void Section_Click(object sender,RoutedEventArgs e){if(sender is Button b&&b.Tag is string kind)await LoadSection(kind);}
    private async void Home_Click(object sender,RoutedEventArgs e)=>await LoadSection("movie");
    private void Search_TextChanged(object sender,TextChangedEventArgs e){if(IsLoaded)ApplyFilter();}
    private void Category_Changed(object sender,SelectionChangedEventArgs e){if(IsLoaded)ApplyFilter();}
    private async void Refresh_Click(object sender,RoutedEventArgs e)=>await LoadSection(_currentKind);
    private void Catalog_DoubleClick(object sender,MouseButtonEventArgs e)=>Play(CatalogList.SelectedItem as MediaEntry);
    private void Catalog_KeyDown(object sender,KeyEventArgs e){if(e.Key==Key.Enter)Play(CatalogList.SelectedItem as MediaEntry);}
    private void Hero_Click(object sender,MouseButtonEventArgs e){if(_heroItems.Count>0)Play(_heroItems[_heroIndex]);}
    private void PlayPause_Click(object sender,RoutedEventArgs e){if(_player==null)return;if(_player.IsPlaying)_player.Pause();else _player.Play();}
    private void Previous_Click(object sender,RoutedEventArgs e){var i=CatalogList.SelectedIndex;if(i>0){CatalogList.SelectedIndex=i-1;Play(CatalogList.SelectedItem as MediaEntry);}}
    private void Next_Click(object sender,RoutedEventArgs e){var i=CatalogList.SelectedIndex;if(i>=0&&i<CatalogList.Items.Count-1){CatalogList.SelectedIndex=i+1;Play(CatalogList.SelectedItem as MediaEntry);}}
    private void Fullscreen_Click(object sender,RoutedEventArgs e){WindowState=WindowState==WindowState.Maximized?WindowState.Normal:WindowState.Maximized;WindowStyle=WindowState==WindowState.Maximized?WindowStyle.None:WindowStyle.SingleBorderWindow;}
    private void ToggleFavorite_Click(object sender,RoutedEventArgs e){if(CatalogList.SelectedItem is not MediaEntry item)return;if(!_favoriteUrls.Add(item.Url))_favoriteUrls.Remove(item.Url);}
    private void Favorites_Click(object sender,RoutedEventArgs e){PageTitle.Text="Favoritos";_visible.Clear();foreach(var x in _all.Where(x=>_favoriteUrls.Contains(x.Url)))_visible.Add(x);EmptyMessage.Visibility=_visible.Count==0?Visibility.Visible:Visibility.Collapsed;EmptyMessage.Text="Seus favoritos aparecerão aqui.";}

    private void ShowSetup_Click(object sender,RoutedEventArgs e){SetupView.Visibility=Visibility.Visible;NameBox.Text=_playlist?.PlaylistName??"ÁUREON";ServerBox.Text=_playlist?.Mode=="m3u"?_playlist.M3uUrl:_playlist?.ServerUrl??"";UserBox.Text=_playlist?.Username??"";PasswordBox.Password=_playlist?.Password??"";EpgBox.Text=_playlist?.EpgUrl??"";XtreamRadio.IsChecked=_playlist?.Mode!="m3u";M3uRadio.IsChecked=_playlist?.Mode=="m3u";Mode_Changed(sender,e);}
    private void HideSetup_Click(object sender,RoutedEventArgs e)=>SetupView.Visibility=Visibility.Collapsed;
    private void Mode_Changed(object sender,RoutedEventArgs e){if(UserBox==null)return;var xt=XtreamRadio.IsChecked==true;UserBox.Visibility=xt?Visibility.Visible:Visibility.Collapsed;PasswordBox.Visibility=xt?Visibility.Visible:Visibility.Collapsed;ServerBox.ToolTip=xt?"Servidor Xtream":"Link M3U/M3U8";}
    private async void SaveSetup_Click(object sender,RoutedEventArgs e)
    {
        var xt=XtreamRadio.IsChecked==true;var p=new PlaylistConfig{Mode=xt?"xtream":"m3u",PlaylistName=NameBox.Text.Trim(),ServerUrl=xt?ServerBox.Text.Trim():"",Username=UserBox.Text.Trim(),Password=PasswordBox.Password,M3uUrl=xt?"":ServerBox.Text.Trim(),EpgUrl=EpgBox.Text.Trim()};
        if(!p.IsValid){SetupStatus.Text="Preencha os dados obrigatórios.";return;}_playlist=p;SecureStore.SavePlaylist(p);SetupStatus.Text="Conectando…";ShowMain();await LoadSection("movie");
    }

    private void DisposeAll(){_shutdown.Cancel();_activationTimer.Stop();_heroTimer.Stop();_player?.Stop();_media?.Dispose();_player?.Dispose();_libVlc?.Dispose();_shutdown.Dispose();}
}
