namespace Aureon.Windows;

public sealed class PlaylistConfig
{
    public string Mode { get; set; } = "";
    public string PlaylistName { get; set; } = "ÁUREON";
    public string ServerUrl { get; set; } = "";
    public string Username { get; set; } = "";
    public string Password { get; set; } = "";
    public string M3uUrl { get; set; } = "";
    public string EpgUrl { get; set; } = "";
    public bool IsValid => Mode == "xtream"
        ? !string.IsNullOrWhiteSpace(ServerUrl) && !string.IsNullOrWhiteSpace(Username) && !string.IsNullOrWhiteSpace(Password)
        : Mode == "m3u" && !string.IsNullOrWhiteSpace(M3uUrl);
}

public sealed class MediaEntry
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string Url { get; set; } = "";
    public string Group { get; set; } = "Todos";
    public string Poster { get; set; } = "";
    public string Added { get; set; } = "";
    public string Kind { get; set; } = "live";
    public string DisplayGroup => string.IsNullOrWhiteSpace(Group) ? "Todos" : Group;
}

public sealed class DeviceIdentity
{
    public string DeviceCode { get; set; } = "";
    public string Pin { get; set; } = "";
    public string DeviceToken { get; set; } = "";
}

public sealed class ActivationResult
{
    public string Status { get; set; } = "pending";
    public PlaylistConfig? Playlist { get; set; }
}
