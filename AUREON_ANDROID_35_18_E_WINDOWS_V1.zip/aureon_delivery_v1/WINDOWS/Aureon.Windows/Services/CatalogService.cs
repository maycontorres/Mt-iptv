using System.Net;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace Aureon.Windows.Services;

public sealed class CatalogService
{
    private readonly HttpClient _http = new(new HttpClientHandler { AutomaticDecompression = DecompressionMethods.All }) { Timeout = TimeSpan.FromSeconds(45) };

    public async Task<List<MediaEntry>> LoadAsync(PlaylistConfig config, string kind, CancellationToken token)
        => config.Mode == "xtream" ? await LoadXtream(config, kind, token) : await LoadM3u(config.M3uUrl, kind, token);

    private async Task<List<MediaEntry>> LoadXtream(PlaylistConfig c, string kind, CancellationToken token)
    {
        var server = c.ServerUrl.Trim().TrimEnd('/');
        var auth = $"username={Uri.EscapeDataString(c.Username)}&password={Uri.EscapeDataString(c.Password)}";
        var categoryAction = kind == "live" ? "get_live_categories" : "get_vod_categories";
        var streamAction = kind == "live" ? "get_live_streams" : "get_vod_streams";
        var categories = new Dictionary<string,string>();
        using (var catDoc = JsonDocument.Parse(await _http.GetStringAsync($"{server}/player_api.php?{auth}&action={categoryAction}", token)))
            foreach (var x in catDoc.RootElement.EnumerateArray()) categories[Read(x,"category_id")] = Read(x,"category_name","Todos");
        using var doc = JsonDocument.Parse(await _http.GetStringAsync($"{server}/player_api.php?{auth}&action={streamAction}", token));
        var list = new List<MediaEntry>();
        foreach (var x in doc.RootElement.EnumerateArray())
        {
            var id = Read(x,"stream_id"); if (string.IsNullOrWhiteSpace(id)) continue;
            var ext = Read(x,"container_extension", kind == "live" ? "ts" : "mp4");
            var path = kind == "live" ? "live" : "movie";
            list.Add(new MediaEntry { Id=id, Name=Read(x,"name","Sem nome"), Poster=Read(x,"stream_icon"), Added=Read(x,"added"),
                Group=categories.GetValueOrDefault(Read(x,"category_id"),"Todos"), Kind=kind,
                Url=$"{server}/{path}/{Uri.EscapeDataString(c.Username)}/{Uri.EscapeDataString(c.Password)}/{id}.{ext}" });
        }
        return list.OrderByDescending(x => ParseAdded(x.Added)).ToList();
    }

    private async Task<List<MediaEntry>> LoadM3u(string url, string requestedKind, CancellationToken token)
    {
        var raw = await _http.GetStringAsync(url, token); var result = new List<MediaEntry>(); string? info = null;
        foreach (var sourceLine in raw.Split('\n'))
        {
            var line=sourceLine.Trim(); if(line.StartsWith("#EXTINF",StringComparison.OrdinalIgnoreCase)){info=line;continue;}
            if(info is null||line.Length==0||line.StartsWith('#'))continue;
            var name=info[(info.LastIndexOf(',')+1)..].Trim();var group=Attr(info,"group-title");var logo=Attr(info,"tvg-logo");
            var kind = Regex.IsMatch(group+" "+name,"filme|movie|vod",RegexOptions.IgnoreCase)?"movie":"live";
            if(kind==requestedKind)result.Add(new MediaEntry{Name=name,Group=string.IsNullOrWhiteSpace(group)?"Todos":group,Poster=logo,Url=line,Kind=kind});info=null;
        }
        return result;
    }

    private static string Attr(string line,string key){var m=Regex.Match(line,$"{Regex.Escape(key)}=\"([^\"]*)\"",RegexOptions.IgnoreCase);return m.Success?m.Groups[1].Value:"";}
    private static string Read(JsonElement e,string key,string fallback="")=>e.TryGetProperty(key,out var v)?v.ToString():fallback;
    private static long ParseAdded(string value)=>long.TryParse(value,out var n)?n:0;
}
