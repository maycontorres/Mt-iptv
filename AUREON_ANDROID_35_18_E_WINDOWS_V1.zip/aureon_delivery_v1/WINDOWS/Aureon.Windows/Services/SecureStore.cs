using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Aureon.Windows.Services;

public static class SecureStore
{
    private static readonly string Folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Aureon");
    private static readonly string IdentityPath = Path.Combine(Folder, "device.bin");
    private static readonly string PlaylistPath = Path.Combine(Folder, "playlist.bin");

    public static DeviceIdentity LoadOrCreateIdentity()
    {
        var saved = Load<DeviceIdentity>(IdentityPath);
        if (saved is not null && saved.DeviceCode.Length == 14 && saved.Pin.Length == 6 && saved.DeviceToken.Length > 20) return saved;
        const string alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        var bytes = RandomNumberGenerator.GetBytes(12);
        var raw = new string(bytes.Select(b => alphabet[b % alphabet.Length]).ToArray());
        var pin = RandomNumberGenerator.GetInt32(0, 1_000_000).ToString("D6");
        var identity = new DeviceIdentity { DeviceCode = $"{raw[..4]}-{raw[4..8]}-{raw[8..12]}", Pin = pin, DeviceToken = $"{Guid.NewGuid()}-{Guid.NewGuid()}" };
        Save(IdentityPath, identity); return identity;
    }

    public static PlaylistConfig? LoadPlaylist() => Load<PlaylistConfig>(PlaylistPath);
    public static void SavePlaylist(PlaylistConfig value) => Save(PlaylistPath, value);
    public static void ClearPlaylist() { if (File.Exists(PlaylistPath)) File.Delete(PlaylistPath); }

    private static T? Load<T>(string path)
    {
        try { if (!File.Exists(path)) return default; var clear = ProtectedData.Unprotect(File.ReadAllBytes(path), null, DataProtectionScope.CurrentUser); return JsonSerializer.Deserialize<T>(clear); }
        catch { return default; }
    }

    private static void Save<T>(string path, T value)
    {
        Directory.CreateDirectory(Folder);
        var clear = JsonSerializer.SerializeToUtf8Bytes(value);
        File.WriteAllBytes(path, ProtectedData.Protect(clear, null, DataProtectionScope.CurrentUser));
    }
}
