using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Aureon.Windows.Services;

public sealed class ActivationService
{
    private const string BaseUrl = "https://whhamqkjfbowjrjjqpxi.supabase.co/functions/v1/aureon-device";
    private readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(18) };
    private static readonly JsonSerializerOptions JsonOptions = new() { PropertyNameCaseInsensitive = true };

    public async Task RegisterAsync(DeviceIdentity id, CancellationToken token)
    {
        using var response = await _http.PostAsJsonAsync(BaseUrl + "/register", new { device_code = id.DeviceCode, pin = id.Pin, device_token = id.DeviceToken, app_version = "windows-1.0.0" }, token);
        await EnsureSuccess(response, token);
    }

    public async Task<ActivationResult> SyncAsync(DeviceIdentity id, CancellationToken token)
    {
        using var response = await _http.PostAsJsonAsync(BaseUrl + "/sync", new { device_code = id.DeviceCode, device_token = id.DeviceToken }, token);
        await EnsureSuccess(response, token);
        var raw = await response.Content.ReadAsStringAsync(token);
        using var doc = JsonDocument.Parse(raw);
        var root = doc.RootElement;
        var result = new ActivationResult { Status = root.TryGetProperty("status", out var status) ? status.GetString() ?? "pending" : "pending" };
        if (root.TryGetProperty("playlist", out var p) && p.ValueKind == JsonValueKind.Object)
        {
            result.Playlist = new PlaylistConfig {
                Mode = Read(p,"mode"), PlaylistName = Read(p,"playlist_name","Minha lista"), ServerUrl = Read(p,"server_url"),
                Username = Read(p,"username"), Password = Read(p,"password"), M3uUrl = Read(p,"m3u_url"), EpgUrl = Read(p,"epg_url") };
        }
        return result;
    }

    private static string Read(JsonElement e, string key, string fallback="") => e.TryGetProperty(key, out var v) ? v.GetString() ?? fallback : fallback;
    private static async Task EnsureSuccess(HttpResponseMessage response, CancellationToken token)
    {
        if (response.IsSuccessStatusCode) return;
        var raw = await response.Content.ReadAsStringAsync(token);
        var message = raw.Contains("device_blocked") ? "Este dispositivo foi bloqueado." : raw.Contains("device_expired") ? "A ativação expirou." : "Servidor de ativação indisponível.";
        throw new InvalidOperationException(message);
    }
}
