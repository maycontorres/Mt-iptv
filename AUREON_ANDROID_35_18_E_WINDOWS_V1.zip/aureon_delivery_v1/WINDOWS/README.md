# ÁUREON para Windows — primeira versão

Aplicativo Windows 10/11 (64 bits) separado do APK Android, mas conectado ao mesmo portal de ativação.

## Incluído

- Código e PIN próprios para cada computador.
- Ativação pelo mesmo portal do ÁUREON.
- Cadastro direto por Xtream Codes ou link M3U/M3U8.
- TV ao vivo e filmes, com categorias e busca.
- Banner automático usando Cinema, Em Cartaz, Lançamentos ou Estreias.
- Player LibVLC com cache de rede, reprodução, pausa, próximo/anterior e tela cheia.
- Credenciais e token protegidos pelo Windows para o usuário atual.
- Build local no Visual Studio e build automático pelo GitHub Actions.

## Abrir no Visual Studio

1. Instale Visual Studio 2022 ou mais recente com **Desenvolvimento para desktop com .NET**.
2. Abra `Aureon.Windows.sln`.
3. Aguarde a restauração dos pacotes.
4. Selecione `x64` e execute.

## Gerar a versão para distribuir

Abra PowerShell na pasta do projeto e execute:

```powershell
.\build-windows.ps1
```

O programa ficará em `publish\win-x64\Aureon.exe`. Distribua a pasta inteira, pois ela contém o motor VLC e as bibliotecas necessárias.

## GitHub

Copie todo o conteúdo deste projeto para o repositório. Em **Actions**, execute `Build AUREON Windows`. Baixe o artefato `AUREON-WINDOWS-X64`.

## Observações

- O Windows aparece no painel como um dispositivo diferente e utiliza uma tela do plano.
- Esta primeira versão cobre TV ao vivo e filmes. Séries com temporadas, EPG avançado e instalador MSIX ficam para a próxima etapa.
- Use somente listas e conteúdos que você tenha autorização para acessar.
