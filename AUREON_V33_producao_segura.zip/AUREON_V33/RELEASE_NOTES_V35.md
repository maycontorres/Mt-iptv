# ÁUREON V35 — banner inicial em largura total

Esta versão preserva as melhorias de produção e controle remoto da V34 e simplifica a tela inicial.

## Tela inicial
- Removidos os quatro cartões à direita: TV Ao Vivo, Filmes, Séries e Favoritos.
- O banner principal agora ocupa toda a largura útil ao lado do menu.
- Os atalhos removidos da área principal continuam acessíveis pelo menu lateral.

## Controle remoto / D-pad
- Foco de categorias mais forte e persistente em dourado.
- Categoria ativa permanece marcada ao entrar na lista de canais, filmes ou séries.
- A rolagem de categorias centraliza o item focado sempre que possível.
- Direita a partir da categoria entra no conteúdo da categoria atual.
- Esquerda a partir de um canal retorna à categoria ativa.
- Em Filmes/Séries, esquerda na primeira coluna do grid retorna à categoria ativa.
- O app lembra o último canal/cartão focado e tenta restaurá-lo ao voltar para o conteúdo.

## Botão Voltar
- Se a busca/teclado estiver ativo, Voltar fecha o teclado primeiro.
- Nos detalhes, Voltar retorna à seção/categoria de origem.
- No conteúdo de TV/Filmes/Séries, Voltar retorna primeiro à coluna de categorias.
- Da coluna de categorias, Voltar retorna ao Início.
- No Início, um toque em Voltar não fecha mais o app por acidente; são necessários dois toques em até 2 segundos.
- No player em tela cheia, Voltar fecha somente o player e retorna ao ÁUREON.

## Versão
- versionCode 36
- versionName 35.0
