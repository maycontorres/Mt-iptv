package com.mtiptv.app;

/** Immutable-ish catalog model shared by UI, cache and player layers. */
final class MediaEntry {
    String id, name, url, group, extension, poster, rating, year, added;
    int kind;

    MediaEntry(String i, String n, String u, String g, String ext, int k) {
        this(i, n, u, g, ext, k, "", "", "", "");
    }

    MediaEntry(String i, String n, String u, String g, String ext, int k,
               String p, String r, String y, String a) {
        id = i; name = n; url = u; group = g; extension = ext; kind = k;
        poster = p == null ? "" : p;
        rating = r == null ? "" : r;
        year = y == null ? "" : y;
        added = a == null ? "" : a;
    }
}
