package com.mtiptv.app;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/** Shared HTTP stack with consistent timeouts and transport checks. */
final class NetworkClient {
    private static final OkHttpClient CLIENT = new OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .build();

    static String getText(String url) throws IOException {
        TransportPolicy.requireAllowed(url);
        Request request = new Request.Builder()
                .url(url)
                .header("User-Agent", "Aureon/34.0")
                .header("Accept", "*/*")
                .build();
        try (Response response = CLIENT.newCall(request).execute()) {
            if (!response.isSuccessful()) throw new IOException("HTTP " + response.code());
            ResponseBody body = response.body();
            if (body == null) throw new IOException("Resposta vazia");
            return body.string();
        }
    }

    static OkHttpClient client() { return CLIENT; }

    private NetworkClient() {}
}
