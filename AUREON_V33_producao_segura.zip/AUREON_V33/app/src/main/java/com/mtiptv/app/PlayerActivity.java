package com.mtiptv.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.okhttp.OkHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.List;

/** Dedicated playback screen. Network, resume and recovery behavior live outside MainActivity. */
public class PlayerActivity extends Activity {
    private ExoPlayer player;
    private ProgressBar loading;
    private PlayerView playerView;
    private TextView title;
    private TextView liveBadge;
    private FrameLayout root;

    private static final long TITLE_TIMEOUT_MS = 2500L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable hideTitle = () -> { if (title != null) title.setVisibility(View.GONE); };

    private int currentKind = MainActivity.MOVIE;
    private ArrayList<MediaEntry> queue = new ArrayList<>();
    private MediaEntry currentEntry;
    private String initialUrl = "", initialName = "";
    private int reconnectAttempts = 0;
    private boolean resumeApplied = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        AppCrashReporter.install(this);
        enterImmersiveMode();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        initialUrl = getIntent().getStringExtra("url"); if (initialUrl == null) initialUrl = "";
        initialName = getIntent().getStringExtra("name"); if (initialName == null) initialName = getString(R.string.app_name);
        currentKind = getIntent().getIntExtra("kind", MainActivity.MOVIE);

        setContentView(R.layout.activity_player);
        root = findViewById(R.id.player_root);
        playerView = findViewById(R.id.player_view);
        loading = findViewById(R.id.player_loading);
        title = findViewById(R.id.player_title);
        liveBadge = findViewById(R.id.live_badge);
        title.setText(initialName);

        playerView.setUseController(true);
        playerView.setKeepScreenOn(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        playerView.setControllerAutoShow(true);
        playerView.setControllerHideOnTouch(true);
        playerView.setControllerShowTimeoutMs(2500);
        playerView.setControllerVisibilityListener((PlayerView.ControllerVisibilityListener) visibility -> {
            if (visibility == View.VISIBLE) showTitleTemporarily();
        });

        root.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() != KeyEvent.ACTION_UP) return false;
            if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
                if (player != null && player.hasNextMediaItem()) player.seekToNextMediaItem();
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
                if (player != null && player.hasPreviousMediaItem()) player.seekToPreviousMediaItem();
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
                if (playerView.isControllerFullyVisible()) playerView.hideController(); else playerView.showController();
                return true;
            }
            return false;
        });
        root.requestFocus();
        showTitleTemporarily();

        OkHttpDataSource.Factory httpFactory = new OkHttpDataSource.Factory(NetworkClient.client())
                .setUserAgent("Aureon/33.0");
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(
                        currentKind == MainActivity.LIVE ? 2500 : 8000,
                        currentKind == MainActivity.LIVE ? 16000 : 45000,
                        currentKind == MainActivity.LIVE ? 500 : 1000,
                        currentKind == MainActivity.LIVE ? 1000 : 2200)
                .setPrioritizeTimeOverSizeThresholds(true)
                .build();

        player = new ExoPlayer.Builder(this)
                .setLoadControl(loadControl)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(httpFactory))
                .build();
        player.setHandleAudioBecomingNoisy(true);
        playerView.setPlayer(player);
        updateLiveUi();

        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                loading.setVisibility(state == Player.STATE_BUFFERING || state == Player.STATE_IDLE ? View.VISIBLE : View.GONE);
                if (state == Player.STATE_READY) {
                    reconnectAttempts = 0;
                    playerView.hideController();
                }
                if (state == Player.STATE_ENDED) saveProgressNow();
            }

            @Override public void onMediaItemTransition(MediaItem mediaItem, int reason) {
                saveProgressNow();
                resumeApplied = false;
                int index = player.getCurrentMediaItemIndex();
                MainActivity.setPlayerQueueIndex(index);
                if (index >= 0 && index < queue.size()) currentEntry = queue.get(index);
                else currentEntry = new MediaEntry("", mediaItem == null ? initialName : String.valueOf(mediaItem.mediaMetadata.title), initialUrl, "", "", currentKind);
                if (currentEntry != null) {
                    currentKind = currentEntry.kind;
                    PlaybackStore.markRecent(PlayerActivity.this, currentEntry);
                    title.setText(currentEntry.name == null ? getString(R.string.app_name) : currentEntry.name);
                }
                updateLiveUi();
                applyResumeIfNeeded();
                showTitleTemporarily();
            }

            @Override public void onPlayerError(PlaybackException error) {
                AppCrashReporter.record(PlayerActivity.this, error);
                loading.setVisibility(View.VISIBLE);
                if (reconnectAttempts < 3) {
                    reconnectAttempts++;
                    long delay = 800L * (1L << (reconnectAttempts - 1));
                    Toast.makeText(PlayerActivity.this,
                            getString(R.string.reconnecting, reconnectAttempts, 3), Toast.LENGTH_SHORT).show();
                    handler.postDelayed(PlayerActivity.this::retryCurrent, delay);
                } else {
                    loading.setVisibility(View.GONE);
                    Toast.makeText(PlayerActivity.this, R.string.playback_failed, Toast.LENGTH_LONG).show();
                }
            }
        });

        playQueueOrSingle(initialUrl, initialName, currentKind);
    }

    private void updateLiveUi() {
        boolean live = currentKind == MainActivity.LIVE;
        liveBadge.setVisibility(live ? View.VISIBLE : View.GONE);
        try {
            playerView.setShowRewindButton(!live);
            playerView.setShowFastForwardButton(!live);
        } catch (Throwable ignored) {}
    }

    private void retryCurrent() {
        if (player == null || isFinishing()) return;
        try {
            long pos = player.getCurrentPosition();
            int idx = player.getCurrentMediaItemIndex();
            player.stop();
            if (idx >= 0) player.seekTo(idx, Math.max(0, pos));
            player.prepare();
            player.play();
        } catch (Exception error) {
            AppCrashReporter.record(this, error);
        }
    }

    private void applyResumeIfNeeded() {
        if (resumeApplied || currentEntry == null || currentEntry.kind == MainActivity.LIVE
                || !AppPrefs.get(this).getBoolean("resume_vod", true)) return;
        long saved = PlaybackStore.progressMs(this, currentEntry);
        if (saved > 15000 && player != null) {
            player.seekTo(saved);
            Toast.makeText(this, R.string.resume_playback, Toast.LENGTH_SHORT).show();
        }
        resumeApplied = true;
    }

    private void saveProgressNow() {
        try {
            if (player != null && currentEntry != null)
                PlaybackStore.saveProgress(this, currentEntry, player.getCurrentPosition(), player.getDuration());
        } catch (Exception ignored) {}
    }

    private void showTitleTemporarily() {
        if (title == null || isFinishing() || isDestroyed()) return;
        handler.removeCallbacks(hideTitle);
        title.setVisibility(View.VISIBLE);
        handler.postDelayed(hideTitle, TITLE_TIMEOUT_MS);
    }

    private void playQueueOrSingle(String url, String name, int kind) {
        currentKind = kind;
        queue = MainActivity.playerQueueSnapshot();
        int start = MainActivity.getPlayerQueueIndex();

        if (!queue.isEmpty() && start >= 0 && start < queue.size()) {
            List<MediaItem> mediaItems = new ArrayList<>();
            ArrayList<MediaEntry> playable = new ArrayList<>();
            for (MediaEntry entry : queue) {
                if (entry == null || entry.url == null || entry.url.trim().isEmpty()) continue;
                try { TransportPolicy.requireAllowed(entry.url); } catch (Exception blocked) { continue; }
                playable.add(entry);
                MediaMetadata metadata = new MediaMetadata.Builder()
                        .setTitle(entry.name == null ? getString(R.string.app_name) : entry.name).build();
                mediaItems.add(new MediaItem.Builder().setUri(entry.url).setMediaMetadata(metadata).build());
            }
            queue = playable;
            if (!mediaItems.isEmpty()) {
                int safeStart = Math.min(start, mediaItems.size() - 1);
                currentEntry = queue.get(safeStart);
                currentKind = currentEntry.kind;
                PlaybackStore.markRecent(this, currentEntry);
                long resume = (currentEntry.kind != MainActivity.LIVE && AppPrefs.get(this).getBoolean("resume_vod", true))
                        ? PlaybackStore.progressMs(this, currentEntry) : C.TIME_UNSET;
                player.setMediaItems(mediaItems, safeStart, resume > 15000 ? resume : C.TIME_UNSET);
                player.setPlayWhenReady(true);
                player.prepare();
                resumeApplied = resume > 15000;
                updateLiveUi();
                return;
            }
        }

        if (url == null || url.trim().isEmpty()) {
            loading.setVisibility(View.GONE);
            Toast.makeText(this, R.string.invalid_content_link, Toast.LENGTH_LONG).show();
            return;
        }
        try {
            TransportPolicy.requireAllowed(url);
        } catch (Exception blocked) {
            loading.setVisibility(View.GONE);
            Toast.makeText(this, blocked.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        currentEntry = new MediaEntry("", name, url, "", "", kind);
        PlaybackStore.markRecent(this, currentEntry);
        MediaMetadata metadata = new MediaMetadata.Builder().setTitle(name == null ? getString(R.string.app_name) : name).build();
        player.setMediaItem(new MediaItem.Builder().setUri(url).setMediaMetadata(metadata).build());
        long resume = (kind != MainActivity.LIVE && AppPrefs.get(this).getBoolean("resume_vod", true))
                ? PlaybackStore.progressMs(this, currentEntry) : 0;
        if (resume > 15000) { player.seekTo(resume); resumeApplied = true; }
        player.setPlayWhenReady(true);
        player.prepare();
        updateLiveUi();
    }

    private void enterImmersiveMode() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) { super.onWindowFocusChanged(hasFocus); if (hasFocus) enterImmersiveMode(); }
    @Override protected void onPause() { saveProgressNow(); super.onPause(); }
    @Override protected void onStop() { saveProgressNow(); super.onStop(); if (player != null) player.pause(); handler.removeCallbacks(hideTitle); hideTitle.run(); }
    @Override protected void onStart() { super.onStart(); if (player != null) player.play(); showTitleTemporarily(); }
    @Override protected void onDestroy() {
        saveProgressNow();
        if (player != null) { player.release(); player = null; }
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
