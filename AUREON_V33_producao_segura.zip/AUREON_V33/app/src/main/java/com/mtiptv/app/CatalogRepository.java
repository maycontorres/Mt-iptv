package com.mtiptv.app;

import android.net.Uri;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Network/data layer for Xtream and remote M3U sources. */
final class CatalogRepository {

    static String normalizeServer(String raw) throws Exception {
        String value = raw == null ? "" : raw.trim();
        if (!value.startsWith("http://") && !value.startsWith("https://"))
            value = (BuildConfig.ALLOW_CLEARTEXT ? "http://" : "https://") + value;
        TransportPolicy.requireAllowed(value);
        URL u = new URL(value);
        String path = u.getPath() == null ? "" : u.getPath();
        if (path.endsWith("/get.php") || path.endsWith("/player_api.php")) path = path.substring(0, path.lastIndexOf('/'));
        else if (path.equals("/")) path = "";
        else if (path.endsWith("/")) path = path.substring(0, path.length() - 1);
        int port = u.getPort();
        return u.getProtocol() + "://" + u.getHost() + (port > 0 ? ":" + port : "") + path;
    }

    static XtreamCreds xtreamFromM3uUrl(String raw) {
        try {
            if (raw == null || raw.trim().isEmpty()) return null;
            Uri u = Uri.parse(raw.trim());
            String user = u.getQueryParameter("username"), pass = u.getQueryParameter("password");
            String path = u.getPath() == null ? "" : u.getPath().toLowerCase(Locale.US);
            if (user == null || pass == null || user.isEmpty() || pass.isEmpty() || !path.endsWith("get.php")) return null;
            return new XtreamCreds(normalizeServer(raw), user, pass);
        } catch (Exception ignored) { return null; }
    }

    static void verifyXtream(XtreamCreds x) throws Exception {
        JSONObject root = new JSONObject(NetworkClient.getText(api(x, "")));
        JSONObject user = root.optJSONObject("user_info");
        if (user == null) throw new IOException("servidor Xtream não respondeu corretamente");
        if ("0".equals(user.optString("auth", "1"))) throw new IOException("usuário ou senha inválidos");
    }

    static DetailInfo loadMovieDetail(XtreamCreds x, MediaEntry e) throws Exception {
        JSONObject root = new JSONObject(NetworkClient.getText(api(x, "get_vod_info&vod_id=" + enc(e.id))));
        JSONObject info = root.optJSONObject("info"); if (info == null) info = new JSONObject();
        JSONObject data = root.optJSONObject("movie_data"); if (data == null) data = new JSONObject();
        DetailInfo d = basicDetail(e);
        d.plot = pick(info, data, "plot", "description", "overview");
        d.genre = firstNonEmpty(pick(info, data, "genre", "genres"), d.genre);
        d.cast = pick(info, data, "cast", "actors");
        d.director = pick(info, data, "director");
        d.duration = pick(info, data, "duration", "runtime", "duration_secs");
        d.releaseDate = firstNonEmpty(pick(info, data, "releasedate", "releaseDate", "release_date", "year"), d.releaseDate);
        d.rating = firstNonEmpty(pick(info, data, "rating_5based", "rating", "rating_10based"), d.rating);
        d.poster = firstNonEmpty(pick(info, data, "movie_image", "cover_big", "cover", "stream_icon"), d.poster);
        return d;
    }

    static DetailInfo loadSeriesDetail(XtreamCreds x, MediaEntry e) throws Exception {
        JSONObject root = new JSONObject(NetworkClient.getText(api(x, "get_series_info&series_id=" + enc(e.id))));
        JSONObject info = root.optJSONObject("info"); if (info == null) info = new JSONObject();
        DetailInfo d = basicDetail(e);
        d.plot = pick(info, null, "plot", "description", "overview");
        d.genre = firstNonEmpty(pick(info, null, "genre", "genres"), d.genre);
        d.cast = pick(info, null, "cast", "actors");
        d.director = pick(info, null, "director");
        d.duration = pick(info, null, "episode_run_time", "duration", "runtime");
        d.releaseDate = firstNonEmpty(pick(info, null, "releaseDate", "releasedate", "release_date", "year"), d.releaseDate);
        d.rating = firstNonEmpty(pick(info, null, "rating_5based", "rating", "rating_10based"), d.rating);
        d.poster = firstNonEmpty(pick(info, null, "cover", "cover_big", "movie_image", "stream_icon"), d.poster);
        return d;
    }

    static List<EpgItem> loadShortEpg(XtreamCreds x, MediaEntry e) throws Exception {
        JSONObject root = new JSONObject(NetworkClient.getText(api(x, "get_short_epg&stream_id=" + enc(e.id) + "&limit=10")));
        JSONArray a = root.optJSONArray("epg_list");
        ArrayList<EpgItem> out = new ArrayList<>();
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i); if (o == null) continue;
            String title = decodeMaybeBase64(o.optString("title", o.optString("name", "Programa")));
            String desc = decodeMaybeBase64(o.optString("description", o.optString("desc", "")));
            String start = firstNonEmpty(o.optString("start_timestamp", ""), o.optString("start", ""));
            String end = firstNonEmpty(o.optString("stop_timestamp", o.optString("end_timestamp", "")), o.optString("end", ""));
            out.add(new EpgItem(title, desc, start, end));
        }
        return out;
    }

    static List<MediaEntry> loadXtreamLive(XtreamCreds x) throws Exception { return loadXtreamLive(x, loadXtreamCategoriesSafe(x, "get_live_categories")); }
    static List<MediaEntry> loadXtreamLive(XtreamCreds x, Map<String,String> cats) throws Exception {
        JSONArray a = new JSONArray(NetworkClient.getText(api(x, "get_live_streams"))); ArrayList<MediaEntry> out = new ArrayList<>();
        for (int i = 0; i < a.length() && out.size() < MainActivity.MAX_ITEMS; i++) {
            JSONObject o = a.optJSONObject(i); if (o == null) continue;
            String id=o.optString("stream_id",""); String name=o.optString("name","Canal"); String cid=o.optString("category_id","");
            String g=cats.containsKey(cid)?cats.get(cid):(cid.isEmpty()?"Outros":"Categoria "+cid);
            String url=x.server+"/live/"+encPath(x.user)+"/"+encPath(x.pass)+"/"+id+".ts";
            out.add(new MediaEntry(id,name,url,g,"ts",MainActivity.LIVE,o.optString("stream_icon",""),o.optString("rating",""),"",o.optString("added","")));
        }
        return out;
    }

    static List<MediaEntry> loadXtreamMovies(XtreamCreds x) throws Exception { return loadXtreamMovies(x, loadXtreamCategoriesSafe(x, "get_vod_categories")); }
    static List<MediaEntry> loadXtreamMovies(XtreamCreds x, Map<String,String> cats) throws Exception {
        JSONArray a = new JSONArray(NetworkClient.getText(api(x, "get_vod_streams"))); ArrayList<MediaEntry> out = new ArrayList<>();
        for (int i = 0; i < a.length() && out.size() < MainActivity.MAX_ITEMS; i++) {
            JSONObject o=a.optJSONObject(i); if(o==null)continue;
            String id=o.optString("stream_id",""); String name=o.optString("name","Filme"); String cid=o.optString("category_id","");
            String g=cats.containsKey(cid)?cats.get(cid):(cid.isEmpty()?"Outros":"Categoria "+cid); String ext=o.optString("container_extension","mp4");
            String url=x.server+"/movie/"+encPath(x.user)+"/"+encPath(x.pass)+"/"+id+"."+ext;
            String poster=o.optString("stream_icon",o.optString("cover","")); String rating=o.optString("rating_5based",o.optString("rating",""));
            String year=o.optString("year",""); if(year.isEmpty()){String rd=o.optString("releaseDate",o.optString("releasedate",""));if(rd.length()>=4)year=rd.substring(0,4);} String added=o.optString("added","");
            out.add(new MediaEntry(id,name,url,g,ext,MainActivity.MOVIE,poster,rating,year,added));
        }
        return out;
    }

    static List<MediaEntry> loadXtreamSeries(XtreamCreds x) throws Exception { return loadXtreamSeries(x, loadXtreamCategoriesSafe(x, "get_series_categories")); }
    static List<MediaEntry> loadXtreamSeries(XtreamCreds x, Map<String,String> cats) throws Exception {
        JSONArray a = new JSONArray(NetworkClient.getText(api(x, "get_series"))); ArrayList<MediaEntry> out = new ArrayList<>();
        for (int i = 0; i < a.length() && out.size() < MainActivity.MAX_ITEMS; i++) {
            JSONObject o=a.optJSONObject(i);if(o==null)continue;String id=o.optString("series_id","");String name=o.optString("name","Série");String cid=o.optString("category_id","");
            String g=cats.containsKey(cid)?cats.get(cid):(cid.isEmpty()?"Outros":"Categoria "+cid);String poster=o.optString("cover",o.optString("stream_icon",""));String rating=o.optString("rating_5based",o.optString("rating",""));
            String year=o.optString("year","");if(year.isEmpty()){String rd=o.optString("releaseDate",o.optString("last_modified",""));if(rd.length()>=4&&!rd.matches("\\d+"))year=rd.substring(0,4);}String added=o.optString("last_modified",o.optString("added",""));
            out.add(new MediaEntry(id,name,null,g,"",MainActivity.SERIES,poster,rating,year,added));
        }
        return out;
    }

    static List<MediaEntry> loadXtreamEpisodes(XtreamCreds x, MediaEntry series) throws Exception {
        JSONObject root = new JSONObject(NetworkClient.getText(api(x, "get_series_info&series_id=" + enc(series.id))));
        JSONObject eps = root.optJSONObject("episodes"); ArrayList<MediaEntry> out = new ArrayList<>(); if (eps == null) return out;
        ArrayList<String> seasons = new ArrayList<>(); Iterator<String> it=eps.keys(); while(it.hasNext())seasons.add(it.next());
        Collections.sort(seasons,(a,b)->{try{return Integer.compare(Integer.parseInt(a),Integer.parseInt(b));}catch(Exception e){return a.compareToIgnoreCase(b);}});
        for(String season:seasons){JSONArray ar=eps.optJSONArray(season);if(ar==null)continue;for(int i=0;i<ar.length();i++){JSONObject o=ar.optJSONObject(i);if(o==null)continue;String id=o.optString("id","");String title=o.optString("title","Episódio "+(i+1));String ext=o.optString("container_extension","mp4");String url=x.server+"/series/"+encPath(x.user)+"/"+encPath(x.pass)+"/"+id+"."+ext;JSONObject info=o.optJSONObject("info");String poster=info==null?series.poster:info.optString("movie_image",series.poster);String added=o.optString("added","");out.add(new MediaEntry(id,title,url,"Temporada "+season,ext,MainActivity.MOVIE,poster,"","",added));}}
        return out;
    }

    static LinkedHashMap<String,String> loadXtreamCategories(XtreamCreds x, String action) throws Exception {
        JSONArray a = new JSONArray(NetworkClient.getText(api(x, action))); LinkedHashMap<String,String> map = new LinkedHashMap<>();
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null){String id=o.optString("category_id","");String name=o.optString("category_name","Outros").trim();if(!id.isEmpty()&&!name.isEmpty())map.put(id,name);}}
        return map;
    }
    static LinkedHashMap<String,String> loadXtreamCategoriesSafe(XtreamCreds x, String action) { try{return loadXtreamCategories(x,action);}catch(Exception ignored){return new LinkedHashMap<>();} }

    static List<MediaEntry> loadFromUrl(String url) throws Exception {
        String body = NetworkClient.getText(url);
        try (BufferedReader r = new BufferedReader(new StringReader(body))) { return parseReader(r); }
    }

    static List<MediaEntry> parseReader(BufferedReader r) throws Exception {
        ArrayList<MediaEntry> out=new ArrayList<>(); String name=null,group="Geral",poster="",line;
        while((line=r.readLine())!=null&&out.size()<MainActivity.MAX_ITEMS){String l=line.trim();if(l.startsWith("#EXTINF")){int comma=l.indexOf(',');name=comma>=0?l.substring(comma+1).trim():"Canal";group=attr(l,"group-title");if(group.isEmpty())group="Geral";poster=attr(l,"tvg-logo");}else if(!l.startsWith("#")&&!l.isEmpty()&&name!=null){int kind=classify(name,group,l);String ext=extension(l);out.add(new MediaEntry("",name,l,group,ext,kind,poster,"","",""));name=null;group="Geral";poster="";}}
        sort(out);return out;
    }

    static List<MediaEntry> loadXtreamM3uFallback(XtreamCreds x, int kind) throws Exception {
        String m3u=x.server+"/get.php?username="+enc(x.user)+"&password="+enc(x.pass)+"&type=m3u_plus&output=ts";
        List<MediaEntry> all=loadFromUrl(m3u);ArrayList<MediaEntry> out=new ArrayList<>();for(MediaEntry e:all)if(e.kind==kind)out.add(e);return out;
    }

    private static String api(XtreamCreds x,String action) throws Exception { return x.server+"/player_api.php?username="+enc(x.user)+"&password="+enc(x.pass)+(action==null||action.isEmpty()?"":"&action="+action); }
    private static String enc(String s) throws Exception { return URLEncoder.encode(s,"UTF-8"); }
    private static String encPath(String s) { return Uri.encode(s); }
    private static void sort(List<MediaEntry> list){Collections.sort(list,Comparator.comparing((MediaEntry e)->e.group==null?"":e.group,String.CASE_INSENSITIVE_ORDER).thenComparing(e->e.name==null?"":e.name,String.CASE_INSENSITIVE_ORDER));}
    private static String attr(String l,String key){String needle=key+"=\"";int a=l.indexOf(needle);if(a<0)return "";int b=l.indexOf('"',a+needle.length());return b>a?l.substring(a+needle.length(),b):"";}
    private static String extension(String url){String x=url.toLowerCase(Locale.US);int q=x.indexOf('?');if(q>=0)x=x.substring(0,q);int dot=x.lastIndexOf('.');return dot>=0?x.substring(dot+1):"";}
    private static int classify(String name,String group,String url){String u=url==null?"":url.toLowerCase(Locale.US);String meta=((name==null?"":name)+" "+(group==null?"":group)).toLowerCase(Locale.US);if(u.contains("/live/"))return MainActivity.LIVE;if(u.contains("/movie/"))return MainActivity.MOVIE;if(u.contains("/series/"))return MainActivity.SERIES;String ext=extension(u);if(ext.equals("ts")||ext.equals("m3u8")||ext.equals("m3u")||ext.equals("mpegts"))return MainActivity.LIVE;boolean episodeLike=meta.contains("series")||meta.contains("séries")||meta.contains("serie")||meta.contains("temporada")||meta.contains("season")||meta.contains("episodio")||meta.contains("episódio")||meta.matches(".*\\bs\\d{1,2}e\\d{1,3}\\b.*");if((ext.equals("mp4")||ext.equals("mkv")||ext.equals("avi")||ext.equals("mov")||ext.equals("wmv"))&&episodeLike)return MainActivity.SERIES;if(ext.equals("mp4")||ext.equals("mkv")||ext.equals("avi")||ext.equals("mov")||ext.equals("wmv"))return MainActivity.MOVIE;if(episodeLike)return MainActivity.SERIES;if(meta.contains("filme")||meta.contains("movie")||meta.contains("vod")||meta.contains("cinema"))return MainActivity.MOVIE;return MainActivity.LIVE;}
    private static DetailInfo basicDetail(MediaEntry e){DetailInfo d=new DetailInfo();d.poster=e.poster==null?"":e.poster;d.rating=e.rating==null?"":e.rating;d.releaseDate=e.year==null?"":e.year;d.genre=e.group==null?"":e.group;return d;}
    private static String pick(JSONObject a,JSONObject b,String... keys){for(String k:keys){if(a!=null){String v=a.optString(k,"").trim();if(!v.isEmpty()&&!v.equalsIgnoreCase("null"))return v;}if(b!=null){String v=b.optString(k,"").trim();if(!v.isEmpty()&&!v.equalsIgnoreCase("null"))return v;}}return "";}
    private static String firstNonEmpty(String a,String b){return a!=null&&!a.trim().isEmpty()?a:b==null?"":b;}
    private static String decodeMaybeBase64(String s){if(s==null)return "";String t=s.trim();if(t.isEmpty())return "";try{if(t.length()%4==0&&t.matches("[A-Za-z0-9+/=\\r\\n]+")){String d=new String(Base64.decode(t,Base64.DEFAULT),"UTF-8").trim();if(!d.isEmpty()&&d.indexOf('\u0000')<0)return d;}}catch(Exception ignored){}return t;}

    private CatalogRepository() {}
}
