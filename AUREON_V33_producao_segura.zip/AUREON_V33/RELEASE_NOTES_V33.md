# ÁUREON V33 — Production hardening

Principais mudanças:

- build `release` não-debug, com R8/ProGuard e redução de recursos;
- dois sabores de rede: `secure` (somente HTTPS) e `compat` (HTTP/HTTPS para provedores antigos);
- credenciais Xtream, URL M3U e URL EPG protegidas com AES/GCM no Android Keystore, sem fallback em texto puro;
- backup automático desativado e regras de extração bloqueando preferências/arquivos sensíveis;
- rede centralizada em OkHttp e player Media3 usando datasource OkHttp;
- imagens remotas carregadas com Glide e cache gerenciado;
- modelos e camada de catálogo extraídos de `MainActivity` para arquivos dedicados/repository;
- telas base e player em XML; RecyclerView continua sendo usado nas listas TV/VOD;
- textos principais externalizados em `strings.xml`;
- relatório local de falhas com sanitização de credenciais e integração opcional com Crashlytics via reflexão;
- placeholders de home renomeados como assets reais e imagens raster movidas para `drawable-nodpi`;
- `versionCode 34`, `versionName 33.0`.

## Variantes

- `secureDebug` / `secureRelease`: bloqueia HTTP em manifest e na política do app.
- `compatDebug` / `compatRelease`: aceita HTTP por compatibilidade. Use apenas quando o servidor não oferecer HTTPS.

## Assinatura de release

O `app/build.gradle` aceita as variáveis de ambiente:

- `AUREON_KEYSTORE_PATH`
- `AUREON_KEYSTORE_PASSWORD`
- `AUREON_KEY_ALIAS`
- `AUREON_KEY_PASSWORD`

Sem essas variáveis, o Gradle ainda consegue compilar a variante release para validar R8, mas o APK sai não assinado. Nunca coloque a keystore ou as senhas em um repositório público.

## Crash reporting remoto

`AppCrashReporter` sempre grava até 5 relatórios locais sanitizados. Ele também detecta Firebase Crashlytics por reflexão caso o SDK/configuração Firebase seja adicionado no futuro. A ativação remota exige um projeto Firebase e `google-services.json`, que não deve ser inventado nem hardcoded.
