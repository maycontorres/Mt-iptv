package com.mtiptv.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.List;

public class PlayerActivity extends Activity {
    ExoPlayer player;
    ProgressBar loading;
    PlayerView playerView;
    TextView title;
    static final long TITLE_TIMEOUT_MS=2500L;
    final Handler handler=new Handler(Looper.getMainLooper());
    final Runnable hideTitle=()->{ if(title!=null)title.setVisibility(View.GONE); };
    int currentKind=1;
    ArrayList<MainActivity.MediaEntry> queue=new ArrayList<>();
    MainActivity.MediaEntry currentEntry;
    String initialUrl="", initialName="";
    int reconnectAttempts=0;
    boolean resumeApplied=false;

    int dp(float v){ return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        enterImmersiveMode();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        initialUrl=getIntent().getStringExtra("url"); if(initialUrl==null)initialUrl="";
        initialName=getIntent().getStringExtra("name"); if(initialName==null)initialName="ÁUREON";
        currentKind=getIntent().getIntExtra("kind",1);

        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK); root.setFocusableInTouchMode(true);
        playerView=new PlayerView(this); playerView.setUseController(true); playerView.setKeepScreenOn(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING); playerView.setControllerAutoShow(true);
        playerView.setControllerHideOnTouch(true); playerView.setControllerShowTimeoutMs(2500);
        root.addView(playerView,new FrameLayout.LayoutParams(-1,-1));

        loading=new ProgressBar(this); loading.setIndeterminate(true); FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(58),dp(58)); lp.gravity=Gravity.CENTER; root.addView(loading,lp);
        title=new TextView(this); title.setText(initialName); title.setTextColor(Color.WHITE); title.setTextSize(15); title.setPadding(dp(16),dp(10),dp(16),dp(10)); title.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-2,-2); tp.gravity=Gravity.TOP|Gravity.LEFT; tp.leftMargin=dp(10); tp.topMargin=dp(8); root.addView(title,tp);
        playerView.setControllerVisibilityListener((PlayerView.ControllerVisibilityListener) visibility->{if(visibility==View.VISIBLE)showTitleTemporarily();});

        root.setOnKeyListener((v,keyCode,event)->{
            if(event.getAction()!=KeyEvent.ACTION_UP)return false;
            if(keyCode==KeyEvent.KEYCODE_MEDIA_NEXT){ if(player!=null&&player.hasNextMediaItem())player.seekToNextMediaItem(); return true; }
            if(keyCode==KeyEvent.KEYCODE_MEDIA_PREVIOUS){ if(player!=null&&player.hasPreviousMediaItem())player.seekToPreviousMediaItem(); return true; }
            if(keyCode==KeyEvent.KEYCODE_DPAD_CENTER||keyCode==KeyEvent.KEYCODE_ENTER){ if(playerView.isControllerFullyVisible())playerView.hideController();else playerView.showController();return true; }
            return false;
        });
        root.requestFocus(); setContentView(root); showTitleTemporarily();

        DefaultHttpDataSource.Factory httpFactory=new DefaultHttpDataSource.Factory().setUserAgent("Aureon/32.0").setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(12000).setReadTimeoutMs(30000);
        DefaultLoadControl loadControl=new DefaultLoadControl.Builder()
                .setBufferDurationsMs(currentKind==MainActivity.LIVE?2500:8000,currentKind==MainActivity.LIVE?16000:45000,currentKind==MainActivity.LIVE?500:1000,currentKind==MainActivity.LIVE?1000:2200)
                .setPrioritizeTimeOverSizeThresholds(true).build();
        player=new ExoPlayer.Builder(this).setLoadControl(loadControl).setMediaSourceFactory(new DefaultMediaSourceFactory(httpFactory)).build();
        player.setHandleAudioBecomingNoisy(true); playerView.setPlayer(player);
        player.addListener(new Player.Listener(){
            @Override public void onPlaybackStateChanged(int state){
                loading.setVisibility(state==Player.STATE_BUFFERING||state==Player.STATE_IDLE?View.VISIBLE:View.GONE);
                if(state==Player.STATE_READY){ reconnectAttempts=0; playerView.hideController(); }
                if(state==Player.STATE_ENDED)saveProgressNow();
            }
            @Override public void onMediaItemTransition(MediaItem mediaItem,int reason){
                saveProgressNow(); resumeApplied=false;
                int index=player.getCurrentMediaItemIndex(); MainActivity.setPlayerQueueIndex(index);
                if(index>=0&&index<queue.size())currentEntry=queue.get(index);
                else currentEntry=new MainActivity.MediaEntry("",mediaItem==null?initialName:String.valueOf(mediaItem.mediaMetadata.title),initialUrl,"","",currentKind);
                if(currentEntry!=null){currentKind=currentEntry.kind;PlaybackStore.markRecent(PlayerActivity.this,currentEntry);title.setText(currentEntry.name==null?"ÁUREON":currentEntry.name);}
                applyResumeIfNeeded(); showTitleTemporarily();
            }
            @Override public void onPlayerError(PlaybackException error){
                loading.setVisibility(View.VISIBLE);
                if(reconnectAttempts<2){
                    reconnectAttempts++; long delay=900L*reconnectAttempts;
                    Toast.makeText(PlayerActivity.this,"Reconectando… ("+reconnectAttempts+"/2)",Toast.LENGTH_SHORT).show();
                    handler.postDelayed(()->retryCurrent(),delay);
                }else{
                    loading.setVisibility(View.GONE); Toast.makeText(PlayerActivity.this,"Não foi possível reproduzir. Tente o próximo item ou verifique o servidor.",Toast.LENGTH_LONG).show();
                }
            }
        });
        playQueueOrSingle(initialUrl,initialName,currentKind);
    }

    void retryCurrent(){
        if(player==null||isFinishing())return;
        try{long pos=player.getCurrentPosition();int idx=player.getCurrentMediaItemIndex();player.stop();if(idx>=0)player.seekTo(idx,Math.max(0,pos));player.prepare();player.play();}catch(Exception ignored){}
    }

    void applyResumeIfNeeded(){
        if(resumeApplied||currentEntry==null||currentEntry.kind==MainActivity.LIVE||!getSharedPreferences("mt",0).getBoolean("resume_vod",true))return;
        long saved=PlaybackStore.progressMs(this,currentEntry); if(saved>15000&&player!=null){player.seekTo(saved);Toast.makeText(this,"Continuando de onde você parou",Toast.LENGTH_SHORT).show();} resumeApplied=true;
    }

    void saveProgressNow(){
        try{if(player!=null&&currentEntry!=null)PlaybackStore.saveProgress(this,currentEntry,player.getCurrentPosition(),player.getDuration());}catch(Exception ignored){}
    }

    void showTitleTemporarily(){ if(title==null||isFinishing()||isDestroyed())return;handler.removeCallbacks(hideTitle);title.setVisibility(View.VISIBLE);handler.postDelayed(hideTitle,TITLE_TIMEOUT_MS); }

    void playQueueOrSingle(String url,String name,int kind){
        currentKind=kind; queue=MainActivity.playerQueueSnapshot(); int start=MainActivity.getPlayerQueueIndex();
        if(!queue.isEmpty()&&start>=0&&start<queue.size()){
            List<MediaItem> mediaItems=new ArrayList<>(); ArrayList<MainActivity.MediaEntry> playable=new ArrayList<>();
            for(MainActivity.MediaEntry e:queue){if(e==null||e.url==null||e.url.trim().isEmpty())continue;playable.add(e);MediaMetadata metadata=new MediaMetadata.Builder().setTitle(e.name==null?"ÁUREON":e.name).build();mediaItems.add(new MediaItem.Builder().setUri(e.url).setMediaMetadata(metadata).build());}
            queue=playable;
            if(!mediaItems.isEmpty()){
                int safeStart=Math.min(start,mediaItems.size()-1); currentEntry=queue.get(safeStart); PlaybackStore.markRecent(this,currentEntry);
                long resume=(currentEntry.kind!=MainActivity.LIVE&&getSharedPreferences("mt",0).getBoolean("resume_vod",true))?PlaybackStore.progressMs(this,currentEntry):C.TIME_UNSET;
                player.setMediaItems(mediaItems,safeStart,resume>15000?resume:C.TIME_UNSET);player.setPlayWhenReady(true);player.prepare();resumeApplied=resume>15000;return;
            }
        }
        if(url==null||url.trim().isEmpty()){loading.setVisibility(View.GONE);Toast.makeText(this,"Link do conteúdo inválido.",Toast.LENGTH_LONG).show();return;}
        currentEntry=new MainActivity.MediaEntry("",name,url,"","",kind);PlaybackStore.markRecent(this,currentEntry);
        MediaMetadata metadata=new MediaMetadata.Builder().setTitle(name==null?"ÁUREON":name).build();player.setMediaItem(new MediaItem.Builder().setUri(url).setMediaMetadata(metadata).build());
        long resume=(kind!=MainActivity.LIVE&&getSharedPreferences("mt",0).getBoolean("resume_vod",true))?PlaybackStore.progressMs(this,currentEntry):0;
        if(resume>15000){player.seekTo(resume);resumeApplied=true;} player.setPlayWhenReady(true);player.prepare();
    }

    void enterImmersiveMode(){getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}
    @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(hasFocus)enterImmersiveMode();}
    @Override protected void onPause(){saveProgressNow();super.onPause();}
    @Override protected void onStop(){saveProgressNow();super.onStop();if(player!=null)player.pause();handler.removeCallbacks(hideTitle);hideTitle.run();}
    @Override protected void onStart(){super.onStart();if(player!=null)player.play();showTitleTemporarily();}
    @Override protected void onDestroy(){saveProgressNow();if(player!=null){player.release();player=null;}handler.removeCallbacksAndMessages(null);super.onDestroy();}
}
