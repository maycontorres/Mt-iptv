package com.mtiptv.app;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/** Persistent catalog cache. Keeps the last working catalog available instantly after app restarts. */
final class CatalogCache {
    static final class CachedCatalog {
        final List<MainActivity.MediaEntry> items;
        final ArrayList<String> categories;
        final long loadedAt;
        CachedCatalog(List<MainActivity.MediaEntry> items, ArrayList<String> categories, long loadedAt) {
            this.items = items; this.categories = categories; this.loadedAt = loadedAt;
        }
    }

    private static File dir(Context c) {
        File d = new File(c.getFilesDir(), "catalog_cache_v2");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private static String token(String sourceKey, int kind) {
        String s = sourceKey == null ? "" : sourceKey;
        return Integer.toHexString(s.hashCode()) + "_" + kind;
    }

    private static File dataFile(Context c, String sourceKey, int kind) {
        return new File(dir(c), token(sourceKey, kind) + ".json.gz");
    }

    private static File metaFile(Context c, String sourceKey, int kind) {
        return new File(dir(c), token(sourceKey, kind) + ".meta");
    }

    static void save(Context c, String sourceKey, int kind, List<MainActivity.MediaEntry> items,
                     List<String> categories, long loadedAt) {
        if (sourceKey == null || sourceKey.isEmpty() || items == null) return;
        File tmp = new File(dir(c), token(sourceKey, kind) + ".tmp");
        File target = dataFile(c, sourceKey, kind);
        try {
            JSONObject root = new JSONObject();
            root.put("loadedAt", loadedAt);
            JSONArray cats = new JSONArray();
            if (categories != null) for (String s : categories) cats.put(s == null ? "" : s);
            root.put("categories", cats);
            JSONArray arr = new JSONArray();
            for (MainActivity.MediaEntry e : items) {
                if (e == null) continue;
                JSONObject o = new JSONObject();
                o.put("id", nz(e.id)); o.put("name", nz(e.name)); o.put("url", nz(e.url));
                o.put("group", nz(e.group)); o.put("extension", nz(e.extension)); o.put("poster", nz(e.poster));
                o.put("rating", nz(e.rating)); o.put("year", nz(e.year)); o.put("added", nz(e.added)); o.put("kind", e.kind);
                arr.put(o);
            }
            root.put("items", arr);
            byte[] bytes = root.toString().getBytes(StandardCharsets.UTF_8);
            try (GZIPOutputStream gz = new GZIPOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)))) {
                gz.write(bytes);
            }
            if (target.exists()) target.delete();
            if (!tmp.renameTo(target)) {
                try (FileInputStream in = new FileInputStream(tmp); FileOutputStream out = new FileOutputStream(target)) {
                    byte[] b = new byte[8192]; int n; while ((n = in.read(b)) != -1) out.write(b, 0, n);
                }
                tmp.delete();
            }
            JSONObject meta = new JSONObject(); meta.put("count", arr.length()); meta.put("loadedAt", loadedAt);
            try (FileOutputStream out = new FileOutputStream(metaFile(c, sourceKey, kind))) {
                out.write(meta.toString().getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) { tmp.delete(); }
    }

    static CachedCatalog load(Context c, String sourceKey, int kind) {
        if (sourceKey == null || sourceKey.isEmpty()) return null;
        File f = dataFile(c, sourceKey, kind); if (!f.exists() || f.length() == 0) return null;
        try (GZIPInputStream gz = new GZIPInputStream(new BufferedInputStream(new FileInputStream(f)))) {
            ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] b = new byte[8192]; int n;
            while ((n = gz.read(b)) != -1) out.write(b, 0, n);
            JSONObject root = new JSONObject(out.toString("UTF-8"));
            long loadedAt = root.optLong("loadedAt", f.lastModified());
            ArrayList<String> categories = new ArrayList<>(); JSONArray cats = root.optJSONArray("categories");
            if (cats != null) for (int i = 0; i < cats.length(); i++) { String s = cats.optString(i, ""); if (!s.isEmpty()) categories.add(s); }
            ArrayList<MainActivity.MediaEntry> items = new ArrayList<>(); JSONArray arr = root.optJSONArray("items");
            if (arr != null) for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i); if (o == null) continue;
                items.add(new MainActivity.MediaEntry(o.optString("id", ""), o.optString("name", ""), o.optString("url", ""),
                        o.optString("group", ""), o.optString("extension", ""), o.optInt("kind", kind),
                        o.optString("poster", ""), o.optString("rating", ""), o.optString("year", ""), o.optString("added", "")));
            }
            return new CachedCatalog(items, categories, loadedAt);
        } catch (Exception ignored) { return null; }
    }

    static int peekCount(Context c, String sourceKey, int kind) {
        File f = metaFile(c, sourceKey, kind); if (!f.exists()) return -1;
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] b = new byte[512]; int n;
            while ((n = in.read(b)) != -1) out.write(b, 0, n);
            return new JSONObject(out.toString("UTF-8")).optInt("count", -1);
        } catch (Exception ignored) { return -1; }
    }

    static void clear(Context c) {
        File[] fs = dir(c).listFiles(); if (fs != null) for (File f : fs) try { f.delete(); } catch (Exception ignored) {}
    }

    private static String nz(String s) { return s == null ? "" : s; }
}
