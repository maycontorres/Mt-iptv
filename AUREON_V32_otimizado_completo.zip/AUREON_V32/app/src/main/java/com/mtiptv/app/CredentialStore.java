package com.mtiptv.app;

import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Stores Xtream username/password encrypted with Android Keystore (API 23+). */
final class CredentialStore {
    private static final String ALIAS="aureon_xtream_key_v1";
    private static final String U="xt_user_secure", P="xt_pass_secure";

    static void migrate(SharedPreferences prefs){
        if(prefs.contains(U)||prefs.contains(P))return;
        String u=prefs.getString("xt_user",""),p=prefs.getString("xt_pass","");
        if((u!=null&&!u.isEmpty())||(p!=null&&!p.isEmpty()))save(prefs,u,p);
    }
    static String user(SharedPreferences prefs){return read(prefs,U,prefs.getString("xt_user",""));}
    static String pass(SharedPreferences prefs){return read(prefs,P,prefs.getString("xt_pass",""));}
    static void save(SharedPreferences prefs,String user,String pass){
        try{
            String eu=encrypt(user==null?"":user),ep=encrypt(pass==null?"":pass);
            prefs.edit().putString(U,eu).putString(P,ep).remove("xt_user").remove("xt_pass").apply();
        }catch(Exception e){prefs.edit().putString("xt_user",user==null?"":user).putString("xt_pass",pass==null?"":pass).apply();}
    }
    static void clear(SharedPreferences prefs){prefs.edit().remove(U).remove(P).remove("xt_user").remove("xt_pass").apply();}
    private static String read(SharedPreferences prefs,String key,String fallback){
        String v=prefs.getString(key,"");if(v==null||v.isEmpty())return fallback==null?"":fallback;
        try{return decrypt(v);}catch(Exception e){return fallback==null?"":fallback;}
    }
    private static SecretKey key() throws Exception{
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(ks.containsAlias(ALIAS))return ((KeyStore.SecretKeyEntry)ks.getEntry(ALIAS,null)).getSecretKey();
        KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return kg.generateKey();
    }
    private static String encrypt(String s)throws Exception{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());byte[] iv=c.getIV(),ct=c.doFinal(s.getBytes(StandardCharsets.UTF_8));byte[] all=new byte[1+iv.length+ct.length];all[0]=(byte)iv.length;System.arraycopy(iv,0,all,1,iv.length);System.arraycopy(ct,0,all,1+iv.length,ct.length);return Base64.encodeToString(all,Base64.NO_WRAP);}
    private static String decrypt(String s)throws Exception{byte[] all=Base64.decode(s,Base64.NO_WRAP);int n=all[0]&0xff;byte[] iv=new byte[n],ct=new byte[all.length-1-n];System.arraycopy(all,1,iv,0,n);System.arraycopy(all,1+n,ct,0,ct.length);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,iv));return new String(c.doFinal(ct),StandardCharsets.UTF_8);}
}
