package com.mtiptv.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.LruCache;
import android.util.Base64;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ProgressBar;
import android.content.res.ColorStateList;
import android.os.SystemClock;

import androidx.media3.common.MediaItem;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.GridLayoutManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.os.Handler;
import android.os.Looper;
import java.util.zip.GZIPInputStream;

public class MainActivity extends Activity {
    static final int LIVE=0, MOVIE=1, SERIES=2;
    static final int PAGE_SIZE=80, MAX_ITEMS=50000;

    final int GOLD=Color.rgb(229,178,63), BG=Color.rgb(5,5,6), PANEL=Color.rgb(15,15,17),
            CARD=Color.rgb(18,18,20), WHITE=Color.rgb(245,245,245), MUTED=Color.rgb(170,170,175);

    LinearLayout root, nav, content, browserList;
    RecyclerView browserRecycler, mediaRecycler;
    TextView browserResultCount;
    ChannelRecyclerAdapter channelRecyclerAdapter;
    MediaRecyclerAdapter mediaRecyclerAdapter;
    ScrollView contentScroll, navScroll;
    SharedPreferences prefs;
    ExecutorService exec=Executors.newSingleThreadExecutor();
    // Carregamento das três bibliotecas em paralelo. Isso evita esperar TV terminar para só então buscar Filmes/Séries.
    ExecutorService dataExec=Executors.newFixedThreadPool(2);
    ExecutorService imageExec=Executors.newFixedThreadPool(4);
    ExecutorService cacheExec=Executors.newSingleThreadExecutor();
    LruCache<String,Bitmap> imageCache=new LruCache<String,Bitmap>((int)Math.min(32L*1024L*1024L,Math.max(8L*1024L*1024L,Runtime.getRuntime().maxMemory()/10L))){
        @Override protected int sizeOf(String key,Bitmap value){ return value==null?0:value.getByteCount(); }
    };
    Uri selectedM3u;
    final Handler uiHandler=new Handler(Looper.getMainLooper());
    static final long STARTUP_MIN_MS=1400L;
    long startupStartedAt;
    final Runnable prepareStartupTask=this::prepareStartup;
    final Runnable finishStartupTask=()->{
        if(!isFinishing()&&!isDestroyed())build();
    };
    File imageDiskDir;
    TextView pageTitle, status;
    String activeScreen="";
    boolean compact, navCollapsed=false, navHidden=false;
    int navWidth;
    Button topMenuButton;
    List<MediaEntry> playlistCache=new ArrayList<>(), browserAll=new ArrayList<>(), browserFiltered=new ArrayList<>();
    List<String> browserCategoryOrder=new ArrayList<>();
    int browserShown=0, browserKind=LIVE;
    String browserGroup="Todos", browserQuery="";
    boolean browserSortRecent=true;
    GridLayout mediaGrid;
    TextView mediaCount;
    LinearLayout categoryColumn;
    EditText categorySearch;

    // Cache de TV / Filmes / Séries em memória. Trocar de aba não baixa a lista novamente.
    static final long SECTION_CACHE_TTL_MS=60L*60L*1000L;
    final Object sectionCacheLock=new Object();
    final Map<Integer,SectionData> sectionCache=new LinkedHashMap<>();
    final Set<Integer> sectionLoading=new LinkedHashSet<>();
    volatile int currentSectionRequest=-1;
    final Map<String,DetailInfo> detailCache=new LinkedHashMap<>();
    final Map<String,List<EpgItem>> epgCache=new LinkedHashMap<>();
    ExoPlayer previewPlayer;
    PlayerView previewPlayerView;
    MediaEntry previewEntry;
    LinearLayout liveEpgContainer;

    // Navegação Anterior/Próximo para detalhes e player.
    List<MediaEntry> detailNavItems=new ArrayList<>();
    // Estado para o botão Voltar/D-pad: ao sair de detalhes, retorna à mesma categoria/item.
    int detailScreenKind=-1, restoreKind=-1;
    String restoreGroup="Todos", restoreQuery="", restoreFocusKey="";
    FeaturedTitle pendingFeatured;
    static final ArrayList<MediaEntry> PLAYER_QUEUE=new ArrayList<>();
    static int PLAYER_INDEX=-1;

    static class MediaEntry {
        String id,name,url,group,extension,poster,rating,year,added;
        int kind;
        MediaEntry(String i,String n,String u,String g,String ext,int k){ this(i,n,u,g,ext,k,"","","",""); }
        MediaEntry(String i,String n,String u,String g,String ext,int k,String p,String r,String y,String a){
            id=i;name=n;url=u;group=g;extension=ext;kind=k;poster=p==null?"":p;rating=r==null?"":r;year=y==null?"":y;added=a==null?"":a;
        }
    }

    static class XtreamCreds {
        String server,user,pass;
        XtreamCreds(String s,String u,String p){server=s;user=u;pass=p;}
        boolean valid(){return server!=null&&!server.isEmpty()&&user!=null&&!user.isEmpty()&&pass!=null&&!pass.isEmpty();}
    }

    static class SectionData {
        List<MediaEntry> items;
        ArrayList<String> categories;
        long loadedAt;
        String sourceKey;
        SectionData(List<MediaEntry> i,List<String> c,long t,String k){
            items=new ArrayList<>(i); categories=new ArrayList<>(c); loadedAt=t; sourceKey=k;
        }
    }

    static class DetailInfo {
        String plot="",genre="",cast="",director="",duration="",releaseDate="",rating="",poster="";
    }

    static class EpgItem {
        String title="",description="",start="",end="";
        EpgItem(String t,String d,String s,String e){title=t;description=d;start=s;end=e;}
    }

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+.5f); }

    TextView text(String s,float size){
        TextView t=new TextView(this); t.setText(s); t.setTextColor(WHITE); t.setTextSize(size); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }

    GradientDrawable box(int color,float radius,int strokeColor,int stroke){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); if(stroke>0)g.setStroke(dp(stroke),strokeColor); return g;
    }

    Button button(String s){
        Button b=new Button(this); b.setText(s); b.setTextColor(WHITE); b.setTextSize(compact?11:14); b.setAllCaps(false); b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(42)); b.setPadding(dp(9),0,dp(9),0); b.setBackground(box(CARD,13,Color.rgb(80,63,25),1)); b.setFocusable(true); b.setClickable(true);
        b.setOnFocusChangeListener((v,has)->{
            if(has){ v.setBackground(box(Color.rgb(58,42,15),13,GOLD,3)); focusMotion(v,true); }
            else { v.setBackground(box(CARD,13,Color.rgb(80,63,25),1)); focusMotion(v,false); }
        });
        return b;
    }

    // Android TV / Google TV: deixa o item atual bem visível ao navegar no D-pad.
    void focusMotion(View v,boolean has){
        if(v==null)return;
        v.animate().cancel();
        v.animate().scaleX(has?1.018f:1f).scaleY(has?1.018f:1f).setDuration(85).start();
        if(Build.VERSION.SDK_INT>=21)v.setElevation(has?dp(8):0);
        if(has) revealFocused(v);
    }

    void revealFocused(View v){
        if(v==null)return;
        v.post(()->{
            try{
                android.graphics.Rect r=new android.graphics.Rect(0,0,Math.max(1,v.getWidth()),Math.max(1,v.getHeight()));
                v.requestRectangleOnScreen(r,true);
            }catch(Exception ignored){}
        });
    }

    void focusFirstChild(LinearLayout parent){
        if(parent==null||parent.getChildCount()==0)return;
        parent.post(()->{
            for(int i=0;i<parent.getChildCount();i++){
                View v=parent.getChildAt(i);
                if(v!=null&&v.isFocusable()&&v.getVisibility()==View.VISIBLE){ v.requestFocus(); revealFocused(v); break; }
            }
        });
    }

    void focusFirstBrowserItem(){
        if(browserRecycler==null)return;
        browserRecycler.scrollToPosition(0);
        browserRecycler.postDelayed(()->{RecyclerView.ViewHolder h=browserRecycler.findViewHolderForAdapterPosition(0);if(h!=null){View target=h.itemView;if(target instanceof android.view.ViewGroup&&((android.view.ViewGroup)target).getChildCount()>0)target=((android.view.ViewGroup)target).getChildAt(0);target.requestFocus();revealFocused(target);}},80);
    }

    void focusFirstMediaCard(){
        if(mediaRecycler==null)return;
        mediaRecycler.scrollToPosition(0);
        mediaRecycler.postDelayed(()->{RecyclerView.ViewHolder h=mediaRecycler.findViewHolderForAdapterPosition(0);if(h!=null){View target=h.itemView;if(target instanceof android.view.ViewGroup&&((android.view.ViewGroup)target).getChildCount()>0)target=((android.view.ViewGroup)target).getChildAt(0);target.requestFocus();revealFocused(target);}},80);
    }

    void restoreBrowserItemFocus(String key){
        if(browserRecycler==null||channelRecyclerAdapter==null||key==null||key.isEmpty())return;
        int pos=-1;for(int i=0;i<channelRecyclerAdapter.data.size();i++)if(key.equals(PlaybackStore.key(channelRecyclerAdapter.data.get(i)))){pos=i;break;}
        if(pos<0){focusFirstBrowserItem();return;} final int p=pos; browserRecycler.scrollToPosition(p);
        browserRecycler.postDelayed(()->{RecyclerView.ViewHolder h=browserRecycler.findViewHolderForAdapterPosition(p);if(h!=null){View t=h.itemView;if(t instanceof android.view.ViewGroup&&((android.view.ViewGroup)t).getChildCount()>0)t=((android.view.ViewGroup)t).getChildAt(0);t.requestFocus();revealFocused(t);}},140);
    }

    void restoreMediaItemFocus(String key){
        if(mediaRecycler==null||mediaRecyclerAdapter==null||key==null||key.isEmpty())return;
        int pos=-1;for(int i=0;i<mediaRecyclerAdapter.data.size();i++)if(key.equals(PlaybackStore.key(mediaRecyclerAdapter.data.get(i)))){pos=i;break;}
        if(pos<0){focusFirstMediaCard();return;} final int p=pos; mediaRecycler.scrollToPosition(p);
        mediaRecycler.postDelayed(()->{RecyclerView.ViewHolder h=mediaRecycler.findViewHolderForAdapterPosition(p);if(h!=null){View t=h.itemView;if(t instanceof android.view.ViewGroup&&((android.view.ViewGroup)t).getChildCount()>0)t=((android.view.ViewGroup)t).getChildAt(0);t.requestFocus();revealFocused(t);}},140);
    }

    void returnToSection(int kind){ detailScreenKind=-1; if(kind==LIVE)showLive(); else if(kind==SERIES)showSeries(); else showMovies(); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        enterImmersiveMode();
        prefs=getSharedPreferences("mt",0); compact=getResources().getConfiguration().screenWidthDp<900; navWidth=compact?180:225;
        showStartup();
        // Give the logo a frame to appear before preparing local state.
        uiHandler.postDelayed(prepareStartupTask,32L);
    }

    void showStartup(){
        startupStartedAt=SystemClock.uptimeMillis();
        LinearLayout splash=new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL); splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(BG); splash.setPadding(dp(24),dp(12),dp(24),dp(12));
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.aureon_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER); logo.setContentDescription("ÁUREON");
        int logoHeight=Math.min(compact?180:235,Math.max(80,getResources().getConfiguration().screenHeightDp-120));
        splash.addView(logo,new LinearLayout.LayoutParams(dp(compact?240:310),dp(logoHeight)));
        ProgressBar progress=new ProgressBar(this); progress.setIndeterminate(true);
        progress.setIndeterminateTintList(ColorStateList.valueOf(GOLD));
        progress.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(28),dp(28)); pp.topMargin=dp(14);
        splash.addView(progress,pp);
        TextView loading=text("Preparando seu aplicativo…",compact?12:15);
        loading.setGravity(Gravity.CENTER); loading.setTextColor(MUTED);
        loading.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(36)); lp.topMargin=dp(6);
        splash.addView(loading,lp);
        setContentView(splash);
    }

    void prepareStartup(){
        if(isFinishing()||isDestroyed())return;
        imageDiskDir=new File(getCacheDir(),"aureon_images"); if(!imageDiskDir.exists())imageDiskDir.mkdirs();
        imageExec.submit(this::trimImageDiskCache);
        if(!prefs.contains("autoplay_live")||!prefs.contains("resume_vod")||!prefs.contains("clock_24h")){
            SharedPreferences.Editor defaults=prefs.edit();
            if(!prefs.contains("autoplay_live"))defaults.putBoolean("autoplay_live",true);
            if(!prefs.contains("resume_vod"))defaults.putBoolean("resume_vod",true);
            if(!prefs.contains("clock_24h"))defaults.putBoolean("clock_24h",false);
            defaults.apply();
        }
        CredentialStore.migrate(prefs);
        migrateOldSource();
        String savedUri=prefs.getString("file_uri",""); if(!savedUri.isEmpty())try{selectedM3u=Uri.parse(savedUri);}catch(Exception ignored){}
        // Network availability never gates the home screen; catálogos continuam carregando em segundo plano.
        long remaining=STARTUP_MIN_MS-(SystemClock.uptimeMillis()-startupStartedAt);
        uiHandler.postDelayed(finishStartupTask,Math.max(0L,remaining));
    }

    void enterImmersiveMode(){
        // Compatível com Android 6+ e evita APIs modernas de insets que podem falhar em alguns aparelhos.
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override protected void onResume(){
        super.onResume();
        enterImmersiveMode();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus){
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus) enterImmersiveMode();
    }


    void migrateOldSource(){
        String mode=prefs.getString("source_mode","").trim();
        String file=prefs.getString("file_uri","").trim();
        String xs=prefs.getString("xt_server","").trim();
        String xu=CredentialStore.user(prefs).trim();
        String xp=CredentialStore.pass(prefs).trim();
        String old=prefs.getString("url","").trim();
        String input=prefs.getString("url_input","").trim();

        // Se o modo salvo ainda é válido, não altera nada.
        if(mode.equals("xtream")&&!xs.isEmpty()&&!xu.isEmpty()&&!xp.isEmpty())return;
        if(mode.equals("file")&&!file.isEmpty())return;
        if(mode.equals("m3u")&&(!old.isEmpty()||!input.isEmpty()))return;

        // Credenciais Xtream salvas por versões mais novas.
        if(!xs.isEmpty()&&!xu.isEmpty()&&!xp.isEmpty()){
            prefs.edit().putString("source_mode","xtream").apply();
            return;
        }

        // Versões antigas salvavam a URL get.php completa. Recupera servidor, usuário e senha dela.
        String[] candidates={old,input};
        for(String candidate:candidates){
            if(candidate==null||candidate.trim().isEmpty())continue;
            try{
                XtreamCreds x=xtreamFromM3uUrl(candidate);
                if(x!=null&&x.valid()){
                    prefs.edit().putString("source_mode","xtream")
                            .putString("xt_server",x.server).apply();
                    CredentialStore.save(prefs,x.user,x.pass);
                    return;
                }
            }catch(Exception ignored){}
        }

        if(!file.isEmpty()){
            prefs.edit().putString("source_mode","file").apply();
            return;
        }
        if(!old.isEmpty()){
            prefs.edit().putString("source_mode","m3u").apply();
            return;
        }
        if(!input.isEmpty()){
            prefs.edit().putString("source_mode","m3u").putString("url",input).apply();
        }
    }

    String resolveSourceMode(){
        migrateOldSource();
        String mode=prefs.getString("source_mode","").trim();
        if(mode.equals("xtream")&&savedXtream().valid())return "xtream";
        if(mode.equals("file")&&!prefs.getString("file_uri","").trim().isEmpty())return "file";
        if(mode.equals("m3u")){
            String u=prefs.getString("url","").trim();
            if(u.isEmpty())u=prefs.getString("url_input","").trim();
            if(!u.isEmpty())return "m3u";
        }

        // Última tentativa de recuperação sem depender de source_mode.
        if(savedXtream().valid()){
            prefs.edit().putString("source_mode","xtream").apply();
            return "xtream";
        }
        String u=prefs.getString("url","").trim();
        if(u.isEmpty())u=prefs.getString("url_input","").trim();
        if(!u.isEmpty()){
            try{
                XtreamCreds x=xtreamFromM3uUrl(u);
                if(x!=null&&x.valid()){
                    prefs.edit().putString("source_mode","xtream").putString("xt_server",x.server).apply();
                    CredentialStore.save(prefs,x.user,x.pass);
                    return "xtream";
                }
            }catch(Exception ignored){}
            prefs.edit().putString("source_mode","m3u").putString("url",u).apply();
            return "m3u";
        }
        if(!prefs.getString("file_uri","").trim().isEmpty()){
            prefs.edit().putString("source_mode","file").apply();
            return "file";
        }
        return "";
    }

    void showMissingSource(String title){
        clear(title);
        addTitle(title,24);
        TextView t=text("Sua playlist não foi encontrada nesta instalação. Toque abaixo para conectar novamente sem alterar a interface.",compact?11:14);
        t.setTextColor(MUTED); t.setGravity(Gravity.CENTER); t.setPadding(dp(18),dp(18),dp(18),dp(18));
        content.addView(t,new LinearLayout.LayoutParams(-1,dp(compact?110:130)));
        Button b=button("＋  CONECTAR PLAYLIST"); b.setTextColor(GOLD); b.setOnClickListener(v->showPlaylistManager());
        content.addView(b,new LinearLayout.LayoutParams(-1,dp(56)));
    }

    void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.HORIZONTAL); root.setBackgroundColor(BG); setContentView(root); buildNav(); buildMain(); showHome();
        // Enquanto o usuário vê o Início, aquece TV/Filmes/Séries em segundo plano.
        root.postDelayed(this::prewarmAllSections,1800);
    }

    void buildNav(){
        navScroll=new ScrollView(this); navScroll.setFillViewport(true); navScroll.setVerticalScrollBarEnabled(false); navScroll.setBackgroundColor(Color.rgb(4,6,8));
        nav=new LinearLayout(this); nav.setOrientation(LinearLayout.VERTICAL); navScroll.addView(nav,new ScrollView.LayoutParams(-1,-2));
        root.addView(navScroll,new LinearLayout.LayoutParams(dp(navWidth),-1));
        renderNav();
    }

    void renderNav(){
        if(nav==null)return;
        nav.removeAllViews();
        nav.setPadding(dp(navCollapsed?8:(compact?12:18)),dp(7),dp(navCollapsed?8:(compact?12:18)),dp(12));

        Button toggle=button(navCollapsed?"☰":"☰   Recolher");
        toggle.setTextColor(GOLD); toggle.setGravity(navCollapsed?Gravity.CENTER:Gravity.LEFT|Gravity.CENTER_VERTICAL);
        toggle.setPadding(navCollapsed?0:dp(12),0,0,0); toggle.setOnClickListener(v->toggleNav());
        nav.addView(toggle,new LinearLayout.LayoutParams(-1,dp(navCollapsed?44:42)));

        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.aureon_logo); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams lpLogo=new LinearLayout.LayoutParams(-1,dp(navCollapsed?72:(compact?116:155))); lpLogo.topMargin=dp(4); nav.addView(logo,lpLogo);

        addNavModern("⌂", "Início", this::showHome, true);
        addNavModern("▣", "TV Ao Vivo", this::showLive, false);
        addNavModern("▤", "Filmes", this::showMovies, false);
        addNavModern("▱", "Séries", this::showSeries, false);
        addNavModern("▦", "Categorias", this::showCategoriesHub, false);
        addNavModern("◉", "Rádio", this::showRadio, false);
        addNavModern("▣", "EPG (Guia)", this::showEpgGuide, false);
        addNavModern("♡", "Favoritos", this::showFavorites, false);
        addNavModern("◉", "Continue Assistindo", this::showContinueWatching, false);
        addNavModern("⌕", "Busca", this::showGlobalSearch, false);
        addNavModern("⚙", "Configurações", this::showSetup, false);
    }

    void toggleNav(){
        // No conteúdo, o menu lateral some por completo e pode ser reaberto pelo botão ☰ do topo.
        setNavHidden(true);
    }

    void setNavHidden(boolean hidden){
        navHidden=hidden;
        if(navScroll!=null) navScroll.setVisibility(hidden?View.GONE:View.VISIBLE);
        if(topMenuButton!=null) topMenuButton.setVisibility(hidden?View.VISIBLE:View.GONE);
    }

    void addNavModern(String icon,String label,Runnable action,boolean selected){
        Button b=new Button(this); b.setAllCaps(false); b.setText(navCollapsed?icon:icon+"   "+label); b.setTextSize(navCollapsed?(compact?14:17):(compact?11:14)); b.setTextColor(selected?GOLD:WHITE); b.setGravity(navCollapsed?Gravity.CENTER:Gravity.LEFT|Gravity.CENTER_VERTICAL);
        b.setPadding(navCollapsed?0:dp(compact?14:18),0,navCollapsed?0:dp(8),0); b.setMinHeight(0); b.setFocusable(true); b.setClickable(true);
        b.setBackground(box(selected?Color.rgb(61,43,13):Color.TRANSPARENT,14,selected?GOLD:Color.rgb(20,22,24),selected?1:0));
        b.setOnClickListener(v->{
            if(label.equals("Início")){ setNavHidden(false); action.run(); }
            else { setNavHidden(true); action.run(); }
        });
        b.setOnFocusChangeListener((v,has)->{ Button x=(Button)v; x.setTextColor(has?GOLD:WHITE); v.setBackground(box(has?Color.rgb(48,35,14):Color.TRANSPARENT,14,has?GOLD:Color.rgb(20,22,24),has?1:0)); });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(navCollapsed?44:(compact?43:51))); lp.bottomMargin=dp(3); nav.addView(b,lp);
    }

    void buildMain(){
        LinearLayout wrap=new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL); root.addView(wrap,new LinearLayout.LayoutParams(0,-1,1));

        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT); top.setPadding(dp(16),dp(8),dp(16),dp(6)); top.setBackgroundColor(Color.rgb(3,5,7));
        topMenuButton=button("☰"); topMenuButton.setTextColor(GOLD); topMenuButton.setTextSize(compact?17:21); topMenuButton.setVisibility(View.GONE); topMenuButton.setOnClickListener(v->setNavHidden(false));
        LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(dp(compact?46:54),dp(compact?42:50)); mlp.rightMargin=dp(8); top.addView(topMenuButton,mlp);
        pageTitle=text("",1); pageTitle.setVisibility(View.GONE); top.addView(pageTitle,new LinearLayout.LayoutParams(0,1,1));

        Button search=new Button(this); search.setAllCaps(false); search.setText("⌕   Buscar..."); search.setTextColor(WHITE); search.setTextSize(compact?10:13); search.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); search.setPadding(dp(15),0,0,0); search.setBackground(box(Color.rgb(7,9,11),13,Color.rgb(104,77,24),1)); search.setOnClickListener(v->showGlobalSearch());
        top.addView(search,new LinearLayout.LayoutParams(dp(compact?230:305),dp(compact?42:50)));

        LinearLayout clock=new LinearLayout(this); clock.setOrientation(LinearLayout.VERTICAL); clock.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); clock.setPadding(dp(18),0,dp(14),0);
        String time=new SimpleDateFormat(prefs.getBoolean("clock_24h",false)?"HH:mm":"h:mm a",Locale.getDefault()).format(new Date());
        String date=new SimpleDateFormat("EEE, dd 'de' MMM",new Locale("pt","BR")).format(new Date());
        TextView tvTime=text(time,compact?15:20); tvTime.setGravity(Gravity.RIGHT); tvTime.setTypeface(null,1); clock.addView(tvTime,new LinearLayout.LayoutParams(-1,dp(compact?23:28)));
        TextView tvDate=text(date,compact?8:11); tvDate.setGravity(Gravity.RIGHT); tvDate.setTextColor(MUTED); clock.addView(tvDate,new LinearLayout.LayoutParams(-1,dp(compact?18:22)));
        top.addView(clock,new LinearLayout.LayoutParams(dp(compact?150:190),dp(compact?48:56)));

        Button profile=new Button(this); profile.setText("●"); profile.setTextColor(Color.LTGRAY); profile.setTextSize(compact?17:22); profile.setBackground(box(Color.rgb(11,12,14),30,GOLD,1)); profile.setOnClickListener(v->showSetup()); top.addView(profile,new LinearLayout.LayoutParams(dp(compact?46:58),dp(compact?46:58)));
        wrap.addView(top,new LinearLayout.LayoutParams(-1,dp(compact?62:72)));

        contentScroll=new ScrollView(this); contentScroll.setFillViewport(true); contentScroll.setVerticalScrollBarEnabled(false);
        // Não deixa o ScrollView externo capturar o foco invisivelmente na TV.
        contentScroll.setFocusable(false); contentScroll.setFocusableInTouchMode(false);
        contentScroll.setDescendantFocusability(android.view.ViewGroup.FOCUS_AFTER_DESCENDANTS);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(compact?12:20),dp(8),dp(compact?12:20),dp(24));
        contentScroll.addView(content); wrap.addView(contentScroll,new LinearLayout.LayoutParams(-1,0,1));
    }

    void clear(String title){
        activeScreen=title==null?"":title;
        pendingFeatured=null;
        releasePreviewPlayer();
        content.removeAllViews(); pageTitle.setText(title); browserList=null; browserRecycler=null; mediaRecycler=null; browserResultCount=null; channelRecyclerAdapter=null; mediaRecyclerAdapter=null; if(contentScroll!=null) contentScroll.post(() -> contentScroll.scrollTo(0,0));
    }

    void releasePreviewPlayer(){
        if(previewPlayerView!=null) previewPlayerView.setPlayer(null);
        if(previewPlayer!=null){ try{previewPlayer.release();}catch(Exception ignored){} }
        previewPlayer=null; previewPlayerView=null; previewEntry=null; liveEpgContainer=null;
    }


    void addTitle(String s,float size){
        TextView t=text(s,compact?Math.max(14,size-2):size); t.setTypeface(null,1); t.setTextColor(WHITE); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(size>22?40:34)); p.topMargin=dp(4); content.addView(t,p);
    }

    void showHome(){ currentSectionRequest=-1; detailScreenKind=-1; restoreKind=-1;
        setNavHidden(false);
        clear("Início");

        LinearLayout first=new LinearLayout(this); first.setOrientation(LinearLayout.HORIZONTAL); first.setGravity(Gravity.CENTER_VERTICAL);
        ImageView hero=new ImageView(this); hero.setImageResource(R.drawable.hero_mock); hero.setScaleType(ImageView.ScaleType.CENTER_CROP); hero.setBackground(box(Color.rgb(10,10,10),14,GOLD,1)); hero.setClickable(true); hero.setFocusable(true); hero.setContentDescription("John Wick 4 — abrir detalhes"); hero.setOnClickListener(v->openFeatured(new FeaturedTitle(MOVIE,"John Wick 4","John Wick: Chapter 4","John Wick 4: Baba Yaga")));
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(0,dp(compact?196:268),1.65f); hp.rightMargin=dp(10); first.addView(hero,hp);

        LinearLayout quick=new LinearLayout(this); quick.setOrientation(LinearLayout.VERTICAL);
        LinearLayout q1=new LinearLayout(this); q1.setOrientation(LinearLayout.HORIZONTAL);
        addHomeQuick(q1,"▣","TV AO VIVO",homeCountSub(LIVE,"CANAIS"),this::showLive);
        addHomeQuick(q1,"◉","FILMES",homeCountSub(MOVIE,"TÍTULOS"),this::showMovies);
        quick.addView(q1,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout q2=new LinearLayout(this); q2.setOrientation(LinearLayout.HORIZONTAL);
        addHomeQuick(q2,"▤","SÉRIES",homeCountSub(SERIES,"SÉRIES"),this::showSeries);
        addHomeQuick(q2,"★","FAVORITOS",PlaybackStore.favoriteCount(this)+" SALVOS",this::showFavorites);
        LinearLayout.LayoutParams q2p=new LinearLayout.LayoutParams(-1,0,1); q2p.topMargin=dp(8); quick.addView(q2,q2p);
        first.addView(quick,new LinearLayout.LayoutParams(0,dp(compact?196:268),1.25f));
        content.addView(first,new LinearLayout.LayoutParams(-1,dp(compact?196:268)));

        List<MediaEntry> cw=PlaybackStore.continueWatching(this,10);
        if(!cw.isEmpty()) addDynamicMediaStrip("Continue Assistindo",cw,this::showContinueWatching,compact?126:168);

        SectionData movieData=cachedSection(MOVIE,true);
        if(movieData!=null&&!movieData.items.isEmpty()) addDynamicMediaStrip("Filmes adicionados recentemente",latestEntries(movieData.items,10),this::showMovies,compact?138:190);
        else addFeaturedStrip("Filmes em Destaque",R.drawable.films_mock,this::showMovies,compact?138:190,new FeaturedTitle[]{
            new FeaturedTitle(MOVIE,"Deadpool & Wolverine","Deadpool e Wolverine","Deadpool and Wolverine"),
            new FeaturedTitle(MOVIE,"Divertida Mente 2","Divertidamente 2","Inside Out 2"),
            new FeaturedTitle(MOVIE,"Bad Boys Até o Fim","Bad Boys: Ride or Die","Bad Boys 4"),
            new FeaturedTitle(MOVIE,"Duna: Parte 2","Duna: Parte Dois","Dune: Part Two","Dune: Part 2"),
            new FeaturedTitle(MOVIE,"Godzilla e Kong: O Novo Império","Godzilla x Kong: The New Empire","Godzilla x Kong: O Novo Império"),
            new FeaturedTitle(MOVIE,"Kung Fu Panda 4"),
            new FeaturedTitle(MOVIE,"Planeta dos Macacos: O Reinado","Kingdom of the Planet of the Apes")
        });

        SectionData seriesData=cachedSection(SERIES,true);
        if(seriesData!=null&&!seriesData.items.isEmpty()) addDynamicMediaStrip("Séries adicionadas recentemente",latestEntries(seriesData.items,10),this::showSeries,compact?126:172);
        else addFeaturedStrip("Séries em Destaque",R.drawable.series_mock,this::showSeries,compact?126:172,new FeaturedTitle[]{
            new FeaturedTitle(SERIES,"The Last of Us"),new FeaturedTitle(SERIES,"Fallout"),
            new FeaturedTitle(SERIES,"House of the Dragon","A Casa do Dragão"),
            new FeaturedTitle(SERIES,"A Casa do Dragão","House of the Dragon"),
            new FeaturedTitle(SERIES,"Reacher"),new FeaturedTitle(SERIES,"The Boys"),
            new FeaturedTitle(SERIES,"Round 6","Squid Game"),new FeaturedTitle(SERIES,"Breaking Bad","Breaking Bad: A Química do Mal")
        });
        addPreviewStrip("Canais Ao Vivo",R.drawable.live_mock,this::showLive,compact?92:112);
    }

    String homeCountSub(int kind,String label){
        SectionData d=cachedSection(kind,true); int count=d==null?-1:d.items.size();
        if(count<0){String key=currentSourceCacheKey(); if(!key.isEmpty())count=CatalogCache.peekCount(this,key,kind);}
        if(count<0)return kind==LIVE?"CANAIS":label;
        return String.format(Locale.US,"%,d %s",count,label);
    }

    List<MediaEntry> latestEntries(List<MediaEntry> source,int limit){
        ArrayList<MediaEntry> out=new ArrayList<>();for(MediaEntry e:source)if(contentAllowed(e))out.add(e);Collections.sort(out,(a,b)->compareAdded(b,a));
        if(out.size()>limit)return new ArrayList<>(out.subList(0,limit)); return out;
    }

    void addDynamicMediaStrip(String title,List<MediaEntry> entries,Runnable all,int height){
        if(entries==null||entries.isEmpty())return;
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t=text(title,compact?14:19);t.setTypeface(null,1);head.addView(t,new LinearLayout.LayoutParams(0,dp(34),1));
        TextView more=text("Ver todos  ›",compact?9:12);more.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);more.setTextColor(Color.LTGRAY);more.setFocusable(true);more.setClickable(true);more.setOnClickListener(v->all.run());head.addView(more,new LinearLayout.LayoutParams(dp(compact?90:120),dp(34)));content.addView(head,new LinearLayout.LayoutParams(-1,dp(36)));
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);hsv.setFocusable(false);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(0,0,dp(8),0);hsv.addView(row,new HorizontalScrollView.LayoutParams(-2,-1));
        int cardW=compact?100:132, posterH=Math.max(90,height-42);
        final ArrayList<MediaEntry> stripItems=new ArrayList<>(entries);
        for(MediaEntry e:entries){LinearLayout card=makePosterCard(e,cardW,posterH);card.setOnClickListener(v->{detailNavItems=new ArrayList<>(stripItems);if(e.kind==LIVE)showLiveDetails(e);else if(e.url!=null&&!e.url.isEmpty()&&e.group!=null&&e.group.toLowerCase(Locale.US).startsWith("temporada")){setPlayerQueue(stripItems,e);play(e);}else showMediaDetails(e);});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(cardW),dp(height));lp.rightMargin=dp(8);row.addView(card,lp);}
        content.addView(hsv,new LinearLayout.LayoutParams(-1,dp(height+4)));
    }

    void addHomeQuick(LinearLayout row,String icon,String title,String sub,Runnable action){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(compact?12:16),dp(7),dp(10),dp(7)); card.setBackground(box(Color.rgb(10,11,12),14,Color.rgb(93,69,22),1)); card.setClickable(true); card.setFocusable(true); card.setOnClickListener(v->action.run());
        TextView ic=text(icon,compact?23:31); ic.setTextColor(GOLD); ic.setGravity(Gravity.CENTER); card.addView(ic,new LinearLayout.LayoutParams(dp(compact?48:64),-1));
        LinearLayout labels=new LinearLayout(this); labels.setOrientation(LinearLayout.VERTICAL); labels.setGravity(Gravity.CENTER_VERTICAL);
        TextView h=text(title,compact?11:16); h.setTypeface(null,1); labels.addView(h,new LinearLayout.LayoutParams(-1,dp(compact?25:32)));
        TextView s=text(sub,compact?8:11); s.setTextColor(WHITE); labels.addView(s,new LinearLayout.LayoutParams(-1,dp(compact?20:24)));
        card.addView(labels,new LinearLayout.LayoutParams(0,-1,1));
        card.setOnFocusChangeListener((v,has)->v.setBackground(box(has?Color.rgb(38,29,13):Color.rgb(10,11,12),14,has?GOLD:Color.rgb(93,69,22),1)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); p.leftMargin=dp(4); p.rightMargin=dp(4); row.addView(card,p);
    }

    void addPreviewStrip(String title,int drawable,Runnable action,int h){
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL); TextView t=text(title,compact?14:19); t.setTypeface(null,1); head.addView(t,new LinearLayout.LayoutParams(0,dp(34),1)); TextView more=text("Ver todos  ›",compact?9:12); more.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); more.setTextColor(Color.LTGRAY); head.addView(more,new LinearLayout.LayoutParams(dp(compact?90:120),dp(34))); content.addView(head,new LinearLayout.LayoutParams(-1,dp(36)));
        ImageView strip=new ImageView(this); strip.setImageResource(drawable); strip.setScaleType(ImageView.ScaleType.CENTER_CROP); strip.setBackground(box(Color.rgb(8,8,9),10,Color.rgb(70,52,18),1)); strip.setClickable(true); strip.setFocusable(true); strip.setOnClickListener(v->action.run()); content.addView(strip,new LinearLayout.LayoutParams(-1,dp(h)));
        more.setFocusable(true); more.setOnClickListener(v->action.run());
    }

    static class FeaturedTitle {
        final int kind;
        final String title;
        final String[] aliases;
        final Set<String> normalizedAliases=new LinkedHashSet<>();
        FeaturedTitle(int kind,String title,String... otherNames){
            this.kind=kind; this.title=title;
            aliases=new String[otherNames.length+1]; aliases[0]=title;
            System.arraycopy(otherNames,0,aliases,1,otherNames.length);
            for(String alias:aliases)normalizedAliases.add(FeaturedMatcher.normalize(alias));
        }
    }

    void addFeaturedStrip(String title,int drawable,Runnable all,int height,FeaturedTitle[] titles){
        // Preserve the original artwork and its CENTER_CROP geometry. Only add individual hit targets.
        addPreviewStrip(title,drawable,all,height);
        View original=content.getChildAt(content.getChildCount()-1);
        content.removeView(original);
        original.setClickable(false); original.setFocusable(false);
        BitmapFactory.Options bounds=new BitmapFactory.Options(); bounds.inJustDecodeBounds=true;
        BitmapFactory.decodeResource(getResources(),drawable,bounds);
        FrameLayout strip=new FrameLayout(this){
            @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){
                super.onSizeChanged(w,h,oldw,oldh);
                float scale=Math.max((float)w/bounds.outWidth,(float)h/bounds.outHeight);
                float scaledWidth=bounds.outWidth*scale, offset=Math.round((w-scaledWidth)/2f);
                for(int i=0;i<titles.length;i++){
                    int left=Math.max(0,Math.round(offset+scaledWidth*i/titles.length));
                    int right=Math.min(w,Math.round(offset+scaledWidth*(i+1)/titles.length));
                    View target=getChildAt(i+1);
                    FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Math.max(0,right-left),h);
                    lp.leftMargin=left; target.setLayoutParams(lp);
                    target.setVisibility(right>left?View.VISIBLE:View.GONE);
                }
            }
        };
        strip.addView(original,new FrameLayout.LayoutParams(-1,-1));
        for(FeaturedTitle item:titles){
            View target=new View(this); target.setFocusable(true); target.setClickable(true);
            target.setContentDescription(item.title+" — abrir detalhes");
            target.setOnClickListener(v->openFeatured(item));
            target.setOnFocusChangeListener((v,has)->v.setBackground(has?box(Color.TRANSPARENT,10,GOLD,2):null));
            strip.addView(target,new FrameLayout.LayoutParams(0,-1));
        }
        content.addView(strip,new LinearLayout.LayoutParams(-1,dp(height)));
    }

    void openFeatured(FeaturedTitle title){
        currentSectionRequest=-1;
        String mode=resolveSourceMode();
        if(mode.isEmpty()){ showMissingSource(title.title); return; }
        SectionData data=cachedSection(title.kind,true);
        if(data!=null){ showFeaturedMatch(title,data); return; }
        clear(title.title); setNavHidden(true);
        TextView loading=text("Localizando "+title.title+" na sua playlist…",15);
        loading.setGravity(Gravity.CENTER); loading.setTextColor(MUTED);
        content.addView(loading,new LinearLayout.LayoutParams(-1,dp(110)));
        pendingFeatured=title;
        // Reuse any catalog request already started by background prewarming.
        fetchSectionAsync(title.kind,mode,false);
    }

    void showFeaturedMatch(FeaturedTitle title,SectionData data){
        clear(title.title); setNavHidden(true);
        TextView loading=text("Localizando "+title.title+" na sua playlist…",15);
        loading.setGravity(Gravity.CENTER); loading.setTextColor(MUTED);
        content.addView(loading,new LinearLayout.LayoutParams(-1,dp(110)));
        dataExec.submit(()->{
            ArrayList<MediaEntry> matches=new ArrayList<>();
            for(MediaEntry e:data.items){
                if(e.kind==title.kind && title.normalizedAliases.contains(FeaturedMatcher.normalize(e.name)))matches.add(e);
            }
            runOnUiThread(()->{
                if(loading.getParent()==content && data.sourceKey.equals(currentSourceCacheKey()))renderFeaturedMatches(title,data,matches);
            });
        });
    }

    void renderFeaturedMatches(FeaturedTitle title,SectionData data,List<MediaEntry> matches){
        if(matches.size()==1){
            detailNavItems=new ArrayList<>(data.items);
            showMediaDetails(matches.get(0)); return;
        }
        clear(title.title); setNavHidden(true); addTitle(title.title,24);
        TextView message=text(matches.isEmpty()?"Este título não foi encontrado na sua playlist.":"Escolha a versão disponível na sua playlist:",compact?12:15);
        message.setTextColor(MUTED); content.addView(message,new LinearLayout.LayoutParams(-1,dp(64)));
        for(MediaEntry e:matches){
            Button option=button(e.name+(e.group==null||e.group.isEmpty()?"":" • "+e.group));
            option.setOnClickListener(v->{detailNavItems=new ArrayList<>(data.items);showMediaDetails(e);});
            content.addView(option,new LinearLayout.LayoutParams(-1,dp(54)));
        }
        Button back=button("←  VOLTAR AO INÍCIO"); back.setOnClickListener(v->showHome());
        content.addView(back,new LinearLayout.LayoutParams(-1,dp(52)));
    }

    void showGlobalSearch(){ currentSectionRequest=-1;
        setNavHidden(true); clear("Busca"); addTitle("Busca global",24);
        TextView sub=text("Pesquise uma vez e encontre canais, filmes e séries juntos.",compact?10:13);sub.setTextColor(MUTED);content.addView(sub,new LinearLayout.LayoutParams(-1,dp(36)));
        EditText search=field("⌕  Digite canal, filme ou série…","");content.addView(search,new LinearLayout.LayoutParams(-1,dp(52)));
        LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(10);content.addView(results,rp);
        final Runnable[] pending={null};
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void afterTextChanged(Editable e){} public void onTextChanged(CharSequence cs,int st,int b,int c){
            if(pending[0]!=null)uiHandler.removeCallbacks(pending[0]); String q=cs.toString().trim();
            pending[0]=()->runGlobalSearch(q,results); uiHandler.postDelayed(pending[0],280);
        }});
        TextView hint=text("Digite pelo menos 2 letras.",compact?11:14);hint.setTextColor(MUTED);hint.setGravity(Gravity.CENTER);results.addView(hint,new LinearLayout.LayoutParams(-1,dp(90)));
        search.postDelayed(search::requestFocus,180);
    }

    void runGlobalSearch(String query,LinearLayout results){
        results.removeAllViews(); if(query==null||query.trim().length()<2){TextView h=text("Digite pelo menos 2 letras.",compact?11:14);h.setTextColor(MUTED);h.setGravity(Gravity.CENTER);results.addView(h,new LinearLayout.LayoutParams(-1,dp(90)));return;}
        TextView loading=text("Buscando em TV, Filmes e Séries…",compact?11:14);loading.setTextColor(MUTED);loading.setGravity(Gravity.CENTER);results.addView(loading,new LinearLayout.LayoutParams(-1,dp(80)));
        final String q=query.toLowerCase(Locale.US);
        dataExec.submit(()->{
            ArrayList<MediaEntry> matches=new ArrayList<>(); LinkedHashMap<Integer,SectionData> sourceByKind=new LinkedHashMap<>();
            try{
                for(int kind=LIVE;kind<=SERIES;kind++){
                    SectionData d=ensureSectionSync(kind); if(d==null)continue; sourceByKind.put(kind,d);
                    for(MediaEntry e:d.items){if(e!=null&&contentAllowed(e)&&e.name!=null&&e.name.toLowerCase(Locale.US).contains(q)){matches.add(e);if(matches.size()>=80)break;}}
                    if(matches.size()>=80)break;
                }
            }catch(Exception ignored){}
            runOnUiThread(()->{
                results.removeAllViews(); if(matches.isEmpty()){TextView none=text("Nenhum resultado encontrado.",compact?11:14);none.setTextColor(MUTED);none.setGravity(Gravity.CENTER);results.addView(none,new LinearLayout.LayoutParams(-1,dp(90)));return;}
                TextView count=text(matches.size()+" resultado(s)",compact?10:12);count.setTextColor(MUTED);results.addView(count,new LinearLayout.LayoutParams(-1,dp(34)));
                for(MediaEntry e:matches){String type=e.kind==LIVE?"TV":e.kind==MOVIE?"FILME":"SÉRIE";Button b=button(type+"  •  "+e.name);b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setPadding(dp(15),0,dp(10),0);b.setOnClickListener(v->{SectionData d=sourceByKind.get(e.kind);detailNavItems=d==null?new ArrayList<>():new ArrayList<>(d.items);if(e.kind==LIVE)showLiveDetails(e);else showMediaDetails(e);});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.bottomMargin=dp(5);results.addView(b,lp);}
            });
        });
    }

    SectionData ensureSectionSync(int kind) throws Exception{
        SectionData d=cachedSection(kind,true); if(d!=null)return d; String mode=resolveSourceMode(); if(mode.isEmpty())return null; String sourceKey=currentSourceCacheKey();
        CatalogCache.CachedCatalog disk=CatalogCache.load(this,sourceKey,kind); if(disk!=null&&!disk.items.isEmpty()){d=new SectionData(disk.items,disk.categories,disk.loadedAt,sourceKey);storeSection(kind,d);return d;}
        d=fetchSectionData(kind,mode,sourceKey);storeSection(kind,d);saveCatalogAsync(kind,d);return d;
    }

    void showFavorites(){ currentSectionRequest=-1; setNavHidden(true); clear("Favoritos"); addTitle("Favoritos",24); List<MediaEntry> all=PlaybackStore.favorites(this); showStoredEntries("Seus favoritos",all); }
    void showContinueWatching(){ currentSectionRequest=-1; setNavHidden(true); clear("Continue Assistindo"); addTitle("Continue Assistindo",24); showStoredEntries("Retome de onde parou",PlaybackStore.continueWatching(this,100)); }

    void showStoredEntries(String subtitle,List<MediaEntry> entries){
        TextView sub=text(subtitle,compact?10:13);sub.setTextColor(MUTED);content.addView(sub,new LinearLayout.LayoutParams(-1,dp(36)));
        if(entries==null||entries.isEmpty()){TextView none=text("Ainda não há itens aqui.",compact?12:15);none.setTextColor(MUTED);none.setGravity(Gravity.CENTER);content.addView(none,new LinearLayout.LayoutParams(-1,dp(110)));return;}
        final ArrayList<MediaEntry> navItems=new ArrayList<>(entries);
        for(MediaEntry e:entries){
            Button b=button((e.kind==LIVE?"▣  ":e.kind==MOVIE?"▤  ":"▱  ")+(e.name==null?"Conteúdo":e.name));b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setPadding(dp(15),0,dp(10),0);
            b.setOnClickListener(v->{detailNavItems=new ArrayList<>(navItems);if(e.kind==LIVE)showLiveDetails(e);else if(e.url!=null&&!e.url.isEmpty()&&e.group!=null&&e.group.toLowerCase(Locale.US).startsWith("temporada")){setPlayerQueue(navItems,e);play(e);}else showMediaDetails(e);});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.bottomMargin=dp(5);content.addView(b,lp);
        }
    }

    void showRadio(){ currentSectionRequest=-1; setNavHidden(true); clear("Rádio"); addTitle("Rádio",24); TextView loading=text("Localizando estações na sua playlist…",compact?11:14);loading.setTextColor(MUTED);loading.setGravity(Gravity.CENTER);content.addView(loading,new LinearLayout.LayoutParams(-1,dp(90)));
        dataExec.submit(()->{ArrayList<MediaEntry> radios=new ArrayList<>();try{SectionData d=ensureSectionSync(LIVE);if(d!=null)for(MediaEntry e:d.items){String z=((e.group==null?"":e.group)+" "+(e.name==null?"":e.name)).toLowerCase(Locale.US);if(z.contains("radio")||z.contains("rádio")||z.contains("fm ")||z.endsWith(" fm"))radios.add(e);}}catch(Exception ignored){}runOnUiThread(()->{clear("Rádio");addTitle("Rádio",24);if(radios.isEmpty()){TextView none=text("Nenhuma estação de rádio foi identificada na sua playlist.",compact?11:14);none.setTextColor(MUTED);none.setGravity(Gravity.CENTER);content.addView(none,new LinearLayout.LayoutParams(-1,dp(100)));}else showBrowser("Rádio",radios,LIVE);});});
    }

    void showEpgGuide(){ currentSectionRequest=-1; setNavHidden(true); clear("EPG (Guia)"); addTitle("EPG (Guia)",24); TextView sub=text("Selecione um canal para abrir a programação atual e os próximos programas.",compact?10:13);sub.setTextColor(MUTED);content.addView(sub,new LinearLayout.LayoutParams(-1,dp(38))); TextView loading=text("Carregando canais…",compact?11:14);loading.setTextColor(MUTED);loading.setGravity(Gravity.CENTER);content.addView(loading,new LinearLayout.LayoutParams(-1,dp(80)));
        dataExec.submit(()->{SectionData d=null;try{d=ensureSectionSync(LIVE);}catch(Exception ignored){}final SectionData data=d;runOnUiThread(()->{if(data==null){showInfo("Não foi possível carregar o guia agora.");return;}clear("EPG (Guia)");addTitle("EPG (Guia)",24);EditText search=field("⌕  Buscar canal…","");content.addView(search,new LinearLayout.LayoutParams(-1,dp(48)));LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list,new LinearLayout.LayoutParams(-1,-2));Runnable render=()->{list.removeAllViews();String q=search.getText().toString().trim().toLowerCase(Locale.US);int shown=0;for(MediaEntry e:data.items){if(e.name==null||(!q.isEmpty()&&!e.name.toLowerCase(Locale.US).contains(q)))continue;Button b=button("▣  "+e.name+"   •   "+(e.group==null?"":e.group));b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setOnClickListener(v->{detailNavItems=new ArrayList<>(data.items);showLiveDetails(e);});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.bottomMargin=dp(4);list.addView(b,lp);if(++shown>=120)break;}};search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void afterTextChanged(Editable e){}public void onTextChanged(CharSequence s,int st,int b,int c){render.run();}});render.run();});});
    }

    void showCategoriesHub(){ currentSectionRequest=-1;
        clear("Categorias"); addTitle("Escolha o tipo de conteúdo",22); Button live=button("▣ TV AO VIVO — escolher categoria e canal"); live.setOnClickListener(v->showLive()); content.addView(live,new LinearLayout.LayoutParams(-1,dp(56)));
        Button mov=button("▤ FILMES — escolher categoria e filme"); mov.setOnClickListener(v->showMovies()); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(56)); p.topMargin=dp(8); content.addView(mov,p);
        Button ser=button("● SÉRIES — escolher categoria, série e episódio"); ser.setOnClickListener(v->showSeries()); LinearLayout.LayoutParams p2=new LinearLayout.LayoutParams(-1,dp(56)); p2.topMargin=dp(8); content.addView(ser,p2);
    }

    void showSetup(){ currentSectionRequest=-1;
        setNavHidden(true); clear("Configurações"); addTitle("Configurações",24);
        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        addSettingsRow(grid,"▣","Adicionar / Trocar Playlist",this::showPlaylistManager,"◫","Chave do Dispositivo",this::showDeviceCode);
        addSettingsRow(grid,"↻","Atualizar Catálogos",this::refreshCatalogs,"⌫","Limpar Cache",this::clearAppCache);
        addSettingsRow(grid,"◉","Ocultar conteúdo adulto: "+onOff(prefs.getBoolean("hide_adult",false)),()->toggleBooleanSetting("hide_adult"),"▶","Autoplay TV: "+onOff(prefs.getBoolean("autoplay_live",true)),()->toggleBooleanSetting("autoplay_live"));
        addSettingsRow(grid,"◷","Retomar filmes/séries: "+onOff(prefs.getBoolean("resume_vod",true)),()->toggleBooleanSetting("resume_vod"),"◷","Relógio 24h: "+onOff(prefs.getBoolean("clock_24h",false)),()->toggleBooleanSetting("clock_24h"));
        addSettingsRow(grid,"⌫","Limpar histórico de TV",()->clearHistoryKind(LIVE),"⌫","Limpar histórico de Filmes",()->clearHistoryKind(MOVIE));
        addSettingsRow(grid,"⌫","Limpar histórico de Séries",()->clearHistoryKind(SERIES),"⌫","Limpar todo histórico",()->{PlaybackStore.clearAllHistory(this);showInfo("Histórico e pontos de reprodução removidos.");});
        addSettingsRow(grid,"▣","Abrir Guia EPG",this::showEpgGuide,"♡","Abrir Favoritos",this::showFavorites);
        content.addView(grid,new LinearLayout.LayoutParams(-1,-2));
        TextView dev=text("ÁUREON • Device Key: "+DeviceKeyUtil.key(this)+" • v32.0",compact?10:13);dev.setTextColor(MUTED);dev.setGravity(Gravity.CENTER);LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(42));mp.topMargin=dp(8);content.addView(dev,mp);
    }

    void addSettingsRow(LinearLayout grid,String i1,String l1,Runnable a1,String i2,String l2,Runnable a2){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);addSettingsTile(row,i1,l1,a1);addSettingsTile(row,i2,l2,a2);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(compact?64:76));rp.bottomMargin=dp(8);grid.addView(row,rp);
    }
    String onOff(boolean v){return v?"Ligado":"Desligado";}
    void toggleBooleanSetting(String key){prefs.edit().putBoolean(key,!prefs.getBoolean(key,false)).apply();showSetup();}
    void clearHistoryKind(int kind){PlaybackStore.clearRecents(this,kind);showInfo("Histórico limpo.");}
    void refreshCatalogs(){invalidateSectionCaches();CatalogCache.clear(this);detailCache.clear();epgCache.clear();String mode=resolveSourceMode();if(!mode.isEmpty())prewarmAllSections();showInfo("Atualização iniciada em segundo plano.");}

    void clearAppCache(){
        playlistCache.clear();
        invalidateSectionCaches();
        imageCache.evictAll();
        clearImageDiskCache();
        CatalogCache.clear(this);
        showInfo("Cache limpo. As listas serão atualizadas na próxima abertura; favoritos e Continue Assistindo foram preservados.");
    }

    void addSettingsTile(LinearLayout row,String icon,String label,Runnable action){
        Button b=button(icon+"   "+label); b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); b.setPadding(dp(16),0,dp(10),0); b.setOnClickListener(v->action.run());
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1); lp.leftMargin=dp(4); lp.rightMargin=dp(4); row.addView(b,lp);
    }

    void showPlaylistManager(){ currentSectionRequest=-1;
        clear("Adicionar Playlist"); addTitle("Adicionar Playlist",24);
        LinearLayout tabs=new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL); Button xt=button("XTREAM CODES API"); Button m3uTab=button("ADD M3U URL"); xt.setTextColor(GOLD); tabs.addView(xt,new LinearLayout.LayoutParams(0,dp(48),1)); tabs.addView(m3uTab,new LinearLayout.LayoutParams(0,dp(48),1)); content.addView(tabs,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView device=text("DEVICE KEY   "+DeviceKeyUtil.key(this),compact?10:13); device.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); device.setTextColor(MUTED); content.addView(device,new LinearLayout.LayoutParams(-1,dp(36)));
        final String[] mode={prefs.getString("source_mode","xtream").equals("xtream")?"xtream":"m3u"};
        EditText name=field("Nome da Playlist",prefs.getString("playlist_name","ÁUREON")); content.addView(name,new LinearLayout.LayoutParams(-1,dp(50)));
        EditText url=field("URL do servidor / M3U",prefs.getString("url_input",prefs.getString("xt_server",""))); content.addView(url,new LinearLayout.LayoutParams(-1,dp(50)));
        EditText user=field("Usuário Xtream",CredentialStore.user(prefs)); content.addView(user,new LinearLayout.LayoutParams(-1,dp(50)));
        EditText pass=field("Senha Xtream",CredentialStore.pass(prefs)); pass.setInputType(129); content.addView(pass,new LinearLayout.LayoutParams(-1,dp(50)));
        EditText epg=field("URL EPG XMLTV (opcional)",prefs.getString("epg","")); content.addView(epg,new LinearLayout.LayoutParams(-1,dp(50)));
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); Button cancel=button("Cancelar"); Button go=button("Adicionar & Conectar"); go.setTextColor(GOLD); actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1)); LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(0,dp(52),1); gp.leftMargin=dp(8); actions.addView(go,gp); content.addView(actions,new LinearLayout.LayoutParams(-1,dp(58)));
        status=text("",compact?10:13); status.setTextColor(MUTED); content.addView(status,new LinearLayout.LayoutParams(-1,dp(40)));
        Runnable repaint=()->{xt.setTextColor(mode[0].equals("xtream")?GOLD:WHITE);m3uTab.setTextColor(mode[0].equals("m3u")?GOLD:WHITE);};
        xt.setOnClickListener(v->{mode[0]="xtream";repaint.run();}); m3uTab.setOnClickListener(v->{mode[0]="m3u";repaint.run();}); repaint.run(); cancel.setOnClickListener(v->showSetup());
        go.setOnClickListener(v->{prefs.edit().putString("playlist_name",name.getText().toString()).apply();connect(mode[0],url,user,pass,epg,status,go);});
    }

    void showDeviceCode(){ currentSectionRequest=-1;
        clear("QR Code / Dispositivo"); addTitle("QR Code / Dispositivo",24);
        String deviceKey=DeviceKeyUtil.key(this);
        TextView key=text("Device Key\n"+deviceKey,compact?20:28); key.setTypeface(null,1); key.setGravity(Gravity.CENTER); key.setBackground(box(Color.rgb(14,15,18),14,Color.rgb(70,70,74),1)); content.addView(key,new LinearLayout.LayoutParams(-1,dp(compact?90:110)));
        ImageView qr=new ImageView(this); qr.setScaleType(ImageView.ScaleType.FIT_CENTER); qr.setPadding(dp(12),dp(12),dp(12),dp(12)); qr.setBackground(box(Color.WHITE,12,Color.WHITE,1));
        Bitmap qrBitmap=makeQrBitmap("AUREON-DEVICE:"+deviceKey,compact?420:560); if(qrBitmap!=null)qr.setImageBitmap(qrBitmap); else qr.setImageResource(R.drawable.aureon_logo);
        LinearLayout.LayoutParams qlp=new LinearLayout.LayoutParams(dp(compact?220:300),dp(compact?220:300)); qlp.gravity=Gravity.CENTER_HORIZONTAL; qlp.topMargin=dp(18); content.addView(qr,qlp);
        TextView hint=text("QR da chave deste aparelho. O app não envia suas credenciais para terceiros.",compact?11:15); hint.setGravity(Gravity.CENTER); hint.setTextColor(MUTED); content.addView(hint,new LinearLayout.LayoutParams(-1,dp(60)));
    }

    Bitmap makeQrBitmap(String value,int size){
        try{
            BitMatrix bits=new MultiFormatWriter().encode(value,BarcodeFormat.QR_CODE,size,size);
            Bitmap b=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);
            for(int y=0;y<size;y++)for(int x=0;x<size;x++)b.setPixel(x,y,bits.get(x,y)?Color.BLACK:Color.WHITE);
            return b;
        }catch(Exception e){return null;}
    }

    EditText field(String hint,String value){ EditText e=new EditText(this); e.setHint(hint); e.setHintTextColor(Color.rgb(115,115,120)); e.setTextColor(WHITE); e.setText(value); e.setSingleLine(true); e.setPadding(dp(12),0,dp(12),0); e.setBackground(box(Color.rgb(20,20,22),13,Color.rgb(70,70,72),1)); return e; }

    void connect(String mode,EditText url,EditText user,EditText pass,EditText epg,TextView st,Button go){
        String u=url.getText().toString().trim(), us=user.getText().toString().trim(), pw=pass.getText().toString().trim();
        if(mode.equals("file")&&selectedM3u==null){st.setText("Escolha um arquivo M3U/M3U8.");return;}
        if(mode.equals("m3u")&&u.isEmpty()){st.setText("Informe a URL M3U/M3U8.");return;}
        if(mode.equals("xtream")&&(u.isEmpty()||us.isEmpty()||pw.isEmpty())){st.setText("Preencha servidor, usuário e senha Xtream.");return;}
        go.setEnabled(false); st.setText("Testando e carregando…");
        prefs.edit().putString("epg",epg.getText().toString().trim()).putString("url_input",u).apply();
        exec.submit(()->{
            try{
                if(mode.equals("xtream")){
                    String server=normalizeServer(u); XtreamCreds x=new XtreamCreds(server,us,pw); verifyXtream(x);
                    prefs.edit().putString("source_mode","xtream").putString("xt_server",server).putString("url","").putString("file_uri","").apply(); CredentialStore.save(prefs,us,pw); selectedM3u=null; playlistCache.clear(); invalidateSectionCaches();
                }else if(mode.equals("file")){
                    List<MediaEntry> items=loadFromUri(selectedM3u); playlistCache=new ArrayList<>(items); prefs.edit().putString("source_mode","file").putString("url","").putString("xt_server","").apply(); CredentialStore.clear(prefs); invalidateSectionCaches();
                }else{
                    // Se a URL M3U for um link Xtream get.php, tente usar a API nativa do provedor.
                    // Isso separa TV ao vivo, filmes e séries de forma confiável.
                    XtreamCreds detected=xtreamFromM3uUrl(u);
                    boolean usedXtream=false;
                    if(detected!=null && detected.valid()){
                        try{
                            verifyXtream(detected);
                            prefs.edit().putString("source_mode","xtream").putString("xt_server",detected.server).putString("url","").putString("file_uri","").apply(); CredentialStore.save(prefs,detected.user,detected.pass);
                            selectedM3u=null; playlistCache.clear(); invalidateSectionCaches(); usedXtream=true;
                        }catch(Exception ignored){
                            // Se player_api.php não estiver disponível, cai para a M3U normal.
                        }
                    }
                    if(!usedXtream){
                        List<MediaEntry> items=loadFromUrl(u); playlistCache=new ArrayList<>(items); prefs.edit().putString("source_mode","m3u").putString("url",u).putString("file_uri","").putString("xt_server","").apply(); CredentialStore.clear(prefs); selectedM3u=null; invalidateSectionCaches();
                    }
                }
                runOnUiThread(()->{go.setEnabled(true);st.setText("Conectado com sucesso.");showLive();});
            }catch(Exception e){ runOnUiThread(()->{go.setEnabled(true);st.setText("Falha: "+friendlyError(e));}); }
        });
    }

    String friendlyError(Exception e){ String m=e.getMessage(); if(m==null||m.trim().isEmpty())return "não foi possível conectar."; if(m.length()>120)m=m.substring(0,120); return m; }

    String normalizeServer(String s) throws Exception{
        String v=s.trim(); if(!v.startsWith("http://")&&!v.startsWith("https://"))v="http://"+v; URL u=new URL(v); String path=u.getPath()==null?"":u.getPath();
        if(path.endsWith("/get.php")||path.endsWith("/player_api.php"))path=path.substring(0,path.lastIndexOf('/')); else if(path.equals("/"))path=""; else if(path.endsWith("/"))path=path.substring(0,path.length()-1);
        int port=u.getPort(); return u.getProtocol()+"://"+u.getHost()+(port>0?":"+port:"")+path;
    }

    XtreamCreds savedXtream(){ return new XtreamCreds(prefs.getString("xt_server",""),CredentialStore.user(prefs),CredentialStore.pass(prefs)); }

    XtreamCreds xtreamFromM3uUrl(String raw){
        try{
            if(raw==null||raw.trim().isEmpty())return null;
            Uri u=Uri.parse(raw.trim());
            String us=u.getQueryParameter("username"), pw=u.getQueryParameter("password");
            String path=u.getPath()==null?"":u.getPath().toLowerCase(Locale.US);
            if(us==null||pw==null||us.isEmpty()||pw.isEmpty()||!path.endsWith("get.php"))return null;
            return new XtreamCreds(normalizeServer(raw),us,pw);
        }catch(Exception e){ return null; }
    }
    String enc(String s) throws Exception{return URLEncoder.encode(s,"UTF-8");}
    String api(XtreamCreds x,String action) throws Exception{ return x.server+"/player_api.php?username="+enc(x.user)+"&password="+enc(x.pass)+(action==null||action.isEmpty()?"":"&action="+action); }

    void verifyXtream(XtreamCreds x) throws Exception{
        JSONObject o=new JSONObject(httpText(api(x,""))); JSONObject user=o.optJSONObject("user_info"); if(user==null)throw new IOException("servidor Xtream não respondeu corretamente"); String auth=user.optString("auth","1"); if(auth.equals("0"))throw new IOException("usuário ou senha inválidos");
    }

    void showLive(){ setNavHidden(true); loadSection(LIVE); }
    void showMovies(){ setNavHidden(true); loadSection(MOVIE); }
    void showSeries(){ setNavHidden(true); loadSection(SERIES); }

    String categoryAction(int kind){ return kind==LIVE?"get_live_categories":kind==MOVIE?"get_vod_categories":"get_series_categories"; }

    String sectionTitle(int kind){ return kind==LIVE?"TV Ao Vivo":kind==MOVIE?"Filmes":"Séries"; }

    String currentSourceCacheKey(){
        String mode=resolveSourceMode();
        if(mode.equals("xtream")){
            XtreamCreds x=savedXtream();
            return "xtream|"+x.server+"|"+x.user+"|"+Integer.toHexString((x.pass==null?"":x.pass).hashCode());
        }
        if(mode.equals("file"))return "file|"+prefs.getString("file_uri","");
        if(mode.equals("m3u"))return "m3u|"+prefs.getString("url",prefs.getString("url_input",""));
        return "";
    }

    void invalidateSectionCaches(){
        synchronized(sectionCacheLock){ sectionCache.clear(); sectionLoading.clear(); }
    }

    SectionData cachedSection(int kind,boolean allowStale){
        String key=currentSourceCacheKey();
        synchronized(sectionCacheLock){
            SectionData d=sectionCache.get(kind);
            if(d==null||key.isEmpty()||!key.equals(d.sourceKey))return null;
            if(!allowStale && System.currentTimeMillis()-d.loadedAt>SECTION_CACHE_TTL_MS)return null;
            return d;
        }
    }

    void storeSection(int kind,SectionData d){
        synchronized(sectionCacheLock){ sectionCache.put(kind,d); }
    }

    boolean sectionIsLoading(int kind){ synchronized(sectionCacheLock){ return sectionLoading.contains(kind); } }

    boolean markSectionLoading(int kind){
        synchronized(sectionCacheLock){
            if(sectionLoading.contains(kind))return false;
            sectionLoading.add(kind); return true;
        }
    }

    void unmarkSectionLoading(int kind){ synchronized(sectionCacheLock){ sectionLoading.remove(kind); } }

    void prewarmAllSections(){
        String mode=resolveSourceMode();
        if(mode.isEmpty())return;
        for(int kind=LIVE;kind<=SERIES;kind++){
            if(cachedSection(kind,false)==null)fetchSectionAsync(kind,mode,false);
        }
    }

    void prewarmOtherSections(int exceptKind){
        String mode=resolveSourceMode();
        if(mode.isEmpty())return;
        for(int kind=LIVE;kind<=SERIES;kind++){
            if(kind!=exceptKind && cachedSection(kind,false)==null)fetchSectionAsync(kind,mode,false);
        }
    }

    void renderSectionData(int kind,SectionData d){
        String title=sectionTitle(kind);
        ArrayList<MediaEntry> visible=new ArrayList<>(); for(MediaEntry e:d.items)if(contentAllowed(e))visible.add(e);
        browserCategoryOrder=new ArrayList<>(); for(String c:d.categories)if(!prefs.getBoolean("hide_adult",false)||!adultText(c))browserCategoryOrder.add(c);
        if(kind==LIVE)showBrowser(title,visible,kind); else showLibrary(title,visible,kind);
    }

    boolean adultText(String s){String z=s==null?"":s.toLowerCase(Locale.US);return z.contains("xxx")||z.contains("adult")||z.contains("18+")||z.contains("porn");}
    boolean contentAllowed(MediaEntry e){return !prefs.getBoolean("hide_adult",false)||!(adultText(e==null?"":e.group)||adultText(e==null?"":e.name));}

    void loadSection(int kind){
        String title=sectionTitle(kind);
        currentSectionRequest=kind;
        String mode=resolveSourceMode();
        if(mode.isEmpty()){ showMissingSource(title); return; }

        // Cache-first: se já carregou esta aba, abre na hora.
        SectionData cached=cachedSection(kind,true);
        if(cached!=null){
            renderSectionData(kind,cached);
            // Depois de 1 hora mantém o conteúdo na tela e atualiza silenciosamente.
            if(System.currentTimeMillis()-cached.loadedAt>SECTION_CACHE_TTL_MS)fetchSectionAsync(kind,mode,false);
            return;
        }

        clear(title);
        TextView loading=text(sectionIsLoading(kind)?"Preparando "+title.toLowerCase(Locale.US)+"…":"Carregando "+title.toLowerCase(Locale.US)+"…",15);
        loading.setTextColor(MUTED); loading.setGravity(Gravity.CENTER);
        content.addView(loading,new LinearLayout.LayoutParams(-1,dp(120)));
        fetchSectionAsync(kind,mode,true);
    }

    void fetchSectionAsync(int kind,String mode,boolean foregroundRequest){
        if(!markSectionLoading(kind))return;
        final String sourceKey=currentSourceCacheKey();
        dataExec.submit(()->{
            try{
                // Persistent cache first: after reopening the app, the last working catalog appears before the network refresh.
                SectionData memory=cachedSection(kind,true);
                if(memory==null){
                    CatalogCache.CachedCatalog disk=CatalogCache.load(this,sourceKey,kind);
                    if(disk!=null&&!disk.items.isEmpty()&&sourceKey.equals(currentSourceCacheKey())){
                        SectionData diskData=new SectionData(disk.items,disk.categories,disk.loadedAt,sourceKey);
                        storeSection(kind,diskData);
                        runOnUiThread(()->{
                            if(pendingFeatured!=null&&pendingFeatured.kind==kind){FeaturedTitle f=pendingFeatured;pendingFeatured=null;showFeaturedMatch(f,diskData);}
                            else if(currentSectionRequest==kind)renderSectionData(kind,diskData);
                        });
                        if(System.currentTimeMillis()-disk.loadedAt<=SECTION_CACHE_TTL_MS){
                            if(foregroundRequest)runOnUiThread(()->uiHandler.postDelayed(()->prewarmOtherSections(kind),700));
                            return;
                        }
                    }
                }

                SectionData data=fetchSectionData(kind,mode,sourceKey);
                if(!sourceKey.equals(currentSourceCacheKey()))return;
                storeSection(kind,data);
                saveCatalogAsync(kind,data);
                runOnUiThread(()->{
                    if(pendingFeatured!=null && pendingFeatured.kind==kind && sourceKey.equals(currentSourceCacheKey())){
                        FeaturedTitle selected=pendingFeatured; pendingFeatured=null; showFeaturedMatch(selected,data);
                    }else if(currentSectionRequest==kind && sourceKey.equals(currentSourceCacheKey())){
                        renderSectionData(kind,data);
                    }
                });
                if(foregroundRequest)runOnUiThread(()->uiHandler.postDelayed(()->prewarmOtherSections(kind),700));
            }catch(Exception e){
                runOnUiThread(()->{
                    if(pendingFeatured!=null && pendingFeatured.kind==kind && sourceKey.equals(currentSourceCacheKey())){
                        FeaturedTitle selected=pendingFeatured;
                        clear(selected.title);
                        TextView error=text("Não foi possível localizar o título. "+friendlyError(e),compact?12:15);
                        content.addView(error,new LinearLayout.LayoutParams(-1,dp(110)));
                        Button retry=button("↻  TENTAR NOVAMENTE"); retry.setOnClickListener(v->openFeatured(selected)); content.addView(retry,new LinearLayout.LayoutParams(-1,dp(52)));
                        Button back=button("←  VOLTAR AO INÍCIO"); back.setOnClickListener(v->showHome()); content.addView(back,new LinearLayout.LayoutParams(-1,dp(52)));
                    }else if(currentSectionRequest==kind && cachedSection(kind,true)==null){ showSectionError(sectionTitle(kind),e); }
                });
            }finally{ unmarkSectionLoading(kind); }
        });
    }

    void saveCatalogAsync(int kind,SectionData data){
        if(data==null||data.sourceKey==null||data.sourceKey.isEmpty())return;
        try{cacheExec.submit(()->CatalogCache.save(this,data.sourceKey,kind,data.items,data.categories,data.loadedAt));}catch(Exception ignored){}
    }

    SectionData fetchSectionData(int kind,String mode,String sourceKey) throws Exception{
        List<MediaEntry> items=new ArrayList<>();
        ArrayList<String> categoryOrder=new ArrayList<>();

        if(mode.equals("xtream")){
            XtreamCreds x=savedXtream();
            if(!x.valid())throw new IOException("credenciais Xtream não encontradas");

            LinkedHashMap<String,String> cats=loadXtreamCategoriesSafe(x,categoryAction(kind));
            if(kind==LIVE)items=loadXtreamLive(x,cats);
            else if(kind==MOVIE)items=loadXtreamMovies(x,cats);
            else items=loadXtreamSeries(x,cats);

            LinkedHashSet<String> used=new LinkedHashSet<>();
            for(MediaEntry e:items){
                String g=(e.group==null||e.group.trim().isEmpty())?"Outros":e.group.trim();
                used.add(g);
            }
            for(String name:cats.values()){
                if(name==null)continue;
                String n=name.trim();
                if(!n.isEmpty()&&!categoryOrder.contains(n))categoryOrder.add(n);
            }
            for(String g:used)if(!categoryOrder.contains(g))categoryOrder.add(g);

            if(items.isEmpty()){
                List<MediaEntry> fallback=loadXtreamM3uFallback(x,kind);
                if(fallback!=null&&!fallback.isEmpty()){
                    items=fallback; categoryOrder.clear(); LinkedHashSet<String> groups=new LinkedHashSet<>();
                    for(MediaEntry e:items)groups.add((e.group==null||e.group.trim().isEmpty())?"Outros":e.group.trim());
                    categoryOrder.addAll(groups);
                }
            }
        }else{
            List<MediaEntry> all=ensurePlaylistLoaded(mode);
            LinkedHashSet<String> groups=new LinkedHashSet<>();
            for(MediaEntry e:all){
                if(e.kind==kind){
                    items.add(e);
                    groups.add((e.group==null||e.group.trim().isEmpty())?"Outros":e.group.trim());
                }
            }
            categoryOrder.addAll(groups);
        }
        return new SectionData(items,categoryOrder,System.currentTimeMillis(),sourceKey);
    }

    void showSectionError(String title,Exception e){
        clear(title); addTitle(title,24);
        TextView t=text("Não foi possível carregar "+title+". "+friendlyError(e),compact?11:14);
        t.setTextColor(MUTED); t.setGravity(Gravity.CENTER); t.setPadding(dp(18),dp(18),dp(18),dp(18));
        content.addView(t,new LinearLayout.LayoutParams(-1,dp(compact?110:130)));
        Button retry=button("↻  TENTAR NOVAMENTE"); retry.setTextColor(GOLD);
        retry.setOnClickListener(v->{ if(title.equals("TV Ao Vivo"))showLive(); else if(title.equals("Filmes"))showMovies(); else showSeries(); });
        content.addView(retry,new LinearLayout.LayoutParams(-1,dp(54)));
        Button setup=button("⚙  TROCAR PLAYLIST"); setup.setOnClickListener(v->showPlaylistManager());
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(54)); sp.topMargin=dp(8); content.addView(setup,sp);
    }

    List<MediaEntry> loadXtreamM3uFallback(XtreamCreds x,int kind) throws Exception{
        String m3u=x.server+"/get.php?username="+enc(x.user)+"&password="+enc(x.pass)+"&type=m3u_plus&output=ts";
        List<MediaEntry> all=loadFromUrl(m3u); ArrayList<MediaEntry> out=new ArrayList<>();
        for(MediaEntry e:all)if(e.kind==kind)out.add(e);
        return out;
    }

    List<MediaEntry> ensurePlaylistLoaded(String mode) throws Exception{
        if(!playlistCache.isEmpty())return new ArrayList<>(playlistCache); List<MediaEntry> all;
        if(mode.equals("file")){String su=prefs.getString("file_uri","");if(su.isEmpty())throw new IOException("arquivo não encontrado");all=loadFromUri(Uri.parse(su));}
        else {String u=prefs.getString("url","");if(u.isEmpty())throw new IOException("URL não encontrada");all=loadFromUrl(u);} playlistCache=new ArrayList<>(all); return all;
    }

    void showBrowser(String title,List<MediaEntry> items,int kind){
        boolean restoring=restoreKind==kind; String focusKey=restoring?restoreFocusKey:"";
        browserAll=new ArrayList<>(items); browserKind=kind; browserGroup=restoring?restoreGroup:"Todos"; browserQuery=restoring?restoreQuery:""; detailScreenKind=-1; clear(title);
        if(items.isEmpty()){ TextView empty=text("Nenhum conteúdo deste tipo foi encontrado nesta fonte.",14); empty.setTextColor(MUTED); empty.setGravity(Gravity.CENTER); content.addView(empty,new LinearLayout.LayoutParams(-1,dp(120))); Button setup=button("⚙ CONFIGURAR OUTRA FONTE"); setup.setOnClickListener(v->showSetup()); content.addView(setup,new LinearLayout.LayoutParams(-1,dp(52))); return; }

        LinearLayout toolbar=new LinearLayout(this); toolbar.setOrientation(LinearLayout.HORIZONTAL); toolbar.setGravity(Gravity.CENTER_VERTICAL);
        EditText catSearch=field("⌕  Buscar categoria...",""); toolbar.addView(catSearch,new LinearLayout.LayoutParams(dp(compact?220:285),dp(46)));
        EditText channelSearch=field("⌕  Buscar canais...",browserQuery); LinearLayout.LayoutParams chp=new LinearLayout.LayoutParams(0,dp(46),1); chp.leftMargin=dp(8); toolbar.addView(channelSearch,chp);
        content.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(52)));

        LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.HORIZONTAL); body.setGravity(Gravity.TOP);
        LinearLayout catPanel=new LinearLayout(this); catPanel.setOrientation(LinearLayout.VERTICAL); catPanel.setPadding(dp(8),dp(8),dp(8),dp(8)); catPanel.setBackground(box(Color.rgb(8,9,11),12,Color.rgb(70,55,24),1));
        ScrollView catScroll=new ScrollView(this); catScroll.setVerticalScrollBarEnabled(true); catScroll.setScrollbarFadingEnabled(false); catScroll.setNestedScrollingEnabled(true); catScroll.setFocusable(false); catScroll.setFocusableInTouchMode(false); catScroll.setDescendantFocusability(android.view.ViewGroup.FOCUS_AFTER_DESCENDANTS); LinearLayout cats=new LinearLayout(this); cats.setOrientation(LinearLayout.VERTICAL); catScroll.addView(cats,new ScrollView.LayoutParams(-1,-2)); int liveCatH=Math.max(230,getResources().getConfiguration().screenHeightDp-(compact?150:175)); catPanel.addView(catScroll,new LinearLayout.LayoutParams(-1,dp(liveCatH)));
        int leftW=compact?220:280; body.addView(catPanel,new LinearLayout.LayoutParams(dp(leftW),-1));

        LinearLayout channelPanel=new LinearLayout(this); channelPanel.setOrientation(LinearLayout.VERTICAL); channelPanel.setPadding(dp(8),0,dp(8),0);
        browserResultCount=text("",compact?10:12);browserResultCount.setTextColor(MUTED);channelPanel.addView(browserResultCount,new LinearLayout.LayoutParams(-1,dp(30)));
        browserRecycler=new RecyclerView(this);browserRecycler.setLayoutManager(new LinearLayoutManager(this));browserRecycler.setHasFixedSize(true);browserRecycler.setItemViewCacheSize(12);browserRecycler.setNestedScrollingEnabled(true);browserRecycler.setFocusable(false);browserRecycler.setDescendantFocusability(android.view.ViewGroup.FOCUS_AFTER_DESCENDANTS);
        channelRecyclerAdapter=new ChannelRecyclerAdapter();browserRecycler.setAdapter(channelRecyclerAdapter);int channelH=Math.max(220,getResources().getConfiguration().screenHeightDp-(compact?160:185));channelPanel.addView(browserRecycler,new LinearLayout.LayoutParams(-1,dp(channelH)));
        body.addView(channelPanel,new LinearLayout.LayoutParams(0,dp(channelH+34),1.15f));

        LinearLayout playerPanel=new LinearLayout(this); playerPanel.setOrientation(LinearLayout.VERTICAL); playerPanel.setPadding(dp(8),0,0,0);
        FrameLayout preview=new FrameLayout(this); preview.setBackground(box(Color.BLACK,12,Color.rgb(70,55,24),1)); ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.aureon_logo); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); preview.addView(logo,new FrameLayout.LayoutParams(-1,-1)); TextView hint=text("Selecione um canal para reproduzir",compact?10:13); hint.setGravity(Gravity.CENTER|Gravity.BOTTOM); hint.setTextColor(MUTED); FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(52)); hp.gravity=Gravity.BOTTOM; preview.addView(hint,hp); playerPanel.addView(preview,new LinearLayout.LayoutParams(-1,dp(compact?230:320)));
        LinearLayout quick=new LinearLayout(this); quick.setOrientation(LinearLayout.HORIZONTAL); Button back=button("↶\nVoltar"); Button fav=button("♡\nFavorito"); Button full=button("⛶\nTela Cheia"); Button more=button("⋯\nMais"); quick.addView(back,new LinearLayout.LayoutParams(0,dp(76),1)); quick.addView(fav,new LinearLayout.LayoutParams(0,dp(76),1)); quick.addView(full,new LinearLayout.LayoutParams(0,dp(76),1)); quick.addView(more,new LinearLayout.LayoutParams(0,dp(76),1)); LinearLayout.LayoutParams qlp=new LinearLayout.LayoutParams(-1,dp(82)); qlp.topMargin=dp(8); playerPanel.addView(quick,qlp);
        body.addView(playerPanel,new LinearLayout.LayoutParams(0,-1,.95f)); content.addView(body,new LinearLayout.LayoutParams(-1,-2));

        LinkedHashMap<String,Integer> counts=new LinkedHashMap<>(); for(MediaEntry e:items){String g=(e.group==null||e.group.trim().isEmpty())?"Outros":e.group.trim();counts.put(g,counts.getOrDefault(g,0)+1);} 
        Runnable rebuildCats=()->{cats.removeAllViews();String f=catSearch.getText().toString().trim().toLowerCase(Locale.US); addLiveCategory(cats,"Todos",items.size(),browserGroup.equals("Todos"),channelSearch); if(f.isEmpty()||"recentemente vistos".contains(f))addLiveCategory(cats,"Recentemente vistos",storedMatches(PlaybackStore.recents(this,100),LIVE,items).size(),browserGroup.equals("Recentemente vistos"),channelSearch); if(f.isEmpty()||"favoritos".contains(f))addLiveCategory(cats,"Favoritos",storedMatches(PlaybackStore.favorites(this),LIVE,items).size(),browserGroup.equals("Favoritos"),channelSearch); ArrayList<String> names=browserCategoryOrder.isEmpty()?new ArrayList<>(counts.keySet()):new ArrayList<>(browserCategoryOrder); for(String g:counts.keySet())if(!names.contains(g))names.add(g); for(String g:names){if(g==null||g.trim().isEmpty())continue;if(!f.isEmpty()&&!g.toLowerCase(Locale.US).contains(f))continue;addLiveCategory(cats,g,counts.getOrDefault(g,0),browserGroup.equals(g),channelSearch);}};
        catSearch.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){rebuildCats.run();}public void afterTextChanged(Editable e){}});
        channelSearch.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){browserQuery=s.toString();renderBrowserList();}public void afterTextChanged(Editable e){}});
        rebuildCats.run(); renderBrowserList();
        if(restoring && !focusKey.isEmpty()){ restoreKind=-1; restoreBrowserItemFocus(focusKey); }
        else { if(restoring)restoreKind=-1; focusFirstChild(cats); }
    }

    void addLiveCategory(LinearLayout parent,String group,int count,boolean selected,EditText search){
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(10),0,dp(8),0); row.setBackground(box(selected?Color.rgb(68,49,15):Color.TRANSPARENT,9,selected?GOLD:Color.TRANSPARENT,selected?2:0)); row.setClickable(true); row.setFocusable(true);
        TextView n=text(group,compact?10:12); n.setTextColor(selected?GOLD:WHITE); row.addView(n,new LinearLayout.LayoutParams(0,dp(42),1)); TextView c=text(String.valueOf(count),compact?9:11); c.setTextColor(selected?GOLD:MUTED); c.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); row.addView(c,new LinearLayout.LayoutParams(dp(48),dp(42)));
        row.setOnClickListener(v->{browserGroup=group;browserQuery=search.getText().toString();renderBrowserList();focusFirstBrowserItem();});
        row.setOnFocusChangeListener((v,has)->{
            boolean active=browserGroup.equals(group);
            if(has){
                row.setBackground(box(Color.rgb(78,56,16),9,GOLD,3)); n.setTextColor(GOLD); c.setTextColor(WHITE);
            }else{
                row.setBackground(box(active?Color.rgb(68,49,15):Color.TRANSPARENT,9,active?GOLD:Color.TRANSPARENT,active?2:0));
                n.setTextColor(active?GOLD:WHITE); c.setTextColor(active?GOLD:MUTED);
            }
            focusMotion(v,has);
        });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(44)); lp.bottomMargin=dp(2); parent.addView(row,lp);
    }

    String titleForKind(int kind){ return kind==LIVE?"TV Ao Vivo":kind==MOVIE?"Filmes":"Séries"; }

    void showLibrary(String title,List<MediaEntry> items,int kind){
        boolean restoring=restoreKind==kind; String focusKey=restoring?restoreFocusKey:"";
        browserAll=new ArrayList<>(items); browserKind=kind; browserGroup=restoring?restoreGroup:"Todos"; browserQuery=restoring?restoreQuery:""; browserSortRecent=true; detailScreenKind=-1; clear(title+" • "+items.size());
        if(items.isEmpty()){ TextView empty=text("Nenhum "+title.toLowerCase(Locale.US)+" foi encontrado nesta fonte.",14); empty.setTextColor(MUTED); empty.setGravity(Gravity.CENTER); content.addView(empty,new LinearLayout.LayoutParams(-1,dp(120))); Button setup=button("⚙ CONFIGURAR OUTRA FONTE"); setup.setOnClickListener(v->showSetup()); content.addView(setup,new LinearLayout.LayoutParams(-1,dp(52))); return; }

        LinearLayout heading=new LinearLayout(this); heading.setGravity(Gravity.CENTER_VERTICAL); heading.setPadding(0,0,0,dp(5));
        TextView icon=text(kind==MOVIE?"▤":"▶",compact?24:31); icon.setTextColor(GOLD); icon.setGravity(Gravity.CENTER); icon.setBackground(box(Color.rgb(15,15,16),12,GOLD,1)); heading.addView(icon,new LinearLayout.LayoutParams(dp(compact?48:60),dp(compact?48:60)));
        LinearLayout htexts=new LinearLayout(this); htexts.setOrientation(LinearLayout.VERTICAL); htexts.setPadding(dp(12),0,0,0); TextView h=text(title,compact?22:29); h.setTypeface(null,1); htexts.addView(h,new LinearLayout.LayoutParams(-1,dp(compact?29:36))); TextView hs=text(kind==MOVIE?"Milhares de filmes para você assistir":"Milhares de séries para você assistir",compact?9:12); hs.setTextColor(MUTED); htexts.addView(hs,new LinearLayout.LayoutParams(-1,dp(22))); heading.addView(htexts,new LinearLayout.LayoutParams(0,dp(compact?54:64),1));
        content.addView(heading,new LinearLayout.LayoutParams(-1,dp(compact?60:70)));

        LinearLayout toolbar=new LinearLayout(this); toolbar.setOrientation(LinearLayout.HORIZONTAL); toolbar.setGravity(Gravity.CENTER_VERTICAL);
        EditText search=field(kind==MOVIE?"⌕   Buscar filmes...":"⌕   Buscar séries...",browserQuery); toolbar.addView(search,new LinearLayout.LayoutParams(0,dp(compact?43:48),1));
        Button sort=button("Ordenar: Mais recentes  ▾"); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(compact?190:255),dp(compact?43:48)); sp.leftMargin=dp(8); toolbar.addView(sort,sp);
        mediaCount=text("Todos ("+items.size()+")",compact?11:15); mediaCount.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(compact?135:180),dp(compact?43:48)); cp.leftMargin=dp(8); toolbar.addView(mediaCount,cp);
        content.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(compact?48:54)));

        LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.HORIZONTAL); body.setGravity(Gravity.TOP);
        LinearLayout categoryPanel=new LinearLayout(this); categoryPanel.setOrientation(LinearLayout.VERTICAL); categoryPanel.setPadding(dp(10),dp(9),dp(10),dp(10)); categoryPanel.setBackground(box(Color.rgb(9,10,11),13,Color.rgb(82,61,21),1));
        categorySearch=field("⌕  Buscar categoria...",""); categoryPanel.addView(categorySearch,new LinearLayout.LayoutParams(-1,dp(compact?40:45)));
        ScrollView catScroll=new ScrollView(this); catScroll.setVerticalScrollBarEnabled(true); catScroll.setScrollbarFadingEnabled(false); catScroll.setNestedScrollingEnabled(true); catScroll.setFocusable(false); catScroll.setFocusableInTouchMode(false); catScroll.setDescendantFocusability(android.view.ViewGroup.FOCUS_AFTER_DESCENDANTS); categoryColumn=new LinearLayout(this); categoryColumn.setOrientation(LinearLayout.VERTICAL); catScroll.addView(categoryColumn,new ScrollView.LayoutParams(-1,-2)); int libraryCatH=Math.max(220,getResources().getConfiguration().screenHeightDp-(compact?185:210)); LinearLayout.LayoutParams csp=new LinearLayout.LayoutParams(-1,dp(libraryCatH)); csp.topMargin=dp(8); categoryPanel.addView(catScroll,csp);
        int catW=compact?225:285; body.addView(categoryPanel,new LinearLayout.LayoutParams(dp(catW),dp(libraryCatH+(compact?58:64))));

        LinearLayout gridWrap=new LinearLayout(this); gridWrap.setOrientation(LinearLayout.VERTICAL); gridWrap.setPadding(dp(10),0,0,0);
        int cols=compact?4:5;mediaRecycler=new RecyclerView(this);mediaRecycler.setLayoutManager(new GridLayoutManager(this,cols));mediaRecycler.setHasFixedSize(true);mediaRecycler.setItemViewCacheSize(cols*3);mediaRecycler.setNestedScrollingEnabled(true);mediaRecycler.setFocusable(false);mediaRecycler.setDescendantFocusability(android.view.ViewGroup.FOCUS_AFTER_DESCENDANTS);mediaRecyclerAdapter=new MediaRecyclerAdapter(cols);mediaRecycler.setAdapter(mediaRecyclerAdapter);
        gridWrap.addView(mediaRecycler,new LinearLayout.LayoutParams(-1,dp(libraryCatH+(compact?58:64)))); body.addView(gridWrap,new LinearLayout.LayoutParams(0,dp(libraryCatH+(compact?58:64)),1));
        content.addView(body,new LinearLayout.LayoutParams(-1,-2));

        Runnable rebuildCategories=()->renderCategoryColumn(categorySearch.getText().toString());
        categorySearch.addTextChangedListener(new TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){rebuildCategories.run();} public void afterTextChanged(Editable e){} });
        search.addTextChangedListener(new TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){browserQuery=s.toString();renderMediaGrid();} public void afterTextChanged(Editable e){} });
        sort.setOnClickListener(v->{browserSortRecent=!browserSortRecent;sort.setText(browserSortRecent?"Ordenar: Mais recentes  ▾":"Ordenar: A-Z  ▾");renderMediaGrid();});
        renderCategoryColumn(""); renderMediaGrid();
        if(restoring && !focusKey.isEmpty()){ restoreKind=-1; restoreMediaItemFocus(focusKey); }
        else { if(restoring)restoreKind=-1; focusFirstChild(categoryColumn); }
    }

    void renderCategoryColumn(String filter){
        if(categoryColumn==null)return; categoryColumn.removeAllViews(); String f=filter==null?"":filter.trim().toLowerCase(Locale.US);
        LinkedHashMap<String,Integer> counts=new LinkedHashMap<>(); for(MediaEntry e:browserAll){String g=(e.group==null||e.group.trim().isEmpty())?"Outros":e.group.trim();counts.put(g,counts.getOrDefault(g,0)+1);} 
        addLibraryCategory("Todos",browserAll.size(),browserGroup.equals("Todos"));
        if(browserKind==MOVIE) addLibraryCategory("Continuar assistindo",storedMatches(PlaybackStore.continueWatching(this,100),MOVIE,browserAll).size(),browserGroup.equals("Continuar assistindo"));
        else addLibraryCategory("Recentemente vistos",storedMatches(PlaybackStore.recents(this,100),SERIES,browserAll).size(),browserGroup.equals("Recentemente vistos"));
        addLibraryCategory("Favoritos",storedMatches(PlaybackStore.favorites(this),browserKind,browserAll).size(),browserGroup.equals("Favoritos"));
        ArrayList<String> names=browserCategoryOrder.isEmpty()?new ArrayList<>(counts.keySet()):new ArrayList<>(browserCategoryOrder);
        for(String g:counts.keySet())if(!names.contains(g))names.add(g);
        for(String g:names){if(g==null||g.trim().isEmpty())continue;if(!f.isEmpty()&&!g.toLowerCase(Locale.US).contains(f))continue; addLibraryCategory(g,counts.getOrDefault(g,0),browserGroup.equals(g));}
    }

    void addLibraryCategory(String group,int count,boolean selected){
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(10),0,dp(8),0); row.setBackground(box(selected?Color.rgb(70,50,16):Color.TRANSPARENT,10,selected?GOLD:Color.TRANSPARENT,selected?2:0)); row.setClickable(true); row.setFocusable(true);
        TextView name=text(group,compact?10:13); name.setTextColor(selected?GOLD:WHITE); row.addView(name,new LinearLayout.LayoutParams(0,dp(compact?38:44),1)); TextView ct=text(String.valueOf(count),compact?9:11); ct.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); ct.setTextColor(selected?GOLD:MUTED); row.addView(ct,new LinearLayout.LayoutParams(dp(55),dp(compact?38:44)));
        row.setOnClickListener(v->{browserGroup=group;renderCategoryColumn(categorySearch==null?"":categorySearch.getText().toString());renderMediaGrid();focusFirstMediaCard();});
        row.setOnFocusChangeListener((v,has)->{
            boolean active=browserGroup.equals(group);
            if(has){
                row.setBackground(box(Color.rgb(78,56,16),10,GOLD,3)); name.setTextColor(GOLD); ct.setTextColor(WHITE);
            }else{
                row.setBackground(box(active?Color.rgb(70,50,16):Color.TRANSPARENT,10,active?GOLD:Color.TRANSPARENT,active?2:0));
                name.setTextColor(active?GOLD:WHITE); ct.setTextColor(active?GOLD:MUTED);
            }
            focusMotion(v,has);
        });
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(compact?40:46)); rp.bottomMargin=dp(2); categoryColumn.addView(row,rp);
    }

    void renderMediaGrid(){
        if(mediaRecycler==null||mediaRecyclerAdapter==null)return; browserFiltered.clear(); String q=browserQuery==null?"":browserQuery.trim().toLowerCase(Locale.US);
        List<MediaEntry> source=browserAll;
        if("Favoritos".equals(browserGroup))source=storedMatches(PlaybackStore.favorites(this),browserKind,browserAll);
        else if("Continuar assistindo".equals(browserGroup))source=storedMatches(PlaybackStore.continueWatching(this,100),MOVIE,browserAll);
        else if("Recentemente vistos".equals(browserGroup))source=storedMatches(PlaybackStore.recents(this,100),SERIES,browserAll);
        for(MediaEntry e:source){boolean groupOk=specialGroup(browserGroup)||browserGroup.equals("Todos")||browserGroup.equals(e.group);boolean searchOk=q.isEmpty()||(e.name!=null&&e.name.toLowerCase(Locale.US).contains(q));if(groupOk&&searchOk)browserFiltered.add(e);}
        if(browserSortRecent) Collections.sort(browserFiltered,(a,b)->compareAdded(b,a)); else Collections.sort(browserFiltered,Comparator.comparing(e->e.name==null?"":e.name,String.CASE_INSENSITIVE_ORDER));
        if(mediaCount!=null)mediaCount.setText((browserGroup.equals("Todos")?"Todos":"Categoria")+" ("+browserFiltered.size()+")");
        mediaRecyclerAdapter.submit(new ArrayList<>(browserFiltered));
    }

    int compareAdded(MediaEntry a,MediaEntry b){
        String aa=a==null?"":a.added, bb=b==null?"":b.added; if(aa==null)aa="";if(bb==null)bb=""; try{return Long.compare(Long.parseLong(aa),Long.parseLong(bb));}catch(Exception ignored){} return aa.compareToIgnoreCase(bb);
    }

    void addNextMediaPage(){ renderMediaGrid(); }

    LinearLayout makePosterCard(MediaEntry e,int cardW,int posterH){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(0,0,0,dp(4)); card.setBackground(box(Color.rgb(12,13,14),9,Color.rgb(91,67,20),1)); card.setClickable(true); card.setFocusable(true);
        FrameLayout posterFrame=new FrameLayout(this); ImageView img=new ImageView(this); img.setScaleType(ImageView.ScaleType.CENTER_CROP); img.setImageResource(R.drawable.aureon_logo); posterFrame.addView(img,new FrameLayout.LayoutParams(-1,-1)); if(e.poster!=null&&!e.poster.trim().isEmpty())loadImage(e.poster,img);
        if(e.rating!=null&&!e.rating.trim().isEmpty()&&!e.rating.equals("0")&&!e.rating.equals("0.0")){TextView rating=text("★ "+trimRating(e.rating),compact?8:10);rating.setTextColor(GOLD);rating.setGravity(Gravity.CENTER);rating.setBackground(box(Color.rgb(5,6,7),7,GOLD,1));FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(dp(compact?46:55),dp(compact?22:25));rp.gravity=Gravity.LEFT|Gravity.BOTTOM;rp.leftMargin=dp(6);rp.bottomMargin=dp(6);posterFrame.addView(rating,rp);} card.addView(posterFrame,new LinearLayout.LayoutParams(-1,dp(posterH)));
        TextView name=text(e.name==null?"":e.name,compact?9:11); name.setTypeface(null,1); name.setMaxLines(2); name.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); name.setPadding(dp(7),dp(2),dp(5),0); card.addView(name,new LinearLayout.LayoutParams(-1,dp(compact?38:44))); TextView yr=text(e.year==null?"":e.year,compact?8:10);yr.setTextColor(MUTED);yr.setPadding(dp(7),0,0,0);card.addView(yr,new LinearLayout.LayoutParams(-1,dp(compact?18:21)));
        card.setOnClickListener(v->openMediaDetailsFromBrowser(e));
        card.setOnFocusChangeListener((v,has)->{
            card.setBackground(box(has?Color.rgb(42,31,12):Color.rgb(12,13,14),9,has?GOLD:Color.rgb(91,67,20),has?4:1));
            name.setTextColor(has?GOLD:WHITE); focusMotion(v,has);
        });
        return card;
    }

    String trimRating(String r){try{double d=Double.parseDouble(r);return String.format(Locale.US,"%.1f",d);}catch(Exception e){return r.length()>4?r.substring(0,4):r;}}

    void loadImage(String url,ImageView target){
        if(url==null||url.trim().isEmpty())return;
        target.setTag(url);
        Bitmap cached=imageCache.get(url);
        if(cached!=null){ target.setImageBitmap(cached); return; }
        imageExec.submit(()->{
            try{
                File disk=imageCacheFile(url);
                Bitmap b=null;
                if(disk.exists()&&disk.length()>0){
                    b=decodeSampledFile(disk,compact?420:560,compact?620:820);
                    if(b==null)disk.delete();
                }
                if(b==null){
                    HttpURLConnection c=null;
                    try{
                        c=(HttpURLConnection)new URL(url).openConnection();
                        c.setConnectTimeout(5000); c.setReadTimeout(9000); c.setInstanceFollowRedirects(true); c.setUseCaches(true);
                        c.setRequestProperty("User-Agent","Aureon/32.0"); c.setRequestProperty("Connection","keep-alive"); c.setRequestProperty("Accept","image/*,*/*;q=0.8");
                        InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n;
                        while((n=in.read(buf))!=-1 && out.size()<8*1024*1024)out.write(buf,0,n);
                        in.close(); byte[] bytes=out.toByteArray();
                        b=decodeSampledBytes(bytes,compact?420:560,compact?620:820);
                        if(b!=null&&bytes.length>0&&bytes.length<8*1024*1024){ try(FileOutputStream fos=new FileOutputStream(disk)){fos.write(bytes);}catch(Exception ignored){} }
                    }finally{ if(c!=null)c.disconnect(); }
                }
                if(b!=null){
                    final Bitmap ready=b; imageCache.put(url,ready);
                    runOnUiThread(()->{ Object tag=target.getTag(); if(tag!=null&&url.equals(tag.toString()))target.setImageBitmap(ready); });
                }
            }catch(Exception ignored){}
        });
    }

    File imageCacheFile(String url){
        String name=Integer.toHexString(url.hashCode())+"_"+Integer.toHexString((url+"mt").hashCode())+".img";
        return new File(imageDiskDir,name);
    }

    Bitmap decodeSampledFile(File f,int reqW,int reqH){
        try{
            BitmapFactory.Options bounds=new BitmapFactory.Options(); bounds.inJustDecodeBounds=true; BitmapFactory.decodeFile(f.getAbsolutePath(),bounds);
            BitmapFactory.Options opt=new BitmapFactory.Options(); opt.inSampleSize=sampleSize(bounds.outWidth,bounds.outHeight,reqW,reqH); opt.inPreferredConfig=Bitmap.Config.RGB_565;
            return BitmapFactory.decodeFile(f.getAbsolutePath(),opt);
        }catch(Exception e){return null;}
    }

    Bitmap decodeSampledBytes(byte[] bytes,int reqW,int reqH){
        try{
            BitmapFactory.Options bounds=new BitmapFactory.Options(); bounds.inJustDecodeBounds=true; BitmapFactory.decodeByteArray(bytes,0,bytes.length,bounds);
            BitmapFactory.Options opt=new BitmapFactory.Options(); opt.inSampleSize=sampleSize(bounds.outWidth,bounds.outHeight,reqW,reqH); opt.inPreferredConfig=Bitmap.Config.RGB_565;
            return BitmapFactory.decodeByteArray(bytes,0,bytes.length,opt);
        }catch(Exception e){return null;}
    }

    int sampleSize(int w,int h,int reqW,int reqH){
        int s=1; if(w<=0||h<=0)return 1; while((w/(s*2))>=reqW&&(h/(s*2))>=reqH)s*=2; return Math.max(1,s);
    }

    void trimImageDiskCache(){
        try{
            if(imageDiskDir==null||!imageDiskDir.exists())return; File[] fs=imageDiskDir.listFiles(); if(fs==null)return;
            long total=0; for(File f:fs)total+=f.length(); if(total<=80L*1024L*1024L)return;
            java.util.Arrays.sort(fs,(a,b)->Long.compare(a.lastModified(),b.lastModified()));
            for(File f:fs){long len=f.length(); if(f.delete())total-=len; if(total<=55L*1024L*1024L)break;}
        }catch(Exception ignored){}
    }

    void clearImageDiskCache(){
        imageExec.submit(()->{ try{ if(imageDiskDir==null)return; File[] fs=imageDiskDir.listFiles(); if(fs!=null)for(File f:fs)f.delete(); }catch(Exception ignored){} });
    }

    void addCategoryButton(LinearLayout row,String group,EditText search){ Button b=button(group); b.setOnClickListener(v->{browserGroup=group;browserQuery=search.getText().toString().trim();renderBrowserList();}); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(compact?135:180),dp(44)); p.rightMargin=dp(5); row.addView(b,p); }

    List<MediaEntry> storedMatches(List<MediaEntry> stored,int kind,List<MediaEntry> current){
        ArrayList<MediaEntry> out=new ArrayList<>(); if(stored==null)return out;
        LinkedHashMap<String,MediaEntry> byKey=new LinkedHashMap<>(); if(current!=null)for(MediaEntry e:current)if(e!=null)byKey.put(PlaybackStore.key(e),e);
        for(MediaEntry e:stored){if(e==null||e.kind!=kind)continue;MediaEntry now=byKey.get(PlaybackStore.key(e));out.add(now==null?e:now);} return out;
    }

    boolean specialGroup(String g){return "Recentemente vistos".equals(g)||"Favoritos".equals(g)||"Continuar assistindo".equals(g);}

    void renderBrowserList(){
        if(browserRecycler==null||channelRecyclerAdapter==null)return; browserFiltered.clear(); String q=browserQuery==null?"":browserQuery.toLowerCase(Locale.US);
        List<MediaEntry> source=browserAll;
        if("Recentemente vistos".equals(browserGroup))source=storedMatches(PlaybackStore.recents(this,100),LIVE,browserAll);
        else if("Favoritos".equals(browserGroup))source=storedMatches(PlaybackStore.favorites(this),LIVE,browserAll);
        for(MediaEntry e:source){boolean groupOk=specialGroup(browserGroup)||browserGroup.equals("Todos")||browserGroup.equals(e.group);boolean searchOk=q.isEmpty()||(e.name!=null&&e.name.toLowerCase(Locale.US).contains(q));if(groupOk&&searchOk)browserFiltered.add(e);}
        if(browserResultCount!=null)browserResultCount.setText(browserFiltered.size()+" resultado(s)");
        channelRecyclerAdapter.submit(new ArrayList<>(browserFiltered));
    }

    void addNextBrowserPage(){ renderBrowserList(); }

    LinearLayout makeLiveRow(MediaEntry e){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(4),dp(10),dp(4));row.setBackground(box(Color.rgb(18,18,20),10,Color.rgb(82,61,22),1));row.setClickable(true);row.setFocusable(true);
        ImageView channelLogo=new ImageView(this);channelLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);channelLogo.setImageResource(R.drawable.aureon_logo);channelLogo.setBackground(box(Color.rgb(8,8,9),8,Color.rgb(70,55,24),1));int logoSize=dp(compact?36:44);LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(logoSize,logoSize);ilp.rightMargin=dp(10);row.addView(channelLogo,ilp);if(e.poster!=null&&!e.poster.trim().isEmpty())loadImage(e.poster,channelLogo);
        TextView playIcon=text("▶",compact?10:12);playIcon.setTextColor(GOLD);playIcon.setGravity(Gravity.CENTER);row.addView(playIcon,new LinearLayout.LayoutParams(dp(22),-1));
        TextView name=text(e.name==null?"Canal":e.name,compact?11:13);name.setTextColor(WHITE);name.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);name.setMaxLines(2);name.setPadding(dp(4),0,0,0);row.addView(name,new LinearLayout.LayoutParams(0,-1,1));
        row.setOnClickListener(v->openLiveDetailsFromBrowser(e));row.setOnFocusChangeListener((v,has)->{row.setBackground(box(has?Color.rgb(78,56,16):Color.rgb(18,18,20),10,has?GOLD:Color.rgb(82,61,22),has?3:1));name.setTextColor(has?GOLD:WHITE);playIcon.setTextColor(has?WHITE:GOLD);focusMotion(v,has);});
        return row;
    }

    void rememberReturnState(MediaEntry e){
        if(e==null)return; restoreKind=e.kind; restoreGroup=browserGroup==null?"Todos":browserGroup; restoreQuery=browserQuery==null?"":browserQuery; restoreFocusKey=PlaybackStore.key(e);
    }

    void openLiveDetailsFromBrowser(MediaEntry e){
        rememberReturnState(e); detailNavItems=new ArrayList<>(browserFiltered.isEmpty()?browserAll:browserFiltered);
        showLiveDetails(e);
    }

    void openMediaDetailsFromBrowser(MediaEntry e){
        rememberReturnState(e); detailNavItems=new ArrayList<>(browserFiltered.isEmpty()?browserAll:browserFiltered);
        showMediaDetails(e);
    }

    MediaEntry adjacentDetail(MediaEntry current,int delta){
        if(current==null||detailNavItems==null||detailNavItems.isEmpty())return null;
        int idx=-1;
        for(int i=0;i<detailNavItems.size();i++){
            MediaEntry x=detailNavItems.get(i);
            if(x==current || (x!=null&&current.id!=null&&current.id.equals(x.id))){idx=i;break;}
        }
        if(idx<0)return null;
        int ni=idx+delta;
        if(ni<0||ni>=detailNavItems.size())return null;
        return detailNavItems.get(ni);
    }

    void addPrevNextButtons(LinearLayout parent,MediaEntry current,boolean live){
        LinearLayout navRow=new LinearLayout(this); navRow.setOrientation(LinearLayout.HORIZONTAL);
        MediaEntry prev=adjacentDetail(current,-1), next=adjacentDetail(current,1);
        Button prevBtn=button("◀  ANTERIOR"); prevBtn.setTextColor(GOLD); prevBtn.setEnabled(prev!=null); prevBtn.setAlpha(prev==null?.35f:1f);
        prevBtn.setOnClickListener(v->{if(prev!=null){if(restoreKind==current.kind)restoreFocusKey=PlaybackStore.key(prev);if(live)showLiveDetails(prev);else showMediaDetails(prev);}});
        Button nextBtn=button("PRÓXIMO  ▶"); nextBtn.setTextColor(GOLD); nextBtn.setEnabled(next!=null); nextBtn.setAlpha(next==null?.35f:1f);
        nextBtn.setOnClickListener(v->{if(next!=null){if(restoreKind==current.kind)restoreFocusKey=PlaybackStore.key(next);if(live)showLiveDetails(next);else showMediaDetails(next);}});
        navRow.addView(prevBtn,new LinearLayout.LayoutParams(0,dp(46),1));
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,dp(46),1); np.leftMargin=dp(8); navRow.addView(nextBtn,np);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(50)); rp.topMargin=dp(6); parent.addView(navRow,rp);
    }

    static synchronized void setPlayerQueue(List<MediaEntry> source,MediaEntry current){
        PLAYER_QUEUE.clear();
        if(source!=null)for(MediaEntry e:source)if(e!=null&&e.url!=null&&!e.url.trim().isEmpty())PLAYER_QUEUE.add(e);
        PLAYER_INDEX=-1;
        if(current!=null){
            for(int i=0;i<PLAYER_QUEUE.size();i++){MediaEntry e=PLAYER_QUEUE.get(i);if(e==current||(current.id!=null&&current.id.equals(e.id))){PLAYER_INDEX=i;break;}}
        }
    }

    static synchronized MediaEntry movePlayerQueue(int delta){
        if(PLAYER_QUEUE.isEmpty())return null;
        if(PLAYER_INDEX<0)PLAYER_INDEX=0; else {int ni=PLAYER_INDEX+delta;if(ni<0||ni>=PLAYER_QUEUE.size())return null;PLAYER_INDEX=ni;}
        return PLAYER_QUEUE.get(PLAYER_INDEX);
    }

    static synchronized boolean canMovePlayerQueue(int delta){
        if(PLAYER_QUEUE.isEmpty()||PLAYER_INDEX<0)return false; int ni=PLAYER_INDEX+delta; return ni>=0&&ni<PLAYER_QUEUE.size();
    }

    static synchronized ArrayList<MediaEntry> playerQueueSnapshot(){
        return new ArrayList<>(PLAYER_QUEUE);
    }

    static synchronized int getPlayerQueueIndex(){
        return PLAYER_INDEX;
    }

    static synchronized void setPlayerQueueIndex(int index){
        if(index>=0&&index<PLAYER_QUEUE.size()) PLAYER_INDEX=index;
    }

    void showMediaDetails(MediaEntry e){
        PlaybackStore.markRecent(this,e); detailScreenKind=e==null?-1:e.kind;
        currentSectionRequest=-1;
        setNavHidden(true);
        clear(e.name==null?"Detalhes":e.name);
        TextView loading=text("Carregando informações…",15); loading.setTextColor(MUTED); loading.setGravity(Gravity.CENTER);
        content.addView(loading,new LinearLayout.LayoutParams(-1,dp(110)));

        String mode=resolveSourceMode();
        XtreamCreds x=savedXtream();
        String cacheKey=e.kind+"|"+(e.id==null?"":e.id);
        final String detailSourceKey=currentSourceCacheKey();
        DetailInfo cached=detailCache.get(cacheKey);
        if(cached!=null){ renderMediaDetails(e,cached); return; }

        if(!mode.equals("xtream")||!x.valid()||e.id==null||e.id.trim().isEmpty()){
            renderMediaDetails(e,basicDetail(e)); return;
        }

        exec.submit(()->{
            DetailInfo d;
            try{ d=e.kind==SERIES?loadSeriesDetail(x,e):loadMovieDetail(x,e); }
            catch(Exception ex){ d=basicDetail(e); }
            final DetailInfo out=d;
            detailCache.put(cacheKey,out);
            runOnUiThread(()->{
                if(loading.getParent()==content && detailSourceKey.equals(currentSourceCacheKey()))renderMediaDetails(e,out);
            });
        });
    }

    DetailInfo basicDetail(MediaEntry e){
        DetailInfo d=new DetailInfo();
        d.poster=e.poster==null?"":e.poster; d.rating=e.rating==null?"":e.rating;
        d.releaseDate=e.year==null?"":e.year; d.genre=e.group==null?"":e.group;
        return d;
    }

    DetailInfo loadMovieDetail(XtreamCreds x,MediaEntry e) throws Exception{
        JSONObject root=new JSONObject(httpText(api(x,"get_vod_info&vod_id="+enc(e.id))));
        JSONObject info=root.optJSONObject("info"); if(info==null)info=new JSONObject();
        JSONObject data=root.optJSONObject("movie_data"); if(data==null)data=new JSONObject();
        DetailInfo d=basicDetail(e);
        d.plot=pick(info,data,"plot","description","overview");
        d.genre=firstNonEmpty(pick(info,data,"genre","genres"),d.genre);
        d.cast=pick(info,data,"cast","actors");
        d.director=pick(info,data,"director");
        d.duration=pick(info,data,"duration","runtime","duration_secs");
        d.releaseDate=firstNonEmpty(pick(info,data,"releasedate","releaseDate","release_date","year"),d.releaseDate);
        d.rating=firstNonEmpty(pick(info,data,"rating_5based","rating","rating_10based"),d.rating);
        d.poster=firstNonEmpty(pick(info,data,"movie_image","cover_big","cover","stream_icon"),d.poster);
        return d;
    }

    DetailInfo loadSeriesDetail(XtreamCreds x,MediaEntry e) throws Exception{
        JSONObject root=new JSONObject(httpText(api(x,"get_series_info&series_id="+enc(e.id))));
        JSONObject info=root.optJSONObject("info"); if(info==null)info=new JSONObject();
        DetailInfo d=basicDetail(e);
        d.plot=pick(info,null,"plot","description","overview");
        d.genre=firstNonEmpty(pick(info,null,"genre","genres"),d.genre);
        d.cast=pick(info,null,"cast","actors");
        d.director=pick(info,null,"director");
        d.duration=pick(info,null,"episode_run_time","duration","runtime");
        d.releaseDate=firstNonEmpty(pick(info,null,"releaseDate","releasedate","release_date","year"),d.releaseDate);
        d.rating=firstNonEmpty(pick(info,null,"rating_5based","rating","rating_10based"),d.rating);
        d.poster=firstNonEmpty(pick(info,null,"cover","cover_big","movie_image","stream_icon"),d.poster);
        return d;
    }

    String pick(JSONObject a,JSONObject b,String... keys){
        for(String k:keys){
            if(a!=null){String v=a.optString(k,"").trim();if(!v.isEmpty()&&!v.equalsIgnoreCase("null"))return v;}
            if(b!=null){String v=b.optString(k,"").trim();if(!v.isEmpty()&&!v.equalsIgnoreCase("null"))return v;}
        }
        return "";
    }

    String firstNonEmpty(String a,String b){return a!=null&&!a.trim().isEmpty()?a:b==null?"":b;}

    void renderMediaDetails(MediaEntry e,DetailInfo d){
        clear(e.name==null?"Detalhes":e.name);

        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.TOP);
        ImageView poster=new ImageView(this); poster.setScaleType(ImageView.ScaleType.CENTER_CROP); poster.setImageResource(R.drawable.aureon_logo);
        String posterUrl=firstNonEmpty(d.poster,e.poster); if(!posterUrl.isEmpty())loadImage(posterUrl,poster);
        poster.setBackground(box(Color.rgb(10,11,12),12,GOLD,1));
        int posterW=dp(compact?150:205), posterH=dp(compact?218:292);
        top.addView(poster,new LinearLayout.LayoutParams(posterW,posterH));

        LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setPadding(dp(20),dp(2),0,0);
        TextView title=text(e.name==null?"":e.name,compact?21:29); title.setTypeface(null,1); title.setMaxLines(2);
        info.addView(title,new LinearLayout.LayoutParams(-1,dp(compact?58:74)));

        StringBuilder meta=new StringBuilder();
        if(d.releaseDate!=null&&!d.releaseDate.isEmpty())meta.append(shortYear(d.releaseDate));
        if(d.rating!=null&&!d.rating.isEmpty()){if(meta.length()>0)meta.append("  •  ");meta.append("★ ").append(trimRating(d.rating));}
        if(d.duration!=null&&!d.duration.isEmpty()){if(meta.length()>0)meta.append("  •  ");meta.append(formatDuration(d.duration));}
        TextView metaV=text(meta.toString(),compact?11:14); metaV.setTextColor(GOLD); info.addView(metaV,new LinearLayout.LayoutParams(-1,dp(30)));

        // A ação principal fica logo no topo para não ficar cortada em telas menores.
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        Button back=button("←  VOLTAR"); back.setTextColor(GOLD); back.setOnClickListener(v->returnToSection(e.kind));
        actions.addView(back,new LinearLayout.LayoutParams(0,dp(48),.8f));
        Button action=button(e.kind==SERIES?"▣  TEMPORADAS":"▶  ASSISTIR"); action.setTextColor(GOLD);
        action.setOnClickListener(v->{if(e.kind==SERIES)showSeriesEpisodes(e);else {setPlayerQueue(detailNavItems,e);play(e);}});
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(48),1.3f); ap.leftMargin=dp(8); actions.addView(action,ap);
        Button favorite=button(PlaybackStore.isFavorite(this,e)?"★  FAVORITO":"☆  FAVORITAR"); favorite.setTextColor(GOLD);
        favorite.setOnClickListener(v->{boolean on=PlaybackStore.toggleFavorite(this,e);favorite.setText(on?"★  FAVORITO":"☆  FAVORITAR");});
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(0,dp(48),1f); fp.leftMargin=dp(8); actions.addView(favorite,fp);
        LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,dp(52)); alp.topMargin=dp(6); info.addView(actions,alp);
        addPrevNextButtons(info,e,false);

        if(d.genre!=null&&!d.genre.isEmpty()){TextView genre=text(d.genre,compact?10:13);genre.setTextColor(MUTED);genre.setMaxLines(2);LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,dp(40));gp.topMargin=dp(6);info.addView(genre,gp);}
        if(d.director!=null&&!d.director.isEmpty()){TextView dir=text("Direção: "+d.director,compact?9:12);dir.setTextColor(MUTED);dir.setMaxLines(2);info.addView(dir,new LinearLayout.LayoutParams(-1,dp(34)));}
        if(d.cast!=null&&!d.cast.isEmpty()){TextView cast=text("Elenco: "+d.cast,compact?9:12);cast.setTextColor(MUTED);cast.setMaxLines(2);info.addView(cast,new LinearLayout.LayoutParams(-1,dp(44)));}

        // O painel de informações pode ser mais alto que a capa (elenco, favorito, anterior/próximo etc.).
        // Usar WRAP_CONTENT evita cortar os botões em telas menores/TVs com overscan.
        info.setMinimumHeight(posterH);
        top.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        content.addView(top,new LinearLayout.LayoutParams(-1,-2));

        TextView sh=text("Sinopse",compact?17:21);sh.setTypeface(null,1);sh.setTextColor(GOLD);LinearLayout.LayoutParams shp=new LinearLayout.LayoutParams(-1,dp(42));shp.topMargin=dp(12);content.addView(sh,shp);
        String plot=d.plot==null||d.plot.trim().isEmpty()?"Sinopse não informada pelo servidor.":d.plot.trim();
        TextView synopsis=text(plot,compact?11:14);synopsis.setTextColor(Color.rgb(215,215,218));synopsis.setGravity(Gravity.TOP|Gravity.LEFT);synopsis.setPadding(dp(14),dp(12),dp(14),dp(12));synopsis.setBackground(box(Color.rgb(13,14,16),12,Color.rgb(78,59,22),1));
        content.addView(synopsis,new LinearLayout.LayoutParams(-1,-2));
    }

    String shortYear(String s){
        if(s==null)return ""; String t=s.trim();
        if(t.matches(".*\\b(19|20)\\d{2}\\b.*")){java.util.regex.Matcher m=java.util.regex.Pattern.compile("(19|20)\\d{2}").matcher(t);if(m.find())return m.group();}
        return t.length()>16?t.substring(0,16):t;
    }

    String formatDuration(String s){
        if(s==null)return ""; String t=s.trim();
        try{long sec=Long.parseLong(t);if(sec>300){long h=sec/3600,m=(sec%3600)/60;return h>0?h+"h "+m+"min":m+" min";}}catch(Exception ignored){}
        return t;
    }

    void showLiveDetails(MediaEntry e){
        PlaybackStore.markRecent(this,e); detailScreenKind=LIVE;
        currentSectionRequest=-1; setNavHidden(true);
        String mode=resolveSourceMode(); XtreamCreds x=savedXtream(); String key=e.id==null?"":e.id;
        List<EpgItem> cached=epgCache.get(key);

        // Abre a tela e inicia o canal imediatamente; o EPG chega depois sem reiniciar o vídeo.
        renderLiveDetails(e,cached);
        if(cached!=null)return;
        if(!mode.equals("xtream")||!x.valid()||key.isEmpty()){ updateLiveEpg(new ArrayList<>()); return; }

        exec.submit(()->{
            List<EpgItem> epg;
            try{epg=loadShortEpg(x,e);}catch(Exception ex){epg=new ArrayList<>();}
            epgCache.put(key,epg); final List<EpgItem> out=epg;
            runOnUiThread(()->{
                if(previewEntry!=null && key.equals(previewEntry.id)) updateLiveEpg(out);
            });
        });
    }

    List<EpgItem> loadShortEpg(XtreamCreds x,MediaEntry e) throws Exception{
        JSONObject root=new JSONObject(httpText(api(x,"get_short_epg&stream_id="+enc(e.id)+"&limit=10")));
        JSONArray a=root.optJSONArray("epg_list"); ArrayList<EpgItem> out=new ArrayList<>(); if(a==null)return out;
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;
            String title=decodeMaybeBase64(o.optString("title",o.optString("name","Programa")));
            String desc=decodeMaybeBase64(o.optString("description",o.optString("desc","")));
            String start=firstNonEmpty(o.optString("start_timestamp",""),o.optString("start",""));
            String end=firstNonEmpty(o.optString("stop_timestamp",o.optString("end_timestamp","")),o.optString("end",""));
            out.add(new EpgItem(title,desc,start,end));
        }
        return out;
    }

    String decodeMaybeBase64(String s){
        if(s==null)return ""; String t=s.trim(); if(t.isEmpty())return "";
        try{
            if(t.length()%4==0&&t.matches("[A-Za-z0-9+/=\\r\\n]+")){
                String d=new String(Base64.decode(t,Base64.DEFAULT),"UTF-8").trim();
                if(!d.isEmpty()&&d.indexOf('\u0000')<0)return d;
            }
        }catch(Exception ignored){}
        return t;
    }

    String epgTime(String s){
        if(s==null||s.trim().isEmpty())return ""; String t=s.trim();
        try{long v=Long.parseLong(t);if(v>1000000000L){SimpleDateFormat f=new SimpleDateFormat("h:mm a",Locale.US);return f.format(new Date(v*1000L));}}catch(Exception ignored){}
        if(t.length()>=16&&t.charAt(10)==' ')return t.substring(11,16);
        return t.length()>16?t.substring(0,16):t;
    }

    void renderLiveDetails(MediaEntry e,List<EpgItem> epg){
        clear(e.name==null?"Canal":e.name);

        LinearLayout head=new LinearLayout(this); head.setOrientation(LinearLayout.HORIZONTAL); head.setGravity(Gravity.TOP);

        LinearLayout infoPanel=new LinearLayout(this); infoPanel.setOrientation(LinearLayout.HORIZONTAL); infoPanel.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo=new ImageView(this); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); logo.setImageResource(R.drawable.aureon_logo);
        logo.setBackground(box(Color.rgb(10,11,12),12,GOLD,1)); if(e.poster!=null&&!e.poster.isEmpty())loadImage(e.poster,logo);
        infoPanel.addView(logo,new LinearLayout.LayoutParams(dp(compact?105:135),dp(compact?105:135)));

        LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); texts.setPadding(dp(16),0,0,0);
        TextView name=text(e.name==null?"Canal":e.name,compact?20:27); name.setTypeface(null,1); name.setMaxLines(2);
        texts.addView(name,new LinearLayout.LayoutParams(-1,dp(compact?56:68)));
        TextView grp=text(e.group==null?"":e.group,compact?10:13); grp.setTextColor(MUTED); grp.setMaxLines(2);
        texts.addView(grp,new LinearLayout.LayoutParams(-1,dp(36)));
        Button liveFav=button(PlaybackStore.isFavorite(this,e)?"★  FAVORITO":"☆  FAVORITAR");liveFav.setTextColor(GOLD);liveFav.setOnClickListener(v->{boolean on=PlaybackStore.toggleFavorite(this,e);liveFav.setText(on?"★  FAVORITO":"☆  FAVORITAR");});
        texts.addView(liveFav,new LinearLayout.LayoutParams(-1,dp(42)));
        Button back=button("←  VOLTAR AOS CANAIS"); back.setTextColor(GOLD); back.setOnClickListener(v->returnToSection(LIVE));
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(46)); bp.topMargin=dp(4); texts.addView(back,bp);
        addPrevNextButtons(texts,e,true);
        infoPanel.addView(texts,new LinearLayout.LayoutParams(0,dp(compact?235:270),1));

        // Player pequeno: começa sozinho. OK/Enter ou toque abre tela cheia.
        FrameLayout previewBox=new FrameLayout(this); previewBox.setBackground(box(Color.BLACK,12,GOLD,1));
        previewBox.setFocusable(true); previewBox.setClickable(true); previewBox.setFocusableInTouchMode(true);
        previewPlayerView=new PlayerView(this); previewPlayerView.setUseController(false); previewPlayerView.setKeepScreenOn(true);
        previewBox.addView(previewPlayerView,new FrameLayout.LayoutParams(-1,-1));
        TextView previewHint=text("OK • Tela cheia",compact?9:11); previewHint.setTextColor(WHITE); previewHint.setGravity(Gravity.CENTER); previewHint.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(30)); hp.gravity=Gravity.BOTTOM; previewBox.addView(previewHint,hp);
        View.OnClickListener openFull=v->openFullScreen(e);
        previewBox.setOnClickListener(openFull); previewPlayerView.setOnClickListener(openFull);
        View.OnKeyListener keyListener=(v,keyCode,event)->{
            if(event.getAction()==KeyEvent.ACTION_UP && (keyCode==KeyEvent.KEYCODE_DPAD_CENTER || keyCode==KeyEvent.KEYCODE_ENTER || keyCode==KeyEvent.KEYCODE_NUMPAD_ENTER)){
                openFullScreen(e); return true;
            }
            return false;
        };
        previewBox.setOnKeyListener(keyListener); previewPlayerView.setFocusable(false);

        LinearLayout leftWrap=new LinearLayout(this); leftWrap.setOrientation(LinearLayout.VERTICAL); leftWrap.addView(infoPanel,new LinearLayout.LayoutParams(-1,-1));
        head.addView(leftWrap,new LinearLayout.LayoutParams(0,dp(compact?250:290),1.0f));
        LinearLayout.LayoutParams pvLp=new LinearLayout.LayoutParams(0,dp(compact?250:290),1.15f); pvLp.leftMargin=dp(14); head.addView(previewBox,pvLp);
        content.addView(head,new LinearLayout.LayoutParams(-1,dp(compact?260:300)));

        startLivePreview(e);
        previewBox.postDelayed(previewBox::requestFocus,250);

        TextView ph=text("Programação",compact?18:22); ph.setTypeface(null,1); ph.setTextColor(GOLD);
        LinearLayout.LayoutParams php=new LinearLayout.LayoutParams(-1,dp(45)); php.topMargin=dp(10); content.addView(ph,php);
        liveEpgContainer=new LinearLayout(this); liveEpgContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(liveEpgContainer,new LinearLayout.LayoutParams(-1,-2));
        updateLiveEpg(epg);
    }

    void updateLiveEpg(List<EpgItem> epg){
        if(liveEpgContainer==null)return;
        liveEpgContainer.removeAllViews();
        if(epg==null){
            TextView loading=text("Carregando programação…",compact?11:14); loading.setTextColor(MUTED); loading.setGravity(Gravity.CENTER_VERTICAL); loading.setPadding(dp(14),dp(12),dp(14),dp(12));
            loading.setBackground(box(Color.rgb(13,14,16),12,Color.rgb(78,59,22),1));
            liveEpgContainer.addView(loading,new LinearLayout.LayoutParams(-1,dp(62))); return;
        }
        if(epg.isEmpty()){
            TextView none=text("A programação deste canal não foi fornecida pelo servidor.",compact?11:14); none.setTextColor(MUTED); none.setPadding(dp(14),dp(16),dp(14),dp(16)); none.setBackground(box(Color.rgb(13,14,16),12,Color.rgb(78,59,22),1));
            liveEpgContainer.addView(none,new LinearLayout.LayoutParams(-1,dp(70))); return;
        }
        int i=0;
        for(EpgItem p:epg){
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(dp(14),dp(10),dp(14),dp(10));
            row.setBackground(box(i==0?Color.rgb(34,27,14):Color.rgb(13,14,16),11,i==0?GOLD:Color.rgb(72,55,22),1));
            String range=epgTime(p.start)+(epgTime(p.end).isEmpty()?"":"  -  "+epgTime(p.end));
            TextView time=text(range,compact?9:11); time.setTextColor(i==0?GOLD:MUTED); row.addView(time,new LinearLayout.LayoutParams(-1,dp(24)));
            TextView title=text(p.title==null||p.title.isEmpty()?"Programa":p.title,compact?12:15); title.setTypeface(null,1); row.addView(title,new LinearLayout.LayoutParams(-1,dp(30)));
            if(p.description!=null&&!p.description.isEmpty()){TextView desc=text(p.description,compact?9:11);desc.setTextColor(MUTED);desc.setMaxLines(2);row.addView(desc,new LinearLayout.LayoutParams(-1,dp(38)));}
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(7); liveEpgContainer.addView(row,lp); i++;
        }
    }

    void startLivePreview(MediaEntry e){
        releasePreviewPlayerOnly();
        if(e==null||e.url==null||e.url.trim().isEmpty()||previewPlayerView==null)return;
        try{
            DefaultHttpDataSource.Factory httpFactory=new DefaultHttpDataSource.Factory()
                    .setUserAgent("Aureon/32.0")
                    .setAllowCrossProtocolRedirects(true)
                    .setConnectTimeoutMs(12000)
                    .setReadTimeoutMs(25000);
            DefaultLoadControl loadControl=new DefaultLoadControl.Builder().setBufferDurationsMs(2500,12000,500,1000).setPrioritizeTimeOverSizeThresholds(true).build();
            previewPlayer=new ExoPlayer.Builder(this).setLoadControl(loadControl).setMediaSourceFactory(new DefaultMediaSourceFactory(httpFactory)).build();
            previewEntry=e; previewPlayerView.setPlayer(previewPlayer); previewPlayer.setHandleAudioBecomingNoisy(true);
            previewPlayer.setMediaItem(MediaItem.fromUri(e.url)); previewPlayer.setPlayWhenReady(prefs.getBoolean("autoplay_live",true)); previewPlayer.prepare();
        }catch(Exception ignored){ releasePreviewPlayerOnly(); }
    }

    void releasePreviewPlayerOnly(){
        if(previewPlayerView!=null) previewPlayerView.setPlayer(null);
        if(previewPlayer!=null){ try{previewPlayer.release();}catch(Exception ignored){} }
        previewPlayer=null; previewEntry=null;
    }

    void openFullScreen(MediaEntry e){
        if(e==null||e.url==null||e.url.isEmpty())return;
        setPlayerQueue(detailNavItems,e);
        if(previewPlayer!=null)previewPlayer.pause();
        Intent i=new Intent(this,PlayerActivity.class); i.putExtra("url",e.url); i.putExtra("name",e.name); i.putExtra("kind",e.kind); startActivity(i);
    }

    void play(MediaEntry e){ if(e.url==null||e.url.isEmpty()){showInfo("Este item não possui link reproduzível.");return;} if(PLAYER_QUEUE.isEmpty())setPlayerQueue(detailNavItems,e); Intent i=new Intent(this,PlayerActivity.class); i.putExtra("url",e.url); i.putExtra("name",e.name); i.putExtra("kind",e.kind); startActivity(i); }

    void showSeriesEpisodes(MediaEntry series){ detailScreenKind=SERIES; currentSectionRequest=-1;
        clear(series.name); TextView loading=text("Carregando temporadas…",15); loading.setTextColor(MUTED); loading.setGravity(Gravity.CENTER); content.addView(loading,new LinearLayout.LayoutParams(-1,dp(120)));
        XtreamCreds x=savedXtream();
        exec.submit(()->{
            try{
                List<MediaEntry> eps=loadXtreamEpisodes(x,series);
                runOnUiThread(()->showSeasonFolders(series,eps));
            }catch(Exception e){
                runOnUiThread(()->showInfo("Não foi possível carregar as temporadas. "+friendlyError(e)));
            }
        });
    }

    void showSeasonFolders(MediaEntry series,List<MediaEntry> episodes){
        clear(series.name);
        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.TOP); top.setPadding(0,0,0,dp(8));
        ImageView poster=new ImageView(this); poster.setScaleType(ImageView.ScaleType.CENTER_CROP); poster.setImageResource(R.drawable.aureon_logo); if(series.poster!=null&&!series.poster.isEmpty())loadImage(series.poster,poster); poster.setBackground(box(Color.rgb(11,12,13),10,GOLD,1)); top.addView(poster,new LinearLayout.LayoutParams(dp(compact?115:155),dp(compact?165:220)));
        LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setPadding(dp(15),dp(4),0,0); TextView title=text(series.name,compact?21:28);title.setTypeface(null,1);info.addView(title,new LinearLayout.LayoutParams(-1,dp(compact?34:42))); TextView sub=text("Escolha uma temporada",compact?11:14);sub.setTextColor(MUTED);info.addView(sub,new LinearLayout.LayoutParams(-1,dp(30))); Button back=button("←  VOLTAR PARA SÉRIES");back.setTextColor(GOLD);back.setOnClickListener(v->returnToSection(SERIES));LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(dp(compact?190:245),dp(46));blp.topMargin=dp(14);info.addView(back,blp);top.addView(info,new LinearLayout.LayoutParams(0,dp(compact?165:220),1)); content.addView(top,new LinearLayout.LayoutParams(-1,dp(compact?175:230)));
        if(episodes==null||episodes.isEmpty()){TextView empty=text("Nenhuma temporada encontrada para esta série.",14);empty.setTextColor(MUTED);empty.setGravity(Gravity.CENTER);content.addView(empty,new LinearLayout.LayoutParams(-1,dp(120)));return;}
        LinkedHashMap<String,List<MediaEntry>> bySeason=new LinkedHashMap<>(); for(MediaEntry e:episodes){String season=e.group==null||e.group.trim().isEmpty()?"Temporada":e.group.trim();bySeason.computeIfAbsent(season,k->new ArrayList<>()).add(e);} ArrayList<String> names=new ArrayList<>(bySeason.keySet());Collections.sort(names,(a,b)->Integer.compare(seasonNumber(a),seasonNumber(b)));
        addTitle("Temporadas",18); GridLayout grid=new GridLayout(this); int cols=compact?3:4;grid.setColumnCount(cols);int screenDp=getResources().getConfiguration().screenWidthDp;int available=Math.max(480,screenDp-navWidth-70);int w=Math.max(150,available/cols-12);
        for(String season:names){List<MediaEntry> eps=bySeason.get(season);Button folder=button("▣  "+season+"\n"+eps.size()+" episódios");folder.setTextColor(GOLD);folder.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);folder.setPadding(dp(14),0,dp(8),0);folder.setOnClickListener(v->showEpisodeList(series,season,episodes,eps));GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=dp(w);gp.height=dp(compact?72:82);gp.setMargins(dp(4),dp(4),dp(6),dp(6));grid.addView(folder,gp);} content.addView(grid,new LinearLayout.LayoutParams(-1,-2));
    }

    int seasonNumber(String name){
        if(name==null)return 9999; String digits=name.replaceAll("[^0-9]",""); if(digits.isEmpty())return 9999; try{return Integer.parseInt(digits);}catch(Exception e){return 9999;}
    }

    void showEpisodeList(MediaEntry series,String season,List<MediaEntry> allEpisodes,List<MediaEntry> seasonEpisodes){
        clear(series.name+" • "+season); LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);Button back=button("←  TEMPORADAS");back.setTextColor(GOLD);back.setOnClickListener(v->showSeasonFolders(series,allEpisodes));head.addView(back,new LinearLayout.LayoutParams(dp(compact?155:200),dp(46)));TextView title=text(series.name+"  •  "+season,compact?16:21);title.setTypeface(null,1);title.setPadding(dp(14),0,0,0);head.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));content.addView(head,new LinearLayout.LayoutParams(-1,dp(54)));
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);int num=1;for(MediaEntry e:seasonEpisodes){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(5),dp(8),dp(5));row.setBackground(box(Color.rgb(12,13,14),10,Color.rgb(79,59,20),1));row.setClickable(true);row.setFocusable(true);ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);thumb.setImageResource(R.drawable.aureon_logo);if(e.poster!=null&&!e.poster.isEmpty())loadImage(e.poster,thumb);row.addView(thumb,new LinearLayout.LayoutParams(dp(compact?92:120),dp(compact?58:72)));LinearLayout texts=new LinearLayout(this);texts.setOrientation(LinearLayout.VERTICAL);texts.setPadding(dp(12),0,0,0);TextView ep=text(e.name==null||e.name.isEmpty()?"Episódio "+num:e.name,compact?11:14);ep.setTypeface(null,1);texts.addView(ep,new LinearLayout.LayoutParams(-1,dp(30)));TextView play=text("▶  Reproduzir",compact?9:11);play.setTextColor(GOLD);texts.addView(play,new LinearLayout.LayoutParams(-1,dp(24)));row.addView(texts,new LinearLayout.LayoutParams(0,-1,1));row.setOnClickListener(v->{setPlayerQueue(seasonEpisodes,e);play(e);});row.setOnFocusChangeListener((v,has)->v.setBackground(box(has?Color.rgb(38,29,14):Color.rgb(12,13,14),10,has?GOLD:Color.rgb(79,59,20),has?2:1)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(compact?70:84));lp.bottomMargin=dp(6);list.addView(row,lp);num++;}content.addView(list,new LinearLayout.LayoutParams(-1,-2));
    }

    List<MediaEntry> loadXtreamLive(XtreamCreds x) throws Exception{ return loadXtreamLive(x,loadXtreamCategoriesSafe(x,"get_live_categories")); }
    List<MediaEntry> loadXtreamLive(XtreamCreds x,Map<String,String> cats) throws Exception{
        JSONArray a=new JSONArray(httpText(api(x,"get_live_streams"))); ArrayList<MediaEntry> out=new ArrayList<>();
        for(int i=0;i<a.length()&&out.size()<MAX_ITEMS;i++){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;String id=o.optString("stream_id","");String name=o.optString("name","Canal");String cid=o.optString("category_id","");String g=cats.containsKey(cid)?cats.get(cid):(cid.isEmpty()?"Outros":"Categoria "+cid);String u=x.server+"/live/"+encPath(x.user)+"/"+encPath(x.pass)+"/"+id+".ts";String poster=o.optString("stream_icon","");String rating=o.optString("rating","");String added=o.optString("added","");out.add(new MediaEntry(id,name,u,g,"ts",LIVE,poster,rating,"",added));
        }
        return out;
    }

    List<MediaEntry> loadXtreamMovies(XtreamCreds x) throws Exception{ return loadXtreamMovies(x,loadXtreamCategoriesSafe(x,"get_vod_categories")); }
    List<MediaEntry> loadXtreamMovies(XtreamCreds x,Map<String,String> cats) throws Exception{
        JSONArray a=new JSONArray(httpText(api(x,"get_vod_streams"))); ArrayList<MediaEntry> out=new ArrayList<>();
        for(int i=0;i<a.length()&&out.size()<MAX_ITEMS;i++){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;String id=o.optString("stream_id","");String name=o.optString("name","Filme");String cid=o.optString("category_id","");String g=cats.containsKey(cid)?cats.get(cid):(cid.isEmpty()?"Outros":"Categoria "+cid);String ext=o.optString("container_extension","mp4");String u=x.server+"/movie/"+encPath(x.user)+"/"+encPath(x.pass)+"/"+id+"."+ext;String poster=o.optString("stream_icon",o.optString("cover",""));String rating=o.optString("rating_5based",o.optString("rating",""));String year=o.optString("year","");if(year.isEmpty()){String rd=o.optString("releaseDate",o.optString("releasedate",""));if(rd.length()>=4)year=rd.substring(0,4);}String added=o.optString("added","");out.add(new MediaEntry(id,name,u,g,ext,MOVIE,poster,rating,year,added));
        }
        return out;
    }

    List<MediaEntry> loadXtreamSeries(XtreamCreds x) throws Exception{ return loadXtreamSeries(x,loadXtreamCategoriesSafe(x,"get_series_categories")); }
    List<MediaEntry> loadXtreamSeries(XtreamCreds x,Map<String,String> cats) throws Exception{
        JSONArray a=new JSONArray(httpText(api(x,"get_series"))); ArrayList<MediaEntry> out=new ArrayList<>();
        for(int i=0;i<a.length()&&out.size()<MAX_ITEMS;i++){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;String id=o.optString("series_id","");String name=o.optString("name","Série");String cid=o.optString("category_id","");String g=cats.containsKey(cid)?cats.get(cid):(cid.isEmpty()?"Outros":"Categoria "+cid);String poster=o.optString("cover",o.optString("stream_icon",""));String rating=o.optString("rating_5based",o.optString("rating",""));String year=o.optString("year","");if(year.isEmpty()){String rd=o.optString("releaseDate",o.optString("last_modified",""));if(rd.length()>=4&&!rd.matches("\\d+"))year=rd.substring(0,4);}String added=o.optString("last_modified",o.optString("added",""));out.add(new MediaEntry(id,name,null,g,"",SERIES,poster,rating,year,added));
        }
        return out;
    }

    List<MediaEntry> loadXtreamEpisodes(XtreamCreds x,MediaEntry series) throws Exception{
        String action="get_series_info&series_id="+enc(series.id); JSONObject root=new JSONObject(httpText(api(x,action))); JSONObject eps=root.optJSONObject("episodes"); ArrayList<MediaEntry> out=new ArrayList<>(); if(eps==null)return out;
        ArrayList<String> seasons=new ArrayList<>(); Iterator<String> it=eps.keys(); while(it.hasNext())seasons.add(it.next()); Collections.sort(seasons,(a,b)->{try{return Integer.compare(Integer.parseInt(a),Integer.parseInt(b));}catch(Exception e){return a.compareToIgnoreCase(b);}});
        for(String season:seasons){JSONArray ar=eps.optJSONArray(season);if(ar==null)continue;for(int i=0;i<ar.length();i++){JSONObject o=ar.optJSONObject(i);if(o==null)continue;String id=o.optString("id","");String title=o.optString("title","Episódio "+(i+1));String ext=o.optString("container_extension","mp4");String u=x.server+"/series/"+encPath(x.user)+"/"+encPath(x.pass)+"/"+id+"."+ext;JSONObject info=o.optJSONObject("info");String poster=info==null?series.poster:info.optString("movie_image",series.poster);String added=o.optString("added","");out.add(new MediaEntry(id,title,u,"Temporada "+season,ext,MOVIE,poster,"","",added));}}
        return out;
    }

    LinkedHashMap<String,String> loadXtreamCategories(XtreamCreds x,String action) throws Exception{ JSONArray a=new JSONArray(httpText(api(x,action))); LinkedHashMap<String,String> m=new LinkedHashMap<>(); for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null){String id=o.optString("category_id","");String name=o.optString("category_name","Outros").trim();if(!id.isEmpty()&&!name.isEmpty())m.put(id,name);}} return m; }
    LinkedHashMap<String,String> loadXtreamCategoriesSafe(XtreamCreds x,String action){ try{return loadXtreamCategories(x,action);}catch(Exception e){return new LinkedHashMap<>();} }

    String encPath(String s){ return Uri.encode(s); }
    void sortEntries(List<MediaEntry> l){ Collections.sort(l,Comparator.comparing((MediaEntry e)->e.group==null?"":e.group,String.CASE_INSENSITIVE_ORDER).thenComparing(e->e.name==null?"":e.name,String.CASE_INSENSITIVE_ORDER)); }

    List<MediaEntry> loadFromUri(Uri uri) throws Exception{
        String name=getFileName(uri); prefs.edit().putString("file_name",name).putString("file_uri",uri.toString()).apply(); InputStream in=getContentResolver().openInputStream(uri); if(in==null)throw new IOException("arquivo não pôde ser aberto");
        try(BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"))){return parseReader(r);}
    }

    List<MediaEntry> loadFromUrl(String s) throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(s).openConnection(); c.setInstanceFollowRedirects(true); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setRequestProperty("User-Agent","Aureon/32.0"); c.setRequestProperty("Accept","*/*"); c.setRequestProperty("Accept-Encoding","gzip");
        int code=c.getResponseCode(); if(code<200||code>=400){c.disconnect();throw new IOException("HTTP "+code);} InputStream in=c.getInputStream(); String ce=c.getContentEncoding(); if(ce!=null&&ce.toLowerCase(Locale.US).contains("gzip"))in=new GZIPInputStream(in);
        try(BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"))){return parseReader(r);} finally{c.disconnect();}
    }

    String httpText(String s) throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(s).openConnection(); c.setInstanceFollowRedirects(true); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setRequestProperty("User-Agent","Aureon/32.0"); c.setRequestProperty("Accept","*/*"); c.setRequestProperty("Accept-Encoding","gzip");
        int code=c.getResponseCode(); if(code<200||code>=400){c.disconnect();throw new IOException("HTTP "+code);} InputStream in=c.getInputStream(); String ce=c.getContentEncoding(); if(ce!=null&&ce.toLowerCase(Locale.US).contains("gzip"))in=new GZIPInputStream(in);
        ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n; while((n=in.read(buf))!=-1)out.write(buf,0,n); in.close(); c.disconnect(); return out.toString("UTF-8");
    }

    String getFileName(Uri uri){ try{Cursor c=getContentResolver().query(uri,null,null,null,null);if(c!=null){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(c.moveToFirst()&&i>=0){String n=c.getString(i);c.close();return n;}c.close();}}catch(Exception ignored){} String p=uri.getLastPathSegment();return p==null?"arquivo M3U":p; }

    List<MediaEntry> parseReader(BufferedReader r) throws Exception{
        ArrayList<MediaEntry> out=new ArrayList<>(); String name=null,group="Geral",poster="",line;
        while((line=r.readLine())!=null&&out.size()<MAX_ITEMS){String l=line.trim();if(l.startsWith("#EXTINF")){int comma=l.indexOf(',');name=comma>=0?l.substring(comma+1).trim():"Canal";group=attr(l,"group-title");if(group.isEmpty())group="Geral";poster=attr(l,"tvg-logo");}else if(!l.startsWith("#")&&!l.isEmpty()&&name!=null){int kind=classifyPlaylistItem(name,group,l);String ext=extension(l);out.add(new MediaEntry("",name,l,group,ext,kind,poster,"","",""));name=null;group="Geral";poster="";}}
        sortEntries(out);return out;
    }

    String attr(String l,String key){String needle=key+"=\"";int a=l.indexOf(needle);if(a<0)return "";int b=l.indexOf('"',a+needle.length());return b>a?l.substring(a+needle.length(),b):"";}
    String extension(String url){String x=url.toLowerCase(Locale.US);int q=x.indexOf('?');if(q>=0)x=x.substring(0,q);int dot=x.lastIndexOf('.');return dot>=0?x.substring(dot+1):"";}
    int classifyPlaylistItem(String name,String group,String url){
        String u=url==null?"":url.toLowerCase(Locale.US);
        String meta=((name==null?"":name)+" "+(group==null?"":group)).toLowerCase(Locale.US);

        // O link real tem prioridade. Uma categoria AO VIVO chamada "Filmes" ou "Séries" continua em TV Ao Vivo.
        if(u.contains("/live/")) return LIVE;
        if(u.contains("/movie/")) return MOVIE;
        if(u.contains("/series/")) return SERIES;

        String ext=extension(u);
        if(ext.equals("ts")||ext.equals("m3u8")||ext.equals("m3u")||ext.equals("mpegts")) return LIVE;

        boolean episodeLike=meta.contains("series")||meta.contains("séries")||meta.contains("serie")||meta.contains("temporada")||meta.contains("season")||meta.contains("episodio")||meta.contains("episódio")||meta.matches(".*\\bs\\d{1,2}e\\d{1,3}\\b.*");
        if((ext.equals("mp4")||ext.equals("mkv")||ext.equals("avi")||ext.equals("mov")||ext.equals("wmv")) && episodeLike) return SERIES;
        if(ext.equals("mp4")||ext.equals("mkv")||ext.equals("avi")||ext.equals("mov")||ext.equals("wmv")) return MOVIE;

        // Fallback para listas que não trazem /live/, /movie/ ou /series/ na URL.
        if(episodeLike) return SERIES;
        if(meta.contains("filme")||meta.contains("movie")||meta.contains("vod")||meta.contains("cinema")) return MOVIE;
        return LIVE;
    }

    class ChannelRecyclerAdapter extends RecyclerView.Adapter<ChannelRecyclerAdapter.Holder>{
        final ArrayList<MediaEntry> data=new ArrayList<>();
        ChannelRecyclerAdapter(){setHasStableIds(true);}
        void submit(List<MediaEntry> items){data.clear();if(items!=null)data.addAll(items);notifyDataSetChanged();}
        @Override public long getItemId(int position){return PlaybackStore.key(data.get(position)).hashCode();}
        @Override public Holder onCreateViewHolder(android.view.ViewGroup parent,int viewType){FrameLayout frame=new FrameLayout(MainActivity.this);frame.setFocusable(false);frame.setDescendantFocusability(android.view.ViewGroup.FOCUS_AFTER_DESCENDANTS);frame.setLayoutParams(new RecyclerView.LayoutParams(-1,dp(compact?56:64)));return new Holder(frame);}
        @Override public void onBindViewHolder(Holder h,int position){FrameLayout frame=(FrameLayout)h.itemView;frame.removeAllViews();LinearLayout row=makeLiveRow(data.get(position));frame.addView(row,new FrameLayout.LayoutParams(-1,-1));}
        @Override public void onViewRecycled(Holder h){((FrameLayout)h.itemView).removeAllViews();}
        @Override public int getItemCount(){return data.size();}
        class Holder extends RecyclerView.ViewHolder{Holder(View v){super(v);}}
    }

    class MediaRecyclerAdapter extends RecyclerView.Adapter<MediaRecyclerAdapter.Holder>{
        final ArrayList<MediaEntry> data=new ArrayList<>(); final int cols;
        MediaRecyclerAdapter(int cols){this.cols=cols;setHasStableIds(true);}
        void submit(List<MediaEntry> items){data.clear();if(items!=null)data.addAll(items);notifyDataSetChanged();}
        @Override public long getItemId(int position){return PlaybackStore.key(data.get(position)).hashCode();}
        @Override public Holder onCreateViewHolder(android.view.ViewGroup parent,int viewType){FrameLayout frame=new FrameLayout(MainActivity.this);frame.setFocusable(false);frame.setDescendantFocusability(android.view.ViewGroup.FOCUS_AFTER_DESCENDANTS);return new Holder(frame);}
        @Override public void onBindViewHolder(Holder h,int position){
            int screenDp=getResources().getConfiguration().screenWidthDp;int catW=compact?225:285;int usable=Math.max(380,screenDp-(navHidden?0:navWidth)-catW-70);int cardW=Math.max(compact?118:145,usable/cols-8);int posterH=(int)(cardW*1.42f);
            FrameLayout frame=(FrameLayout)h.itemView;frame.removeAllViews();LinearLayout card=makePosterCard(data.get(position),cardW,posterH);frame.addView(card,new FrameLayout.LayoutParams(-1,-1));RecyclerView.LayoutParams lp=new RecyclerView.LayoutParams(dp(cardW),dp(posterH+(compact?62:72)));lp.setMargins(dp(4),dp(4),dp(4),dp(8));frame.setLayoutParams(lp);
        }
        @Override public void onViewRecycled(Holder h){((FrameLayout)h.itemView).removeAllViews();}
        @Override public int getItemCount(){return data.size();}
        class Holder extends RecyclerView.ViewHolder{Holder(View v){super(v);}}
    }

    void showInfo(String s){ currentSectionRequest=-1; clear("ÁUREON"); TextView t=text(s,compact?13:16);t.setTextColor(MUTED);t.setGravity(Gravity.CENTER);content.addView(t,new LinearLayout.LayoutParams(-1,dp(130)));Button b=button("⚙ CONFIGURAÇÕES");b.setTextColor(GOLD);b.setOnClickListener(v->showSetup());content.addView(b,new LinearLayout.LayoutParams(-1,dp(52))); }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==77&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){selectedM3u=data.getData();try{int flags=data.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION;getContentResolver().takePersistableUriPermission(selectedM3u,flags);}catch(Exception ignored){}prefs.edit().putString("file_uri",selectedM3u.toString()).putString("source_mode","file").apply();showSetup();}}
    @Override protected void onStop(){
        super.onStop();
        if(previewPlayer!=null) previewPlayer.pause();
    }

    @Override protected void onStart(){
        super.onStart();
        if(previewPlayer!=null) previewPlayer.play();
    }

    @Override public void onBackPressed(){
        if(detailScreenKind>=LIVE&&detailScreenKind<=SERIES){returnToSection(detailScreenKind);return;}
        if("Adicionar Playlist".equals(activeScreen)||"QR Code / Dispositivo".equals(activeScreen)){showSetup();return;}
        if(!"Início".equals(activeScreen)){showHome();return;}
        super.onBackPressed();
    }

    @Override public void onTrimMemory(int level){
        super.onTrimMemory(level);
        if(level>=android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL){
            imageCache.evictAll();
            detailCache.clear(); epgCache.clear();
        }else if(level>=android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW){
            try{imageCache.trimToSize(Math.max(2*1024*1024,imageCache.maxSize()/2));}catch(Exception ignored){}
        }
    }

    @Override public void onLowMemory(){
        super.onLowMemory();
        imageCache.evictAll(); detailCache.clear(); epgCache.clear();
    }

    @Override protected void onDestroy(){
        uiHandler.removeCallbacks(prepareStartupTask);
        uiHandler.removeCallbacks(finishStartupTask);
        releasePreviewPlayer();
        exec.shutdownNow(); dataExec.shutdownNow(); imageExec.shutdownNow(); cacheExec.shutdown(); super.onDestroy();
    }
}
