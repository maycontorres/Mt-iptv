# ÁUREON V35.10

- Corrige textos, código do aparelho e PIN cortados em telefones no modo paisagem.
- Mantém o código do aparelho em uma única linha.
- Reduz automaticamente os elementos quando a altura da tela é pequena.
- Exibe o botão **ENTRAR E CONECTAR** abaixo dos campos de usuário/senha ou M3U.
- Encurta os textos dos campos no celular para evitar cortes.
