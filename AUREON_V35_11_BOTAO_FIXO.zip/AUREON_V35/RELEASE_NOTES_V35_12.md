# ÁUREON 35.12 — estabilidade e desempenho

- A tela aberta pelo usuário agora tem prioridade sobre o pré-carregamento.
- Removido o carregamento simultâneo agressivo de TV, Filmes e Séries.
- TV ao vivo é aquecida primeiro e as demais seções carregam gradualmente.
- Limite total de resposta de rede para impedir carregamento infinito.
- Mensagem clara e botão **Tentar novamente** quando o servidor demora.
- Menor uso simultâneo de processador, memória e internet em aparelhos modestos.

