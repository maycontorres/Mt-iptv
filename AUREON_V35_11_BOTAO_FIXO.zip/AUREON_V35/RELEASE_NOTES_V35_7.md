# ÁUREON V35.7 — Duas formas de adicionar a lista

- Opção 1: ativação pelo site com QR Code, código do aparelho e PIN.
- Opção 2: cadastro direto no aplicativo pelo controle remoto.
- O cadastro direto mantém as telas separadas para Xtream Codes e link M3U.
- O botão manual ficou maior e destacado para não ficar escondido na TV.
- Mantém o preview automático de canais e OK para tela cheia da V35.6.
- versionCode 43 / versionName 35.7.
