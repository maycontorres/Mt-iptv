# ÁUREON 35.13 — player estável

- Restaurado o núcleo de reprodução local estável utilizado na V34.
- Corrigida a troca indevida para CastPlayer sem sessão Chromecast ativa.
- Chromecast temporariamente desativado para priorizar estabilidade.
- Mantidas as otimizações de carregamento e timeout da versão 35.12.
- Mantidos ativação pelo site, entrada direta, preview e demais funções atuais.

