# ÁUREON V35.6 — Preview na lista de canais

- Ao abrir TV Ao Vivo, o primeiro canal começa automaticamente no painel da direita.
- Ao mover o foco, o preview troca para o canal destacado.
- OK no canal abre diretamente em tela cheia.
- O painel da direita também aceita OK/toque para abrir em tela cheia.
- Os botões Voltar, Favorito, Tela Cheia e Mais agora funcionam com o canal do preview.
- versionCode 42 / versionName 35.6.
