# ÁUREON V35.9 — Site e cadastro direto lado a lado

- A primeira tela agora mostra duas áreas visíveis ao mesmo tempo.
- Opção 1: QR Code, código do aparelho e PIN para ativação pelo site.
- Opção 2: cadastro direto no app, ao lado do QR Code.
- O cadastro direto possui abas separadas para Usuário e Senha (Xtream) e Link M3U.
- Campos Xtream: servidor, usuário e senha.
- Campo M3U: link completo M3U/M3U8.
- Mantém a correção do primeiro carregamento de TV Ao Vivo.
- versionCode 45 / versionName 35.9.
