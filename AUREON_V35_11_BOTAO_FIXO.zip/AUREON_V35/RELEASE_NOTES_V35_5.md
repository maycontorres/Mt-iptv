# ÁUREON V35.5 — Ativação pelo site

- Primeiro uso sem catálogo ou imagens demonstrativas.
- Código exclusivo no formato `XXXX-XXXX-XXXX`.
- PIN de 6 números para conectar a lista com segurança.
- Cadastro remoto separado para Xtream Codes e link M3U.
- Sincronização automática a cada poucos segundos.
- Credenciais recebidas são protegidas pelo Android Keystore.
- Opção de cadastro manual mantida para aparelhos sem acesso ao portal.
- versionCode 41 / versionName 35.5.

## Fluxo

1. Instale e abra o aplicativo.
2. Anote o código e o PIN mostrados na TV.
3. Abra o endereço informado na tela pelo celular.
4. Escolha Xtream ou M3U e confirme.
5. A Home real abre automaticamente quando a lista chegar.
