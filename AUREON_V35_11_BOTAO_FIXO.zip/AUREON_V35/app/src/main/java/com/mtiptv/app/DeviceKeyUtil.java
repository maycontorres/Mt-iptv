package com.mtiptv.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.security.SecureRandom;
import java.util.Locale;
import java.util.UUID;

final class DeviceKeyUtil {
    private static final String DEVICE_CODE = "activation_device_code_v1";
    private static final String DEVICE_PIN = "activation_device_pin_v1";
    private static final String DEVICE_TOKEN = "activation_device_token_v1";

    static String key(Context c) {
        SharedPreferences p=AppPrefs.get(c);
        String value=p.getString(DEVICE_CODE,"");
        if(value!=null&&value.matches("[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}"))return value;
        final String alphabet="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        SecureRandom random=new SecureRandom();StringBuilder raw=new StringBuilder();
        for(int i=0;i<12;i++)raw.append(alphabet.charAt(random.nextInt(alphabet.length())));
        value=raw.substring(0,4)+"-"+raw.substring(4,8)+"-"+raw.substring(8,12);
        p.edit().putString(DEVICE_CODE,value).apply();return value;
    }

    static String pin(Context c){
        SharedPreferences p=AppPrefs.get(c);String value=p.getString(DEVICE_PIN,"");
        if(value!=null&&value.matches("\\d{6}"))return value;
        value=String.format(Locale.US,"%06d",new SecureRandom().nextInt(1000000));
        p.edit().putString(DEVICE_PIN,value).apply();return value;
    }

    static String token(Context c){
        SharedPreferences p=AppPrefs.get(c);String value=p.getString(DEVICE_TOKEN,"");
        if(value!=null&&!value.isEmpty())try{return CredentialStore.unprotect(value);}catch(Exception ignored){}
        String token=UUID.randomUUID().toString()+"-"+UUID.randomUUID().toString();
        try{p.edit().putString(DEVICE_TOKEN,CredentialStore.protect(token)).apply();}
        catch(Exception e){throw new IllegalStateException("Não foi possível proteger a chave deste aparelho.",e);}
        return token;
    }

    private DeviceKeyUtil(){}
}
