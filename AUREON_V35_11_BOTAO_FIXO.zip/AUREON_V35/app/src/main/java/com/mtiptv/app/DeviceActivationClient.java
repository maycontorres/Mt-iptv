package com.mtiptv.app;

import android.content.Context;
import org.json.JSONObject;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

final class DeviceActivationClient {
    private static final String BASE="https://whhamqkjfbowjrjjqpxi.supabase.co/functions/v1/aureon-device";
    private static final MediaType JSON=MediaType.get("application/json; charset=utf-8");
    private final Context context;
    private final OkHttpClient http=new OkHttpClient.Builder().connectTimeout(12,TimeUnit.SECONDS).readTimeout(15,TimeUnit.SECONDS).build();

    interface Listener { void onResult(JSONObject result); void onError(String message); }
    DeviceActivationClient(Context context){this.context=context.getApplicationContext();}

    void register(Listener listener){
        try{
            JSONObject body=identity();
            body.put("pin",DeviceKeyUtil.pin(context));
            body.put("app_version",BuildConfig.VERSION_NAME);
            post("/register",body,listener);
        }catch(Exception e){listener.onError("Não foi possível preparar a ativação.");}
    }

    void sync(Listener listener){
        try{post("/sync",identity(),listener);}
        catch(Exception e){listener.onError("Não foi possível consultar a ativação.");}
    }

    private JSONObject identity() throws Exception {
        return new JSONObject().put("device_code",DeviceKeyUtil.key(context)).put("device_token",DeviceKeyUtil.token(context));
    }

    private void post(String route,JSONObject json,Listener listener){
        Request request=new Request.Builder().url(BASE+route).post(RequestBody.create(json.toString(),JSON)).build();
        http.newCall(request).enqueue(new Callback(){
            @Override public void onFailure(Call call,IOException e){listener.onError("Sem conexão com o servidor de ativação.");}
            @Override public void onResponse(Call call,Response response){
                try(Response r=response){
                    String raw=r.body()==null?"{}":r.body().string();
                    JSONObject result=new JSONObject(raw);
                    if(!r.isSuccessful())listener.onError(message(result.optString("error","")));
                    else listener.onResult(result);
                }catch(Exception e){listener.onError("Resposta inválida do servidor de ativação.");}
            }
        });
    }

    private String message(String code){
        if("device_blocked".equals(code))return "Este aparelho foi bloqueado.";
        if("device_expired".equals(code))return "A ativação deste aparelho expirou.";
        if("invalid_device_token".equals(code))return "A identificação segura deste aparelho não confere.";
        return "O servidor de ativação está temporariamente indisponível.";
    }
}
