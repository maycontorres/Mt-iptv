# ÁUREON V35.8 — Correção do primeiro carregamento

- TV Ao Vivo atualiza automaticamente quando o carregamento em segundo plano termina.
- Não é mais necessário abrir Filmes e voltar para os canais aparecerem.
- Corrige a disputa entre o pré-carregamento da Home e a abertura da seção TV Ao Vivo.
- Mantém ativação pelo site, cadastro direto no app e preview automático.
- versionCode 44 / versionName 35.8.
