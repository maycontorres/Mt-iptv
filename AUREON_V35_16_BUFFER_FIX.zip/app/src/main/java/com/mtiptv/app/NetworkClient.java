package com.mtiptv.app;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/** Shared HTTP stack with consistent timeouts and transport checks. */
final class NetworkClient {
    // Requisições curtas: autenticação, categorias, listas e EPG.
    private static final OkHttpClient API_CLIENT = new OkHttpClient.Builder()
            .callTimeout(28, TimeUnit.SECONDS)
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(22, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .build();

    // Transmissões são conexões longas. Nunca aplicar callTimeout/readTimeout
    // de API aqui: isso encerrava canais ao vivo durante a reprodução.
    private static final OkHttpClient STREAM_CLIENT = new OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            // Se o servidor mantiver o socket aberto sem enviar vídeo, gere um
            // erro recuperável em vez de deixar o círculo girando para sempre.
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .callTimeout(0, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .build();

    static String getText(String url) throws IOException {
        TransportPolicy.requireAllowed(url);
        Request request = new Request.Builder()
                .url(url)
                .header("User-Agent", "Aureon/35.16")
                .header("Accept", "*/*")
                .build();
        try (Response response = API_CLIENT.newCall(request).execute()) {
            if (!response.isSuccessful()) throw new IOException("HTTP " + response.code());
            ResponseBody body = response.body();
            if (body == null) throw new IOException("Resposta vazia");
            return body.string();
        }
    }

    static OkHttpClient client() { return STREAM_CLIENT; }

    private NetworkClient() {}
}
