package com.mtiptv.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.cast.CastPlayer;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.okhttp.OkHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.TrackSelectionDialogBuilder;
import androidx.mediarouter.app.MediaRouteButton;
import com.google.android.gms.cast.framework.CastButtonFactory;
import com.google.android.gms.cast.framework.CastContext;

import java.util.ArrayList;
import java.util.List;

@UnstableApi
public class PlayerActivity extends Activity {
    private Player player;
    private ExoPlayer localPlayer;
    private CastPlayer castPlayer;
    private ProgressBar loading;
    private PlayerView playerView;
    private TextView title;
    private FrameLayout root;
    private MediaRouteButton castButton;
    private StreamRecorder recorder;

    private static final long TITLE_TIMEOUT_MS = 2500L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable hideTitle = () -> { if (title != null) title.setVisibility(View.GONE); };

    private int currentKind = MainActivity.MOVIE;
    private ArrayList<MediaEntry> queue = new ArrayList<>();
    private MediaEntry currentEntry;
    private String initialUrl = "", initialName = "";
    private int reconnectAttempts = 0;
    private boolean resumeApplied = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        AppCrashReporter.install(this);
        enterImmersiveMode();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        initialUrl = getIntent().getStringExtra("url"); if (initialUrl == null) initialUrl = "";
        initialName = getIntent().getStringExtra("name"); if (initialName == null) initialName = getString(R.string.app_name);
        currentKind = getIntent().getIntExtra("kind", MainActivity.MOVIE);

        setContentView(R.layout.activity_player);
        root = findViewById(R.id.player_root);
        playerView = findViewById(R.id.player_view);
        loading = findViewById(R.id.player_loading);
        title = findViewById(R.id.player_title);
        View liveBadge = findViewById(R.id.live_badge);
        if (liveBadge != null) liveBadge.setVisibility(View.GONE); // V35: sem aba AO VIVO na tela cheia.
        title.setText(initialName);
        recorder = new StreamRecorder(this);

        playerView.setUseController(true);
        playerView.setKeepScreenOn(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        playerView.setControllerAutoShow(true);
        playerView.setControllerHideOnTouch(true);
        playerView.setControllerShowTimeoutMs(2500);
        // Migra instalações antigas que iniciavam em Zoom e cortavam a transmissão.
        if (!AppPrefs.get(this).getBoolean("player_fit_default_v353", false)) {
            AppPrefs.get(this).edit()
                    .putInt("player_resize_mode", AspectRatioFrameLayout.RESIZE_MODE_FIT)
                    .putBoolean("player_fit_default_v353", true)
                    .apply();
        }
        applyResizeMode();
        playerView.setControllerVisibilityListener((PlayerView.ControllerVisibilityListener) visibility -> {
            if (visibility == View.VISIBLE) showTitleTemporarily();
        });

        root.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN &&
                    (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) && event.getRepeatCount() >= 1) {
                showPlayerMenu(); return true;
            }
            if (event.getAction() != KeyEvent.ACTION_UP) return false;
            if (keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_INFO || keyCode == KeyEvent.KEYCODE_SETTINGS) {
                showPlayerMenu(); return true;
            }
            if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
                if (player != null && player.hasNextMediaItem()) player.seekToNextMediaItem();
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
                if (player != null && player.hasPreviousMediaItem()) player.seekToPreviousMediaItem();
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
                if (playerView.isControllerFullyVisible()) playerView.hideController(); else playerView.showController();
                return true;
            }
            return false;
        });
        root.requestFocus();
        showTitleTemporarily();

        OkHttpDataSource.Factory httpFactory = new OkHttpDataSource.Factory(NetworkClient.client()).setUserAgent("Aureon/35.16");
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(currentKind == MainActivity.LIVE ? 12000 : 8000,
                        currentKind == MainActivity.LIVE ? 60000 : 45000,
                        currentKind == MainActivity.LIVE ? 2500 : 1000,
                        currentKind == MainActivity.LIVE ? 6000 : 2200)
                .setPrioritizeTimeOverSizeThresholds(true).build();

        localPlayer = new ExoPlayer.Builder(this)
                .setLoadControl(loadControl)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(httpFactory)).build();
        localPlayer.setHandleAudioBecomingNoisy(true);
        // Reprodução local estável (mesmo núcleo usado na V34). A V35 trocava
        // para CastPlayer mesmo sem uma sessão Chromecast ativa, o que podia
        // deixar canais ao vivo em buffering ou sem reprodução em alguns aparelhos.
        player = localPlayer;
        castPlayer = null;
        castButton = null;
        playerView.setPlayer(player);

        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                loading.setVisibility(state == Player.STATE_BUFFERING || state == Player.STATE_IDLE ? View.VISIBLE : View.GONE);
                if (state == Player.STATE_READY) { reconnectAttempts = 0; playerView.hideController(); }
                if (state == Player.STATE_ENDED) saveProgressNow();
            }
            @Override public void onMediaItemTransition(MediaItem mediaItem, int reason) {
                saveProgressNow(); resumeApplied = false;
                int index = player.getCurrentMediaItemIndex(); MainActivity.setPlayerQueueIndex(index);
                if (index >= 0 && index < queue.size()) currentEntry = queue.get(index);
                else currentEntry = new MediaEntry("", mediaItem == null ? initialName : String.valueOf(mediaItem.mediaMetadata.title), initialUrl, "", "", currentKind);
                if (currentEntry != null) { currentKind = currentEntry.kind; PlaybackStore.markRecent(PlayerActivity.this, currentEntry); title.setText(currentEntry.name == null ? getString(R.string.app_name) : currentEntry.name); }
                applyResumeIfNeeded(); showTitleTemporarily();
            }
            @Override public void onPlayerError(PlaybackException error) {
                AppCrashReporter.record(PlayerActivity.this, error); loading.setVisibility(View.VISIBLE);
                if (reconnectAttempts < 3) {
                    reconnectAttempts++; long delay = 800L * (1L << (reconnectAttempts - 1));
                    Toast.makeText(PlayerActivity.this, getString(R.string.reconnecting, reconnectAttempts, 3), Toast.LENGTH_SHORT).show();
                    handler.postDelayed(PlayerActivity.this::retryCurrent, delay);
                } else {
                    loading.setVisibility(View.GONE);
                    new AlertDialog.Builder(PlayerActivity.this).setTitle("Falha no player interno")
                            .setMessage("O ÁUREON tentou reconectar. Você pode tentar em um player externo instalado no aparelho.")
                            .setNegativeButton("Fechar",null).setPositiveButton("PLAYER EXTERNO",(d,w)->openExternal()).show();
                }
            }
        });
        playQueueOrSingle(initialUrl, initialName, currentKind);
    }

    private void showPlayerMenu() {
        ArrayList<String> opts=new ArrayList<>();
        opts.add("Formato da tela (Zoom/Fit/Preencher)");
        opts.add("Áudio"); opts.add("Legendas"); opts.add("Velocidade"); opts.add("Player externo");
        if (castButton != null) opts.add("Chromecast");
        if (currentKind == MainActivity.LIVE) { opts.add("Multi-Screen"); opts.add(recorder.isRecording()?"Parar gravação":"Gravar TV ao vivo"); }
        String[] arr=opts.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Opções do player").setItems(arr,(d,which)->{
            String x=arr[which];
            if(x.startsWith("Formato"))cycleResizeMode();
            else if(x.equals("Áudio"))showTracks(C.TRACK_TYPE_AUDIO,"Áudio");
            else if(x.equals("Legendas"))showTracks(C.TRACK_TYPE_TEXT,"Legendas");
            else if(x.equals("Velocidade"))showSpeed();
            else if(x.equals("Player externo"))openExternal();
            else if(x.equals("Chromecast"))openCastChooser();
            else if(x.equals("Multi-Screen"))startActivity(new android.content.Intent(this,MultiScreenActivity.class));
            else if(x.contains("gravação")||x.startsWith("Gravar"))toggleRecording();
        }).show();
    }

    private void showTracks(int type,String label){try{new TrackSelectionDialogBuilder(this,label,player,type).setShowDisableOption(type==C.TRACK_TYPE_TEXT).build().show();}catch(Throwable e){Toast.makeText(this,"Nenhuma opção de "+label.toLowerCase()+" disponível.",Toast.LENGTH_SHORT).show();}}
    private void showSpeed(){final float[] values={0.5f,0.75f,1f,1.25f,1.5f,2f};String[] labels={"0.5x","0.75x","1.0x (normal)","1.25x","1.5x","2.0x"};new AlertDialog.Builder(this).setTitle("Velocidade").setItems(labels,(d,w)->{if(player!=null)player.setPlaybackSpeed(values[w]);}).show();}
    private void cycleResizeMode(){int m=AppPrefs.get(this).getInt("player_resize_mode",AspectRatioFrameLayout.RESIZE_MODE_FIT);if(m==AspectRatioFrameLayout.RESIZE_MODE_ZOOM)m=AspectRatioFrameLayout.RESIZE_MODE_FIT;else if(m==AspectRatioFrameLayout.RESIZE_MODE_FIT)m=AspectRatioFrameLayout.RESIZE_MODE_FILL;else m=AspectRatioFrameLayout.RESIZE_MODE_ZOOM;AppPrefs.get(this).edit().putInt("player_resize_mode",m).apply();applyResizeMode();String n=m==AspectRatioFrameLayout.RESIZE_MODE_ZOOM?"Zoom (pode cortar)":m==AspectRatioFrameLayout.RESIZE_MODE_FIT?"Ajustar (sem cortar)":"Preencher";Toast.makeText(this,"Tela: "+n,Toast.LENGTH_SHORT).show();}
    private void applyResizeMode(){int m=AppPrefs.get(this).getInt("player_resize_mode",AspectRatioFrameLayout.RESIZE_MODE_FIT);playerView.setResizeMode(m);}
    private void openExternal(){MediaEntry e=currentEntry;ExternalPlayerUtil.open(this,e!=null?e.url:initialUrl,e!=null?e.name:initialName);}
    private void openCastChooser(){try{castButton.setVisibility(View.VISIBLE);castButton.performClick();handler.postDelayed(()->castButton.setVisibility(View.GONE),500);}catch(Throwable e){Toast.makeText(this,"Chromecast indisponível neste aparelho.",Toast.LENGTH_SHORT).show();}}
    private void toggleRecording(){if(recorder.isRecording()){recorder.stop();Toast.makeText(this,"Finalizando gravação…",Toast.LENGTH_SHORT).show();return;}String url=currentEntry!=null?currentEntry.url:initialUrl,name=currentEntry!=null?currentEntry.name:initialName;recorder.start(url,name,new StreamRecorder.Callback(){public void onStarted(String n){runOnUiThread(()->Toast.makeText(PlayerActivity.this,"Gravando: "+n,Toast.LENGTH_SHORT).show());}public void onStopped(String m){runOnUiThread(()->Toast.makeText(PlayerActivity.this,m,Toast.LENGTH_LONG).show());}public void onError(String m){runOnUiThread(()->Toast.makeText(PlayerActivity.this,m,Toast.LENGTH_LONG).show());}});}

    private void retryCurrent() { if (player == null || isFinishing()) return; try { long pos=player.getCurrentPosition();int idx=player.getCurrentMediaItemIndex();player.stop();if(idx>=0){if(currentKind==MainActivity.LIVE)player.seekToDefaultPosition(idx);else player.seekTo(idx,Math.max(0,pos));}player.prepare();player.play(); } catch (Exception error) { AppCrashReporter.record(this,error); } }
    private void applyResumeIfNeeded() { if (resumeApplied || currentEntry == null || currentEntry.kind == MainActivity.LIVE || !AppPrefs.get(this).getBoolean("resume_vod", true)) return; long saved=PlaybackStore.progressMs(this,currentEntry);if(saved>15000&&player!=null){player.seekTo(saved);Toast.makeText(this,R.string.resume_playback,Toast.LENGTH_SHORT).show();}resumeApplied=true; }
    private void saveProgressNow() { try { if (player != null && currentEntry != null) PlaybackStore.saveProgress(this,currentEntry,player.getCurrentPosition(),player.getDuration()); } catch (Exception ignored) {} }
    private void showTitleTemporarily() { if(title==null||isFinishing()||isDestroyed())return;handler.removeCallbacks(hideTitle);title.setVisibility(View.VISIBLE);handler.postDelayed(hideTitle,TITLE_TIMEOUT_MS); }

    private void playQueueOrSingle(String url,String name,int kind){currentKind=kind;queue=MainActivity.playerQueueSnapshot();int start=MainActivity.getPlayerQueueIndex();if(!queue.isEmpty()&&start>=0&&start<queue.size()){List<MediaItem> mediaItems=new ArrayList<>();ArrayList<MediaEntry> playable=new ArrayList<>();for(MediaEntry entry:queue){if(entry==null||entry.url==null||entry.url.trim().isEmpty())continue;try{TransportPolicy.requireAllowed(entry.url);}catch(Exception blocked){continue;}playable.add(entry);MediaMetadata md=new MediaMetadata.Builder().setTitle(entry.name==null?getString(R.string.app_name):entry.name).build();mediaItems.add(new MediaItem.Builder().setUri(entry.url).setMediaMetadata(md).build());}queue=playable;if(!mediaItems.isEmpty()){int safeStart=Math.min(start,mediaItems.size()-1);currentEntry=queue.get(safeStart);currentKind=currentEntry.kind;PlaybackStore.markRecent(this,currentEntry);long resume=(currentEntry.kind!=MainActivity.LIVE&&AppPrefs.get(this).getBoolean("resume_vod",true))?PlaybackStore.progressMs(this,currentEntry):C.TIME_UNSET;player.setMediaItems(mediaItems,safeStart,resume>15000?resume:C.TIME_UNSET);player.setPlayWhenReady(true);player.prepare();resumeApplied=resume>15000;return;}}
        if(url==null||url.trim().isEmpty()){loading.setVisibility(View.GONE);Toast.makeText(this,R.string.invalid_content_link,Toast.LENGTH_LONG).show();return;}try{TransportPolicy.requireAllowed(url);}catch(Exception blocked){loading.setVisibility(View.GONE);Toast.makeText(this,blocked.getMessage(),Toast.LENGTH_LONG).show();return;}currentEntry=new MediaEntry("",name,url,"","",kind);PlaybackStore.markRecent(this,currentEntry);MediaMetadata md=new MediaMetadata.Builder().setTitle(name==null?getString(R.string.app_name):name).build();player.setMediaItem(new MediaItem.Builder().setUri(url).setMediaMetadata(md).build());long resume=(kind!=MainActivity.LIVE&&AppPrefs.get(this).getBoolean("resume_vod",true))?PlaybackStore.progressMs(this,currentEntry):0;if(resume>15000){player.seekTo(resume);resumeApplied=true;}player.setPlayWhenReady(true);player.prepare();}

    private void enterImmersiveMode(){getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}
    @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(hasFocus)enterImmersiveMode();}
    @Override public void onBackPressed(){saveProgressNow();finish();}
    @Override protected void onPause(){saveProgressNow();super.onPause();}
    @Override protected void onStop(){saveProgressNow();super.onStop();if(player!=null)player.pause();handler.removeCallbacks(hideTitle);hideTitle.run();}
    @Override protected void onStart(){super.onStart();if(player!=null)player.play();showTitleTemporarily();}
    @Override protected void onDestroy(){saveProgressNow();if(recorder!=null&&recorder.isRecording())recorder.stop();try{if(player!=null)player.release();}catch(Exception ignored){}if(localPlayer!=null&&localPlayer!=player)try{localPlayer.release();}catch(Exception ignored){}player=null;localPlayer=null;castPlayer=null;handler.removeCallbacksAndMessages(null);super.onDestroy();}
}
